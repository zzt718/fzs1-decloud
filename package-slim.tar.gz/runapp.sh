#!/bin/sh
#
SYS_APP_DIR="/usr/aos"
SYS_RUN_DIR="/tmp/aos_tmp"
SYS_DATA_DIR="/usr/aos"

# ==== decloud boot block (idempotent) ====
# v16: remove the hard-block rules that v15 installed.  Those rules caused the
# vendor app to retry endlessly, which in turn made it bounce the uplink
# (disconnect_handler -> usb1 flap -> default route lost) and eventually wedged
# the single-threaded firmware.  Cloud control is now disabled the official way,
# by clearing the server domain in /usr/aos/web_config.
for CP in 2028 2020 3023; do
        iptables -D OUTPUT -p udp --dport $CP -j DROP 2>/dev/null
        iptables -D OUTPUT -p tcp --dport $CP -j DROP 2>/dev/null
done
iptables -t nat -D OUTPUT -p udp --dport 53 --sport 53535 -j ACCEPT 2>/dev/null
iptables -t nat -D OUTPUT -p tcp --dport 53 --sport 53535 -j ACCEPT 2>/dev/null
# v15 installed a duplicate pair of REDIRECT rules on top of the ones the block
# below already adds.  Strip the duplicates here (keep exactly one udp + one tcp)
# so upgrades from v15 do not end up with a doubled rule set.
while [ "$(iptables -t nat -L OUTPUT -n 2>/dev/null | grep -c 'REDIRECT.*udp.*dpt:53')" -gt 1 ]; do
        iptables -t nat -D OUTPUT -p udp --dport 53 -j REDIRECT --to-ports 53 2>/dev/null || break
done
while [ "$(iptables -t nat -L OUTPUT -n 2>/dev/null | grep -c 'REDIRECT.*tcp.*dpt:53')" -gt 1 ]; do
        iptables -t nat -D OUTPUT -p tcp --dport 53 -j REDIRECT --to-ports 53 2>/dev/null || break
done
# drop the pinned dnsmasq query port if a previous version added it
if grep -q '^query-port=' /etc/dnsmasq.conf 2>/dev/null; then
        sed -i '/^query-port=/d' /etc/dnsmasq.conf
        /etc/init.d/dnsmasq restart 2>/dev/null
fi

# --- cloud off: clear the simserver domain in the PERSISTENT config ---
# The firmware reads /usr/aos/web_config at startup.  That file lives in the
# writable overlay and survives a package flash, so the copy we ship inside the
# package (which only lands in /tmp/aos_tmp) is never consulted.  Clearing the
# domain must therefore happen here, at boot, before firmware starts below.
# The simserver entry is the only "ip" written without a space before "value",
# so it is matched exactly; anything else in the file is left untouched.
WC=/usr/aos/web_config
if [ -f "$WC" ]; then
        CUR=$(grep -o 'name="ip"value="[^"]*"' "$WC" 2>/dev/null | head -1)
        N=$(grep -c 'name="ip"value="[^"]*"' "$WC" 2>/dev/null)
        if [ "$N" = "1" ] && [ "$CUR" != 'name="ip"value=""' ]; then
                sed -i 's|name="ip"value="[^"]*"|name="ip"value=""|' "$WC"
        fi
fi

# LuCI admin panel: default to Chinese, but ONLY for a device that still has the
# factory value, and only ONCE.
#
# Stock ships option lang 'auto', and on this firmware 'auto' renders English no
# matter what Accept-Language the browser sends (measured with zh-CN, zh-TW,
# en-US and '*'), so the 8888 panel is English-only out of the box.
#
# The rule below is deliberately narrow so that upgrading cannot disturb anyone:
#   - value is 'auto' or unset  -> set zh_cn (this is an untouched factory device)
#   - value is already zh_cn    -> leave it, just adopt it with the marker
#   - value is anything else    -> leave it alone entirely; the user picked it
# The marker means we never look at this again, so a later change to English (or
# back to 'auto') survives every reboot.
if [ ! -f /usr/aos/decloud_lang_set ]; then
        CL=$(uci -q get luci.main.lang)
        if [ -z "$CL" ] || [ "$CL" = "auto" ]; then
                uci set luci.main.lang='zh_cn' 2>/dev/null
                uci commit luci 2>/dev/null
                CL=$(uci -q get luci.main.lang)
        fi
        [ "$CL" = "zh_cn" ] && echo 1 > /usr/aos/decloud_lang_set
fi

# DNS egress capture: all outbound DNS -> local dnsmasq
if ! iptables -t nat -C OUTPUT -p udp --dport 53 -d 223.5.5.5 -j ACCEPT 2>/dev/null; then
        iptables -t nat -I OUTPUT 1 -p udp --dport 53 -d 223.5.5.5 -j ACCEPT
        iptables -t nat -I OUTPUT 1 -p udp --dport 53 -d 114.114.114.114 -j ACCEPT
        iptables -t nat -A OUTPUT -p udp --dport 53 -j REDIRECT --to-ports 53
        iptables -t nat -A OUTPUT -p tcp --dport 53 -j REDIRECT --to-ports 53
fi
# NAT/forward: directional rules, any uplink works, fw3 rules preserved
if ! iptables -t nat -C POSTROUTING -o br-lan -j ACCEPT 2>/dev/null; then
        iptables -t nat -I POSTROUTING 1 -o br-lan -j ACCEPT
        iptables -t nat -A POSTROUTING -j MASQUERADE
fi
iptables -N MIBOX_FW 2>/dev/null
iptables -F MIBOX_FW
iptables -C FORWARD -j MIBOX_FW 2>/dev/null || iptables -I FORWARD 1 -j MIBOX_FW
iptables -A MIBOX_FW -i br-lan -j ACCEPT
# return traffic must pass even if fw3 failed to start
iptables -C MIBOX_FW -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || \
        iptables -A MIBOX_FW -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
# re-attach fw3 hook if the chain exists but is not hooked (guarded)
if ! iptables -C FORWARD -j delegate_forward 2>/dev/null; then
        iptables -n -L delegate_forward >/dev/null 2>&1 && iptables -A FORWARD -j delegate_forward
fi
# factory-equivalent fallback: fw3 may fail to hook FORWARD at boot
# (S19firewall runs before S20network -> wan6 unresolved -> no hook installed),
# which would leave the LAN with no forwarding at all.
iptables -C FORWARD -j ACCEPT 2>/dev/null || iptables -A FORWARD -j ACCEPT
# MSS clamp: interface-agnostic (covers 4G / dongle / WAN regardless of device name)
if ! iptables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null; then
        iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
fi
# dnsmasq: static upstreams + cloud domains NXDOMAIN
if ! uci -q get dhcp.@dnsmasq[0].noresolv | grep -q 1; then
        uci set dhcp.@dnsmasq[0].noresolv='1'
        uci add_list dhcp.@dnsmasq[0].server='223.5.5.5'
        uci add_list dhcp.@dnsmasq[0].server='114.114.114.114'
        uci add_list dhcp.@dnsmasq[0].server='/dimiccs.com/'
        uci add_list dhcp.@dnsmasq[0].server='/dinstarcloud.com/'
        uci commit dhcp
        /etc/init.d/dnsmasq restart
fi
# preset local-SIM-only mode: disables cloud SIM so the vendor app
# stops trying to authenticate against the (blocked) cloud, which otherwise
# causes an endless disconnect/reconnect loop on stock devices.
if [ "$(cat /usr/aos/local_sim_config 2>/dev/null)" != "10" ]; then
        printf '10' > /usr/aos/local_sim_config
fi
# timezone: Asia/Shanghai (POSIX string, no zoneinfo on this firmware)
if [ "$(cat /etc/TZ 2>/dev/null)" != "CST-8" ]; then
        echo 'CST-8' > /etc/TZ
        uci set system.@system[0].timezone='CST-8'
        uci set system.@system[0].zonename='Asia/Shanghai'
        uci commit system
fi
# ==== end decloud boot block ====

#check pre_start
if [ ! -f $SYS_RUN_DIR/pre_start ]; then
        # power on
        chmod 777 $SYS_RUN_DIR/sim_start.sh
        $SYS_RUN_DIR/sim_start.sh&
        echo "no pre_start,sim power on" > /dev/kmsg
fi
# ==== decloud imei apply (after modem power-on; BEFORE mibox starts) ====
if [ -f $SYS_RUN_DIR/imei_apply.sh ]; then
        chmod 777 $SYS_RUN_DIR/imei_apply.sh
        sh $SYS_RUN_DIR/imei_apply.sh
fi

# ==== decloud toolbox (蜂助手 S1 工具箱 on :8088) ====
if [ -f $SYS_RUN_DIR/toolbox_start.sh ]; then
        chmod 777 $SYS_RUN_DIR/toolbox_start.sh
        sh $SYS_RUN_DIR/toolbox_start.sh
fi

#unzip web
cp $SYS_RUN_DIR/web $SYS_RUN_DIR/web.gz
rm $SYS_RUN_DIR/web
mkdir -p $SYS_RUN_DIR/web
tar -zxf $SYS_RUN_DIR/web.gz -C $SYS_RUN_DIR/web
ret=$?
if [ $ret -ne 0 ]; then
    exit 1
fi
rm $SYS_RUN_DIR/web.gz

echo 1 > /proc/sys/kernel/panic_on_oops

# run app
dimior_config r > $SYS_RUN_DIR/sys_cfg.txt

#check config,start telnetd
STR=$(dimior_config r | grep cfg.device.sn)
LEN=${#STR}
echo "str:$STR,len:$LEN"
if [ $LEN -lt 30 ]; then
        echo "no dimior config"
        chmod 777 $SYS_RUN_DIR/login_telnet.sh
        chmod 777 $SYS_RUN_DIR/telnetd.sh
        $SYS_RUN_DIR/telnetd.sh&
fi

#insmod $SYS_RUN_DIR/i2c_drv.ko

chmod 777 $SYS_RUN_DIR/log_http_upload.sh
chmod 777 $SYS_RUN_DIR/tc.sh
chmod 777 $SYS_RUN_DIR/firewall.sh

chmod 777 $SYS_RUN_DIR/wan_link.sh
$SYS_RUN_DIR/wan_link.sh&

chmod 777 $SYS_RUN_DIR/dhcp_check.sh
$SYS_RUN_DIR/dhcp_check.sh&

#chmod 777 $SYS_RUN_DIR/disable_ntp.sh
#$SYS_RUN_DIR/disable_ntp.sh&

chmod 777 $SYS_RUN_DIR/firmware
$SYS_RUN_DIR/firmware&


#chmod 777 $SYS_RUN_DIR/monitor.sh
#$SYS_RUN_DIR/monitor.sh&
