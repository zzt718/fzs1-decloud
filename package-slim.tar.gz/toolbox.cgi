#!/bin/sh
# toolbox.cgi - decloud edition v6
# single AJAX endpoint (one microcom session), at-port mutex, single auto-refresh
FACTORY_BAND="12,78,145,482,149,0,2,2"
AUTO_SEC=6
BACKUP=/etc/band_backup

at_port(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in *1.1:1.4*) echo "${t##*/}"; return;; esac
  done
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in
      *:1.4*)
        PP=${t##*/}
        at_clearlock "$PP"
        R=$( (echo -e 'ATI
'; sleep 1) | microcom -t 1500 -s 115200 /dev/$PP 2>/dev/null )
        at_clearlock "$PP"
        case "$R" in *EC200T*) echo "$PP"; return;; esac;;
    esac
  done
}
at_lock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    if [ -n "$LP" ] && kill -0 $LP 2>/dev/null; then
      i=0
      while [ $i -lt 12 ]; do
        LP=$(cat /tmp/at_busy.lock 2>/dev/null)
        kill -0 $LP 2>/dev/null || break
        sleep 1
        i=$((i+1))
      done
    fi
  fi
  echo $$ > /tmp/at_busy.lock
}
at_unlock(){ rm -f /tmp/at_busy.lock; }

# ---------- ④ 网口与上网优先级：辅助 ----------
# "仅 有线"模式：4G 保持拨号（拨号守卫无感知），只在防火墙拦断其转发/出站。
# 规则同步写入 /etc/firewall.user（fw3 reload / 重启后自动恢复）。
net_block(){
  if ! iptables -C FORWARD -o usb1 -j REJECT 2>/dev/null; then
    iptables -I FORWARD 1 -o usb1 -j REJECT
  fi
  if ! iptables -C OUTPUT -o usb1 -j REJECT 2>/dev/null; then
    iptables -I OUTPUT 1 -o usb1 -j REJECT
  fi
  if ! grep -q 'toolbox net-onlywan' /etc/firewall.user 2>/dev/null; then
    printf '%s\n' '# toolbox net-onlywan (managed block)' \
      'iptables -I FORWARD 1 -o usb1 -j REJECT' \
      'iptables -I OUTPUT 1 -o usb1 -j REJECT' >> /etc/firewall.user
  fi
}
net_unblock(){
  iptables -D FORWARD -o usb1 -j REJECT 2>/dev/null
  iptables -D OUTPUT -o usb1 -j REJECT 2>/dev/null
  # busybox sed 不支持 /re/,+2d，按行匹配逐条删除
  sed -i '/toolbox net-onlywan/d;/^iptables -I FORWARD 1 -o usb1 -j REJECT$/d;/^iptables -I OUTPUT 1 -o usb1 -j REJECT$/d' /etc/firewall.user 2>/dev/null
}
# 厂商 udhcpc 脚本在 WAN 租约到达时会加 metric0 的 WAN 默认路由并删光其他默认路由
# （路由谋杀之二）。官方扩展点 /etc/udhcpc.user 在每次 DHCP 事件后被 source——在此按
# 工具箱当前模式校正：metric5 模式补 WAN(m5)+4G(m10) 双默认，出厂模式不动（保持 v19.6 行为）。
net_udhcpc_hook(){
  cat > /etc/udhcpc.user << 'UEOF'
# toolbox net-mode guard: sourced by udhcpc script after every DHCP event
[ "$interface" = "eth0.2" ] || exit 0
M=$(uci -q get network.wan.metric 2>/dev/null); [ -z "$M" ] && M=30
A=$(uci -q get network.wan.auto 2>/dev/null); [ -z "$A" ] && A=1
G4=$(ip route show table 102 2>/dev/null | awk '/^default/{print $3; exit}')
if [ "$1" = "deconfig" ]; then
  route del default dev eth0.2 2>/dev/null
  [ "$M" = "5" ] && [ -n "$G4" ] && route add default gw $G4 dev usb1 metric 10 2>/dev/null
  exit 0
fi
if [ "$M" = "5" ]; then
  [ -n "$router" ] && route add default gw $router dev $interface metric 5 2>/dev/null
  [ -n "$G4" ] && route add default gw $G4 dev usb1 metric 10 2>/dev/null
else
  route del default dev eth0.2 2>/dev/null
  [ -n "$G4" ] && route add default gw $G4 dev usb1 metric 10 2>/dev/null
fi
exit 0
UEOF
}
net_port_human(){
  case "$1" in
    p1) echo "LAN1 作 WAN";;
    p2) echo "LAN2 作 WAN";;
    all) echo "全部 LAN（不做有线 WAN）";;
    *)  echo "LAN0 作 WAN（出厂默认）";;
  esac
}
net_mode_human(){
  case "$1" in
    wan) echo "有线优先";;
    only4g) echo "仅 4G";;
    onlywan) echo "仅 有线";;
    *) echo "4G 优先";;
  esac
}
# microcom creates /var/lock/LCK..ttyUSBn and removes it on a clean exit.  If the
# process is killed (our watchdog does exactly that) the lock is left behind and
# every later open fails with "File exists" -- the module looks dead even though
# it is fine.  Clear the lock when its owner is gone.  Called before and after
# each microcom run so a stale lock can never wedge the AT port permanently.
at_clearlock(){
  L=/var/lock/LCK..$1
  [ -f "$L" ] || return 0
  LP=$(cat "$L" 2>/dev/null | tr -d '\0\r\n ')
  case "$LP" in
    ''|*[!0-9]*) rm -f "$L"; return 0 ;;
  esac
  kill -0 "$LP" 2>/dev/null || rm -f "$L"
}
at_trylock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    [ -n "$LP" ] && kill -0 $LP 2>/dev/null && return 1
  fi
  echo $$ > /tmp/at_busy.lock
  return 0
}

# 换频段后的后台收尾：等模组重新驻网 -> 补一次拨号（固件自己不重拨）-> 验证上网。
# 全程不动电源、不重启模组；固件的 AT 轮询与页面刷新照常，本脚本与其共用
# /tmp/at_busy.lock 串行化。状态写 /tmp/band_follow（RUN/1/0），页脚 4 分钟后自清。
band_follow_launch(){
  if [ -f /tmp/band_follow.pid ]; then
    FP=$(cat /tmp/band_follow.pid 2>/dev/null)
    kill -0 "$FP" 2>/dev/null && return 0
  fi
  cat > /tmp/band_follow.sh << 'FEOF'
#!/bin/sh
echo RUN > /tmp/band_follow
atc(){
  at_clearlock(){
    L=/var/lock/LCK..$1
    [ -f "$L" ] || return 0
    LP=$(cat "$L" 2>/dev/null | tr -d '\0\r\n ')
    case "$LP" in ''|*[!0-9]*) rm -f "$L"; return 0;; esac
    kill -0 "$LP" 2>/dev/null || rm -f "$L"
  }
  at_clearlock "$1"
  O=/tmp/atc_bf.txt; rm -f $O
  ( (echo -e "$2\r"; sleep 1) | microcom -t 1500 -s 115200 /dev/$1 > $O 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  R=$(cat $O 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  rm -f $O
  at_clearlock "$1"
  echo "$R"
}
findport(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t 2>/dev/null)
    case "$p" in */1-1.1/1-1.1:1.4/*) echo "${t##*/}"; return 0;; esac
  done
  return 1
}
lock(){ echo $$ > /tmp/at_busy.lock; }
unlock(){ rm -f /tmp/at_busy.lock; }
busy(){ [ -f /tmp/at_busy.lock ] && { LP=$(cat /tmp/at_busy.lock 2>/dev/null); [ -n "$LP" ] && kill -0 $LP 2>/dev/null && return 0; }; return 1; }
T0=$(cut -d. -f1 /proc/uptime)
REG=0
# 420s：严格 TDD=0 锁定时模组可能挣扎数分钟（模组固件已知缺陷，软恢复无害），多等
while [ $(( $(cut -d. -f1 /proc/uptime) - T0 )) -lt 420 ]; do
  P=$(findport) || { sleep 3; continue; }
  if ! busy; then
    lock
    R=$(atc "$P" 'AT+CEREG?')
    unlock
    case "$R" in *": 0,1"*|*": 2,1"*) REG=1; break;; esac
  fi
  sleep 4
done
if [ $REG -eq 0 ]; then
  echo 0 > /tmp/band_follow
  sleep 240; rm -f /tmp/band_follow /tmp/band_follow.pid
  exit 1
fi
sleep 3
P=$(findport)
if [ -n "$P" ] && ! busy; then
  lock
  atc "$P" 'AT+QNETDEVCTL=1,1'
  unlock
fi
T1=$(cut -d. -f1 /proc/uptime)
OK=0
while [ $(( $(cut -d. -f1 /proc/uptime) - T1 )) -lt 60 ]; do
  if ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; then OK=1; break; fi
  sleep 5
done
if [ $OK -eq 0 ]; then
  sleep 10
  P=$(findport)
  if [ -n "$P" ] && ! busy; then
    lock
    atc "$P" 'AT+QNETDEVCTL=1,1'
    unlock
  fi
  T2=$(cut -d. -f1 /proc/uptime)
  while [ $(( $(cut -d. -f1 /proc/uptime) - T2 )) -lt 60 ]; do
    if ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; then OK=1; break; fi
    sleep 5
  done
fi
if ! ip addr show usb1 2>/dev/null | grep -q inet; then
  udhcpc -i usb1 -n -q -t 8 -T 2 >/dev/null 2>&1
fi
if [ $OK -eq 1 ]; then echo 1 > /tmp/band_follow; else echo 0 > /tmp/band_follow; fi
sleep 240
rm -f /tmp/band_follow /tmp/band_follow.pid
FEOF
  chmod 755 /tmp/band_follow.sh
  start-stop-daemon -S -b -m -p /tmp/band_follow.pid -x /bin/sh -- /tmp/band_follow.sh
  return 0
}
follow_out(){
  F=$(cat /tmp/band_follow 2>/dev/null)
  [ -n "$F" ] && echo "FOLLOW=$F"
  return 0
}

atc(){
  at_clearlock "$1"
  rm -f /tmp/atc_out_$$
  # -t is microcom's own silence timeout: it exits by itself once the line goes
  # quiet, so the 8s watchdog the old version needed (and its killall, which
  # killed other readers and stranded the lock file) is gone.  Measured: stdin 1s
  # + -t 1500 reads every response in full, and cuts each call from 8s to ~4s.
  ( (echo -e "$2\r"; sleep 1) | microcom -t 1500 -s 115200 /dev/$1 > /tmp/atc_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  cat /tmp/atc_out_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' '
  rm -f /tmp/atc_out_$$
  at_clearlock "$1"
}
band_write(){
  at_lock
  i=0
  while [ $i -lt 4 ]; do
    ATP=$(at_port)
    if [ -n "$ATP" ]; then
      W=$(atc $ATP "AT*BAND=$1")
      case "$W" in *OK*) at_unlock; return 0;; esac
    fi
    sleep 3
    i=$((i+1))
  done
  at_unlock
  return 1
}
band_human(){
  BH_LOW=$(echo "$1" | cut -d, -f5)
  BH_HIGH=$(echo "$1" | cut -d, -f4)
  BH_OUT=""; BH_N=0
  [ $(( BH_LOW & 1 )) -ne 0 ] && { BH_OUT="$BH_OUT B1"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 4 )) -ne 0 ] && { BH_OUT="$BH_OUT B3"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 16 )) -ne 0 ] && { BH_OUT="$BH_OUT B5"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B8"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 2 )) -ne 0 ] && { BH_OUT="$BH_OUT B34"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 32 )) -ne 0 ] && { BH_OUT="$BH_OUT B38"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 64 )) -ne 0 ] && { BH_OUT="$BH_OUT B39"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B40"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 256 )) -ne 0 ] && { BH_OUT="$BH_OUT B41"; BH_N=$((BH_N+1)); }
  if [ $BH_N -eq 0 ]; then echo "当前未启用任何频段"; else echo "已启用$BH_OUT"; fi
}

# ==================== ③ 锁定频点 / 小区（AT*CELL，ASR 私有命令） ====================
# 语法（实测确认）：AT*CELL=<mode>,3,<band>,<earfcn>[,<pci>]
#   mode=1 频率锁（4 参）/ mode=2 小区锁（5 参）/ AT*CELL=0 解除
# 注意：band 用【真实频段号】（传 3 锁 B3）；参数顺序是 <earfcn> 在前 <pci> 在后
CELL_LOCKFILE=/tmp/cell_lock_state
CELL_LOG=/tmp/cell_lock.log

cell_atc(){ # cell_atc <port> <cmd>
  CLC_D="$1"; CLC_C="$2"
  at_clearlock "$CLC_D"
  rm -f /tmp/cell_atc_$$
  ( (echo -e "$CLC_C\r"; sleep 1) | microcom -t 2000 -s 115200 /dev/$CLC_D > /tmp/cell_atc_$$ 2>/dev/null ) & CLC_MP=$!
  ( sleep 5; kill $CLC_MP 2>/dev/null ) & CLC_KT=$!
  wait $CLC_MP 2>/dev/null; kill $CLC_KT 2>/dev/null
  CLC_R=$(cat /tmp/cell_atc_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  rm -f /tmp/cell_atc_$$
  at_clearlock "$CLC_D"
  echo "$CLC_R"
}

cell_apply(){ # cell_apply <band> <earfcn> <pci|空>
  CA_B="$1"; CA_E="$2"; CA_P="$3"
  at_lock
  CA_OK=0
  CA_I=0
  while [ $CA_I -lt 4 ]; do
    CA_ATP=$(at_port)
    if [ -n "$CA_ATP" ]; then
      if [ -n "$CA_P" ]; then
        CA_R=$(cell_atc "$CA_ATP" "AT*CELL=2,3,$CA_B,$CA_E,$CA_P")
        CA_DESC="小区锁(B$CA_B/$CA_E/PCI$CA_P)"
      else
        CA_R=$(cell_atc "$CA_ATP" "AT*CELL=1,3,$CA_B,$CA_E")
        CA_DESC="频点锁(B$CA_B/$CA_E)"
      fi
      case "$CA_R" in
        *OK*)
          CA_OK=1
          printf '%s' "$CA_DESC" > $CELL_LOCKFILE
          break;;
      esac
    fi
    sleep 3
    CA_I=$((CA_I+1))
  done
  at_unlock
  [ $CA_OK -eq 1 ] && return 0
  return 1
}

cell_clear(){
  at_lock
  CC_OK=0
  CC_I=0
  while [ $CC_I -lt 4 ]; do
    CC_ATP=$(at_port)
    if [ -n "$CC_ATP" ]; then
      CC_R=$(cell_atc "$CC_ATP" 'AT*CELL=0')
      case "$CC_R" in *OK*) CC_OK=1; rm -f $CELL_LOCKFILE; break;; esac
    fi
    sleep 3
    CC_I=$((CC_I+1))
  done
  at_unlock
  [ $CC_OK -eq 1 ] && return 0
  return 1
}

# 锁定/解除后的兜底：写入后若仍未注册 → （锁定模式）自动解除锁定；
# 若已注册但未拨号 → 补一轮拨号（解除锁定后模组重新搜网会掉数据呼叫，同样需要）
cell_guard_launch(){ # cell_guard_launch <mode:lock|clear>
  CG_MODE="$1"
  cat > /tmp/cell_guard.sh << CGEOF
#!/bin/sh
# mode=$CG_MODE: lock=锁定后兜底（未驻网自动解除）；clear=解除后兜底（只补拨号）
sleep 20
# ---- 阶段 1：检查注册（最多 5 轮 × 15s = 75s） ----
i=0
OK=0
while [ \$i -lt 5 ]; do
  P=""
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=\$(readlink -f \$t 2>/dev/null)
    case "\$p" in */1-1.1/1-1.1:1.4/*) P="\${t##*/}";; esac
  done
  if [ -n "\$P" ]; then
    R=\$( ( (echo -e 'AT+QNWINFO\r'; sleep 1) | microcom -t 2000 -s 115200 /dev/\$P 2>/dev/null ) | tr -d '\r' | tr '\n' ' ')
    case "\$R" in *BAND*) OK=1; break;; esac
  fi
  sleep 15
  i=\$((i+1))
done
if [ \$OK -eq 0 ]; then
  # 未驻网 → 锁定模式下解除锁定（回正常驻网）；解除模式下继续等（没什么可撤的）
  if [ "$CG_MODE" = "lock" ]; then
    for t in /sys/bus/usb-serial/devices/ttyUSB*; do
      p=\$(readlink -f \$t 2>/dev/null)
      case "\$p" in */1-1.1/1-1.1:1.4/*) P="\${t##*/}";; esac
    done
    [ -n "\$P" ] && ( (echo -e 'AT*CELL=0\r'; sleep 1) | microcom -t 2000 -s 115200 /dev/\$P >/dev/null 2>&1 )
    rm -f /tmp/cell_lock_state
    echo "GUARD: 锁定后 75s 未驻网，已自动解除锁定" >> /tmp/cell_lock.log
  else
    echo "GUARD: 解除后 75s 未驻网（网络侧问题，非锁定残留）" >> /tmp/cell_lock.log
  fi
  rm -f /tmp/cell_guard.pid
  exit 0
fi
# ---- 阶段 2：已驻网，检查数据通道 ----
# 判据 = AT+QNETDEVCTL? 的末位（1=已拨号，0=未拨号）
# 注意：不能用"网卡有 192.168.43.x IP"判断 —— 那是模组侧固定地址，未拨号时也存在（踩过坑）
# 也不能用 ping 网关判断 —— 网关就是模组本身，未拨号时照通
# 补拨号用 停(=0,1)→起(=1,1) 两步：模组侧呼叫状态可能与查询值滞后，只发"起"无效（实测踩过）
cell_dialed(){ # 返回 1=已拨号
  [ -z "\$1" ] && return 1
  local Q
  Q=\$( ( (echo -e 'AT+QNETDEVCTL?\r'; sleep 1) | microcom -t 2000 -s 115200 /dev/\$1 2>/dev/null ) | tr -d '\r' | tr '\n' ' ')
  case "\$Q" in
    *"+QNETDEVCTL: 1,1,"*,1*) return 0;;
    *"+QNETDEVCTL: 1,1,"*,1" "*) return 0;;
  esac
  return 1
}
sleep 10
if [ -n "\$P" ] && ! cell_dialed "\$P"; then
  ( (echo -e 'AT+QNETDEVCTL=0,1\r'; sleep 2; echo -e 'AT+QNETDEVCTL=1,1\r'; sleep 2) | microcom -t 6000 -s 115200 /dev/\$P >/dev/null 2>&1 )
  echo "GUARD: 驻网正常但未拨号，已重拨（停→起）" >> /tmp/cell_lock.log
  sleep 20
  if cell_dialed "\$P"; then
    echo "GUARD: 重拨成功，数据通道已恢复" >> /tmp/cell_lock.log
  else
    echo "GUARD: 重拨后仍未连通（可点刷新，或稍后再试）" >> /tmp/cell_lock.log
  fi
else
  echo "GUARD: 服务与数据通道均正常" >> /tmp/cell_lock.log
fi
rm -f /tmp/cell_guard.pid
CGEOF
  chmod 755 /tmp/cell_guard.sh
  start-stop-daemon -S -b -m -p /tmp/cell_guard.pid -x /bin/sh -- /tmp/cell_guard.sh
}

cell_state_human(){ # 从状态文件读"当前锁定"描述
  if [ -f $CELL_LOCKFILE ]; then
    cat $CELL_LOCKFILE 2>/dev/null
  else
    echo "未锁定"
  fi
}

# 频段下拉选项：v19.6 起由 EARFCN 自动推导频段（3GPP TS 36.101，EARFCN 全局唯一），
# 用户不再需要手选频段，故本函数已不再被调用。

# EARFCN -> 频段自动推导（3GPP TS 36.101 标准范围；EARFCN 全局唯一，无需用户选频段）
# 返回频段号；不在支持范围时返回空
earfcn_to_band(){
  EB_E="$1"
  case "$EB_E" in ''|*[!0-9]*) echo ""; return;; esac
  if [ "$EB_E" -ge 0 ] && [ "$EB_E" -le 599 ]; then echo 1; return; fi
  if [ "$EB_E" -ge 1200 ] && [ "$EB_E" -le 1949 ]; then echo 3; return; fi
  if [ "$EB_E" -ge 2400 ] && [ "$EB_E" -le 2649 ]; then echo 5; return; fi
  if [ "$EB_E" -ge 3450 ] && [ "$EB_E" -le 3799 ]; then echo 8; return; fi
  if [ "$EB_E" -ge 36200 ] && [ "$EB_E" -le 36349 ]; then echo 34; return; fi
  if [ "$EB_E" -ge 37750 ] && [ "$EB_E" -le 38249 ]; then echo 38; return; fi
  if [ "$EB_E" -ge 38250 ] && [ "$EB_E" -le 38649 ]; then echo 39; return; fi
  if [ "$EB_E" -ge 38650 ] && [ "$EB_E" -le 39649 ]; then echo 40; return; fi
  if [ "$EB_E" -ge 39650 ] && [ "$EB_E" -le 41589 ]; then echo 41; return; fi
  echo ""
}

# MCC/MNC -> operator name.  Values come from the servingcell response we
# already read, so no extra AT command is needed.
op_name(){
  case "$1" in
    46000|46002|46004|46007|46008) echo "中国移动" ;;
    46001|46006|46009)             echo "中国联通" ;;
    46003|46005|46011)             echo "中国电信" ;;
    46015)                         echo "中国广电" ;;
    ""|"?"|"000")                  echo "" ;;
    *)                             echo "其他($1)" ;;
  esac
}

# one session, all data -> key=value lines
data_read(){
  ATP=$(at_port)
  [ -z "$ATP" ] && { echo "STATUSFAIL"; return 1; }
  rm -f /tmp/st_out_$$
  # Commands are pipelined in one burst and the reply is collected once at the
  # end.  Measured on-device: ~1s with this setting versus ~8s when each command
  # waited a full second, with the same 5/5 response rate.
  at_clearlock "$ATP"
  ( (echo -e 'AT*BAND?\r'; echo -e 'AT+QENG="servingcell"\r'; echo -e 'AT+CGSN\r'; echo -e 'AT+QCCID\r'; echo -e 'AT+CSQ\r'; sleep 1) | microcom -t 800 -s 115200 /dev/$ATP > /tmp/st_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  at_clearlock "$ATP"
  RAW=$(cat /tmp/st_out_$$ 2>/dev/null | tr -d '\r')
  rm -f /tmp/st_out_$$
  BANDV=$(echo "$RAW" | grep -o '\*BAND:[0-9,]*' | head -1 | sed 's/\*BAND://')
  CELL=$(echo "$RAW" | grep -o '+QENG: "servingcell".*' | head -1)
  DUPLEX=$(echo "$CELL" | cut -d, -f4 | tr -d '"')
  BAND=$(echo "$CELL" | cut -d, -f10)
  # PCI 与 EARFCN 也在 servingcell 响应里（字段 8/9），锁频点/小区功能要用
  CELLPCI=$(echo "$CELL" | cut -d, -f8 | tr -d '" ')
  CELLEARFCN=$(echo "$CELL" | cut -d, -f9 | tr -d '" ')
  case "$CELLPCI" in ''|*[!0-9]*) CELLPCI="";; esac
  case "$CELLEARFCN" in ''|*[!0-9]*) CELLEARFCN="";; esac
  RSRP=$(echo "$CELL" | cut -d, -f14 | tr -d '"')
  SINR=$(echo "$CELL" | cut -d, -f17 | tr -d '"')
  IMEI=$(echo "$RAW" | grep -oE '^[0-9]{15}$' | head -1)
  ICCID=$(echo "$RAW" | grep -o '+QCCID: [0-9A-Fa-f]*' | head -1 | sed 's/+QCCID: //')
  CSQ=$(echo "$RAW" | grep -o '+CSQ: [0-9]*' | head -1 | sed 's/+CSQ: //')
  # MCC/MNC live in fields 5/6 of the servingcell response
  MCC=$(echo "$CELL" | cut -d, -f5 | tr -d '"')
  MNC=$(echo "$CELL" | cut -d, -f6 | tr -d '"')
  MCCMNC="${MCC}${MNC}"
  case "$MCCMNC" in *[!0-9]*) MCCMNC="";; esac
  OPER=$(op_name "$MCCMNC")
  echo "BANDVAL=${BANDV:-READFAIL}"
  echo "DUPLEX=${DUPLEX:-?}"
  echo "BAND=${BAND:-?}"
  echo "IMEI=${IMEI:-读取失败}"
  echo "ICCID=${ICCID:-读取失败}"
  echo "CSQ=${CSQ:-?}"
  echo "RSRP=${RSRP:-?}"
  echo "SINR=${SINR:-?}"
  echo "OPER=$OPER"
  echo "CELLPCI=${CELLPCI:-}"
  echo "CELLEARFCN=${CELLEARFCN:-}"
  if [ -n "$BANDV" ]; then
    echo "HUMAN=$(band_human "$BANDV")"
  else
    echo "HUMAN=READFAIL"
  fi
  return 0
}

# The timestamp must describe when the data was actually read, not when it was
# served, so a cache hit re-emits the stored time instead of "now".  The panel
# therefore only shows a new time when a real AT read took place.
stamp_out(){
  ST=$(cat /tmp/at_stamp 2>/dev/null)
  [ -z "$ST" ] && ST=$(date +%H:%M:%S)
  echo "STAMP=$ST"
}

# ---------- ajax: all data (rate limited: min 3s between reads) ----------
case "$QUERY_STRING" in
  *a=data*)
    echo "Content-Type: text/plain; charset=utf-8"
    echo ""
    NOW=$(date +%s)
    LAST=""
    [ -f /tmp/at_lastdata ] && LAST=$(cat /tmp/at_lastdata 2>/dev/null)
    # A manual refresh sends force=1 and must always end in a real read, so it
    # bypasses the cache branch entirely and reads the module now.  The throttle
    # window is not waited out: at_trylock() below already serialises access, and
    # sleeping here only adds dead time (measured 5-6s instead of ~2s).
    # Auto-refresh omits the flag and still uses the cache, so the AT port is not
    # hit on every single tick.
    FORCE=0
    case "$QUERY_STRING" in *force=1*) FORCE=1 ;; esac
    if [ $FORCE -eq 0 ] && [ -n "$LAST" ] && [ $((NOW - LAST)) -lt 3 ] && [ -f /tmp/at_cached ]; then
      cat /tmp/at_cached
      # Keep the reported age at >=1.  A cache hit landing in the same second
      # would otherwise emit CACHED=0, which is the marker for "freshly read".
      AGE=$((NOW - LAST)); [ $AGE -lt 1 ] && AGE=1
      echo "CACHED=$AGE"
      stamp_out
      follow_out
      exit 0
    fi
    if ! at_trylock; then
      if [ -f /tmp/at_cached ]; then
        cat /tmp/at_cached
        echo "CACHED=-1"
        stamp_out
      else
        echo "BUSY"
      fi
      exit 0
    fi
    # The vendor app polls the same AT port every 20s and occasionally bursts a
    # SIM re-identification sequence; a read landing inside such a burst can come
    # back empty.  Retry before giving up, and only mark the result as fresh when
    # a retry actually succeeded (otherwise a stale cache would look fresh).
    GOT=0
    RT=0
    while [ $RT -lt 3 ]; do
      data_read > /tmp/at_try_$$ 2>/dev/null
      if grep -q 'BANDVAL=[0-9]' /tmp/at_try_$$ 2>/dev/null; then
        mv /tmp/at_try_$$ /tmp/at_cached
        GOT=1
        break
      fi
      RT=$((RT+1))
      [ $RT -lt 3 ] && sleep 2
    done
    rm -f /tmp/at_try_$$
    if [ ! -f /tmp/at_cached ]; then
      echo "STATUSFAIL"
    else
      cat /tmp/at_cached
    fi
    if [ $GOT -eq 1 ]; then
      date +%s > /tmp/at_lastdata
      date +%H:%M:%S > /tmp/at_stamp
    fi
    at_unlock
    echo "CACHED=0"
    stamp_out
    follow_out
    exit 0
    ;;
esac

LEN=$(echo -n "$CONTENT_LENGTH" | grep -o '[0-9]*' | head -1)
BODY=""
[ -n "$LEN" ] && BODY=$(dd bs=1 count=$LEN 2>/dev/null)

RESULT=""; RESULT_OK=""; APPLIED=""
POSTED=0

# ---------- imei POST (PRG; may trigger reboot) ----------
# ---------- root password POST (for the 8888 LuCI panel) ----------
case "$BODY" in
  *pw1=*)
    urldecode(){
      printf '%b' "$(echo "$1" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')"
    }
    PW0=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw0=\([^&]*\).*/\1/p' | head -1)")
    PW1=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw1=\([^&]*\).*/\1/p' | head -1)")
    PW2=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw2=\([^&]*\).*/\1/p' | head -1)")
    PW_RESULT=""; PW_OK=""
    # Whether the CURRENT PASSWORD must be verified depends on whether the user has
    # ever set one through this page -- NOT on whether root has a hash.  The factory
    # password is unknown to us and to the user, so a device that was never
    # configured here must be allowed to set one without knowing the old value;
    # otherwise the feature is unusable.  Once the user has set it themselves, every
    # later change must prove knowledge of it, so nobody else can take it over.
    PW_PREV=""
    if [ -f /usr/aos/decloud_pw_set ] || [ -f /tmp/webimei/pw_set ]; then PW_PREV=1; fi
    if [ -z "$PW1" ]; then
      PW_RESULT="密码不能为空"
    elif [ "$PW1" != "$PW2" ]; then
      PW_RESULT="两次输入的密码不一致"
    elif [ ${#PW1} -lt 8 ]; then
      PW_RESULT="密码太短，请至少 8 位"
    elif [ -n "$PW_PREV" ]; then
      # 已设过密码：校验当前密码（用 lua + nixio.crypt 比对 /etc/shadow）
      printf '%s' "$PW0" > /tmp/.pwchk
      PW_VALID=$(lua -e '
        local f=io.open("/tmp/.pwchk"); local p=f:read("*a"); f:close()
        local s=io.open("/etc/shadow"):read("*a")
        local h=s:match("^root:([^:]*):")
        local ok=require("nixio")
        if h and h~="" and h~="!" and h~="x" and ok.crypt(p,h)==h then print("1") else print("0") end
      ' 2>/dev/null)
      rm -f /tmp/.pwchk
      if [ "$PW_VALID" != "1" ]; then
        PW_RESULT="当前密码不正确，未做修改"
      else
        PW_SET_GO=1
      fi
    else
      PW_SET_GO=1
    fi
    if [ -n "$PW_SET_GO" ]; then
      BEFORE=$(grep '^root' /etc/shadow 2>/dev/null | cut -d: -f2)
      printf '%s\n%s\n' "$PW1" "$PW2" | passwd root >/tmp/pw_try 2>&1
      AFTER=$(grep '^root' /etc/shadow 2>/dev/null | cut -d: -f2)
      if [ -n "$AFTER" ] && [ "$BEFORE" != "$AFTER" ]; then
        # 用户已通过本界面设过密码：此后修改必须先验证旧密码
        echo 1 > /usr/aos/decloud_pw_set 2>/dev/null
        echo 1 > /tmp/webimei/pw_set 2>/dev/null
        PW_RESULT="密码设置成功！现在可用 root + 该密码登录 8888 管理后台"
        PW_OK=1
      else
        PW_RESULT="密码设置失败，请重试"
      fi
    fi
    echo "$PW_RESULT" > /tmp/pw_result
    echo "$PW_OK" > /tmp/pw_result_ok
    rm -f /tmp/pw_try
    echo "Status: 302 Found"
    echo "Location: /"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
  *imei=*)
    WANT=$(echo "$BODY" | grep -o 'imei=[0-9]*' | head -1 | cut -d= -f2)
    case "$WANT" in
      [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]) : ;;
      *) WANT="";;
    esac
    REBOOTNOW=0
    case "$BODY" in *reboot=1*) REBOOTNOW=1;; esac
    if [ -n "$WANT" ]; then
      # luhn sanity (server side; module enforces anyway)
      LS=0; LD=0
      i=14
      while [ $i -ge 0 ]; do
        D=$(echo "$WANT" | cut -c$((i+1)))
        if [ $LD -eq 1 ]; then D=$((D*2)); [ $D -gt 9 ] && D=$((D-9)); fi
        LS=$((LS+D)); LD=$((1-LD))
        i=$((i-1))
      done
      if [ $((LS % 10)) -ne 0 ]; then
        rm -f /usr/aos/imei_request
        {
          echo "IMEI 校验位不合法，已拒绝保存（设备会拒绝写入）。请核对后重试。"
          echo ""
          echo ""
        } > /tmp/imei_result
        echo "Status: 302 Found"
        echo "Location: /?a=band"
        echo "Content-Type: text/html"
        echo ""
        echo "redirecting"
        exit 0
      fi
      echo "$WANT" > /usr/aos/imei_request
      if [ $REBOOTNOW -eq 1 ]; then
        echo "Content-Type: text/html; charset=utf-8"
        echo ""
        echo "<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width, initial-scale=1'><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:17px}</style></head><body>"
        echo "<h2>IMEI 已保存，设备正在重启…</h2>"
        echo "<p style='color:#c62828'>重启时会把新 IMEI 写入设备，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
        echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
        echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
        echo "</body></html>"
        (sleep 2; sync; reboot) &
        exit 0
      fi
      {
        echo "IMEI 已保存：$WANT"
        echo "1"
        echo ""
      } > /tmp/imei_result
    else
      {
        echo "IMEI 格式错误（需要 15 位数字）"
        echo ""
        echo ""
      } > /tmp/imei_result
    fi
    echo "Status: 302 Found"
    echo "Location: /?a=band"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
esac

# ---------- reboot only (standalone button) ----------
case "$BODY" in
  *reboot=1*)
    echo "Content-Type: text/html; charset=utf-8"
    echo ""
    echo "<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width, initial-scale=1'><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:17px}</style></head><body>"
    echo "<h2>设备正在重启…</h2>"
    echo "<p style='color:#c62828'>重启时会把新 IMEI 写入设备，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
    echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
    echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
    echo "</body></html>"
    (sleep 2; sync; reboot) &
    exit 0
    ;;
esac

# ---------- actions (POST only) ----------
# order matters: restore_bak BEFORE restore (prefix collision)
case "$BODY" in
  *restore_bak*)
    POSTED=1
    if [ -f $BACKUP ]; then
      BK=$(cat $BACKUP)
      case "$BK" in
        [0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*) : ;;
        *) BK="";;
      esac
      if [ -z "$BK" ]; then
        RESULT="备份文件无效，请改用“恢复出厂频段”"
      elif band_write "$BK"; then
        band_follow_launch
        RESULT="已恢复上次配置，正在重新驻网并自动恢复拨号（约1分钟，无需重启）"; RESULT_OK=1; APPLIED="$BK"
      else
        RESULT="恢复失败：设备未响应，请重试"
      fi
    else
      RESULT="没有备份记录"
    fi
    ;;
esac
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *restore*)
    POSTED=1
    if band_write "$FACTORY_BAND"; then
      band_follow_launch
      RESULT="已恢复出厂频段，正在重新驻网并自动恢复拨号（约1分钟，无需重启）"; RESULT_OK=1; APPLIED="$FACTORY_BAND"
    else
      RESULT="恢复失败：设备未响应，请重试（设备可能正在重启）"
    fi
    ;;
esac
fi
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *low=*)
    POSTED=1
    LOWNEW=$(echo "$BODY" | grep -o 'low=[0-9]*' | head -1 | cut -d= -f2)
    HIGHNEW=$(echo "$BODY" | grep -o 'high=[0-9]*' | head -1 | cut -d= -f2)
    case "$LOWNEW" in ''|*[!0-9]*) LOWNEW=0;; esac
    case "$HIGHNEW" in ''|*[!0-9]*) HIGHNEW=0;; esac
    if [ "$LOWNEW" -eq 0 ] && [ "$HIGHNEW" -eq 0 ]; then
      RESULT="错误：至少勾选一个频段"
    elif [ "$LOWNEW" -gt 255 ] || [ "$HIGHNEW" -gt 4095 ]; then
      RESULT="错误：频段值超范围"
    else
      at_lock
      OLDV=""
      ATP=$(at_port)
      [ -n "$ATP" ] && OLDV=$(atc $ATP 'AT*BAND?' | grep -o '\*BAND:[0-9,]*' | sed 's/\*BAND://')
      [ -n "$OLDV" ] && echo "$OLDV" > $BACKUP
      R1=$(echo "$OLDV" | cut -d, -f1); R2=$(echo "$OLDV" | cut -d, -f2); R3=$(echo "$OLDV" | cut -d, -f3)
      T1=$(echo "$OLDV" | cut -d, -f6); T2=$(echo "$OLDV" | cut -d, -f7); T3=$(echo "$OLDV" | cut -d, -f8)
      [ -z "$R1" ] && R1=12; [ -z "$R2" ] && R2=78; [ -z "$R3" ] && R3=145
      [ -z "$T1" ] && T1=0; [ -z "$T2" ] && T2=2; [ -z "$T3" ] && T3=2
      NEW="$R1,$R2,$R3,$HIGHNEW,$LOWNEW,$T1,$T2,$T3"
      WR=0
      i=0
      while [ $i -lt 4 ]; do
        ATP=$(at_port)
        if [ -n "$ATP" ]; then
          W=$(atc $ATP "AT*BAND=$NEW")
          case "$W" in *OK*) WR=1; break;; esac
        fi
        sleep 3
        i=$((i+1))
      done
      at_unlock
      if [ $WR -eq 1 ]; then
        band_follow_launch
        RESULT="已应用新配置，正在重新驻网并自动恢复拨号（约1分钟，无需重启）"; RESULT_OK=1; APPLIED="$NEW"
      else
        RESULT="写入失败：设备未响应，请重试"
      fi
    fi
    ;;
esac
fi

# ---------- ③ 锁定频点 / 小区（POST） ----------
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *cell_clear*)
    POSTED=1
    if cell_clear; then
      # 解除后模组重新搜网会掉数据呼叫，守卫只负责把拨号补回来
      cell_guard_launch clear
      CELL_RESULT="已解除频点/小区锁定，设备正在重新搜网并自动恢复拨号（约 1 分钟）"; CELL_RESULT_OK=1
    else
      CELL_RESULT="解除失败：设备未响应，请重试"
    fi
    ;;
esac
fi
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *cell_lock*|*cell_apply*)
    POSTED=1
    CE_TMP=$(echo "$BODY" | grep -o 'cearfcn=[0-9]*' | head -1 | cut -d= -f2)
    CP_TMP=$(echo "$BODY" | grep -o 'cpci=[0-9]*' | head -1 | cut -d= -f2)
    case "$CE_TMP" in ''|*[!0-9]*) CE_TMP="";; esac
    case "$CP_TMP" in ''|*[!0-9]*) CP_TMP="";; esac
    # "一键锁定当前" 按钮：忽略表单值，直接读当前 servingcell 的频点与 PCI
    case "$BODY" in
      *cell_lock*)
        CUR_RAW=""
        at_lock
        ATP=$(at_port)
        if [ -n "$ATP" ]; then
          CUR_RAW=$(cell_atc "$ATP" 'AT+QENG="servingcell"')
        fi
        at_unlock
        CE_TMP=$(echo "$CUR_RAW" | cut -d, -f9 | tr -d '" ')
        CP_TMP=$(echo "$CUR_RAW" | cut -d, -f8 | tr -d '" ')
        case "$CE_TMP" in ''|*[!0-9]*) CE_TMP="";; esac
        case "$CP_TMP" in ''|*[!0-9]*) CP_TMP="";; esac
        ;;
    esac
    # 由 EARFCN 自动推导频段（不再需要用户选择）
    CB_TMP=""
    [ -n "$CE_TMP" ] && CB_TMP=$(earfcn_to_band "$CE_TMP")
    if [ -z "$CE_TMP" ]; then
      CELL_RESULT="错误：请填写频点（EARFCN），或先确保设备已驻网后点“一键锁定当前”"
    elif [ -z "$CB_TMP" ]; then
      CELL_RESULT="错误：频点 $CE_TMP 不在本设备支持的频段范围内"
    elif [ -n "$CP_TMP" ] && [ "$CP_TMP" -gt 503 ]; then
      CELL_RESULT="错误：PCI 范围为 0-503"
    else
      if [ -n "$CP_TMP" ]; then
        LOCKKIND="小区锁（B$CB_TMP / $CE_TMP / PCI $CP_TMP）"
      else
        LOCKKIND="频点锁（B$CB_TMP / $CE_TMP）"
      fi
      if cell_apply "$CB_TMP" "$CE_TMP" "$CP_TMP"; then
        cell_guard_launch lock
        CELL_RESULT="已下发 $LOCKKIND，设备正在重新搜网（约 10-60 秒）；若 75 秒后仍无网会自动解除锁定"; CELL_RESULT_OK=1
      else
        CELL_RESULT="锁定失败：设备未响应（可能忙或重启中），请稍后重试"
      fi
    fi
    ;;
esac
fi

# ---------- ④ 网口与上网优先级（POST） ----------
# 端口角色：写 /etc/net_port_mode（开机由 rc.local 钩子重放）并立即生效
# 优先级：network.wan.metric（30=4G优先 / 5=有线优先）+ wan.auto + 防火墙拦截
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *net_port=*|*net_mode=*)
    POSTED=1
    NP=$(echo "$BODY" | grep -o 'net_port=[a-z0-9]*' | head -1 | cut -d= -f2)
    NM2=$(echo "$BODY" | grep -o 'net_mode=[a-z0-9]*' | head -1 | cut -d= -f2)
    case "$NP" in p1|p2|all) ;; *) NP=p0;; esac
    case "$NM2" in wan|only4g|onlywan) ;; *) NM2=4g;; esac
    # 全部 LAN 时没有有线 WAN，有线优先/仅有线 自动回落为 4G 优先
    if [ "$NP" = "all" ] && [ "$NM2" != "only4g" ]; then NM2=4g; fi
    case "$NP" in
      p1)
        cat > /etc/net_port_mode << 'NPEOF'
#!/bin/sh
# NETPORT=p1  LAN1 (chip port2) as WAN
switch reg w 14 405555
switch reg w 50 2001
switch reg w 98 7f3f
switch reg w e4 3f
switch reg w 40 1001
switch reg w 44 1002
switch reg w 48 1001
switch reg w 70 ffff447b
switch reg w 74 ffffffff
switch clear
NPEOF
        ;;
      p2)
        cat > /etc/net_port_mode << 'NPEOF'
#!/bin/sh
# NETPORT=p2  LAN2 (chip port1) as WAN
switch reg w 14 405555
switch reg w 50 2001
switch reg w 98 7f3f
switch reg w e4 3f
switch reg w 40 2001
switch reg w 44 1001
switch reg w 48 1001
switch reg w 70 ffff427d
switch reg w 74 ffffffff
switch clear
NPEOF
        ;;
      all)
        cat > /etc/net_port_mode << 'NPEOF'
#!/bin/sh
# NETPORT=all  all three jacks LAN (no wired WAN)
switch reg w 14 405555
switch reg w 50 2001
switch reg w 98 7f3f
switch reg w e4 3f
switch reg w 40 1001
switch reg w 44 1001
switch reg w 48 1001
switch reg w 70 ffff407f
switch reg w 74 ffffffff
switch clear
NPEOF
        ;;
      *)
        rm -f /etc/net_port_mode
        # 恢复出厂寄存器（LLLLW：LAN0=4 号口在 WAN 侧）
        switch reg w 14 405555 >/dev/null 2>&1
        switch reg w 50 2001 >/dev/null 2>&1
        switch reg w 98 7f3f >/dev/null 2>&1
        switch reg w e4 3f >/dev/null 2>&1
        switch reg w 40 1001 >/dev/null 2>&1
        switch reg w 44 1001 >/dev/null 2>&1
        switch reg w 48 1002 >/dev/null 2>&1
        switch reg w 70 ffff506f >/dev/null 2>&1
        switch reg w 74 ffffffff >/dev/null 2>&1
        switch clear >/dev/null 2>&1
        ;;
    esac
    # 开机重放由包内 runapp.sh 负责（rc.local 在本固件不生效，实测）
    [ -f /etc/net_port_mode ] && sh /etc/net_port_mode >/dev/null 2>&1
    case "$NM2" in
      wan)
        uci set network.wan.metric='5'; uci set network.wan.auto='1'; uci commit network
        net_unblock
        net_udhcpc_hook
        ( ifup wan >/dev/null 2>&1 & )
        ;;
      only4g)
        uci set network.wan.metric='30'; uci set network.wan.auto='0'; uci commit network
        net_unblock
        net_udhcpc_hook
        route del default dev eth0.2 2>/dev/null
        ( ifdown wan >/dev/null 2>&1 & )
        ;;
      onlywan)
        uci set network.wan.metric='5'; uci set network.wan.auto='1'; uci commit network
        net_block
        net_udhcpc_hook
        route del default dev eth0.2 2>/dev/null
        ( ifup wan >/dev/null 2>&1 & )
        ;;
      *)
        uci set network.wan.metric='30'; uci set network.wan.auto='1'; uci commit network
        net_unblock
        net_udhcpc_hook
        route del default dev eth0.2 2>/dev/null
        ( ifup wan >/dev/null 2>&1 & )
        ;;
    esac
    NET_RESULT="已应用：$(net_port_human "$NP") + $(net_mode_human "$NM2")。网络已切换，若页面无响应请刷新"; NET_RESULT_OK=1
    ;;
esac
fi

# ---------- PRG: POST -> store result -> 302 redirect ----------
if [ $POSTED -eq 1 ]; then
  {
    echo "$RESULT"
    echo "$RESULT_OK"
    echo "$APPLIED"
  } > /tmp/band_result
  if [ -n "$CELL_RESULT" ]; then
    echo "$CELL_RESULT" > /tmp/cell_result
    echo "$CELL_RESULT_OK" > /tmp/cell_result_ok
  fi
  if [ -n "$NET_RESULT" ]; then
    echo "$NET_RESULT" > /tmp/net_result
    echo "$NET_RESULT_OK" > /tmp/net_result_ok
  fi
  echo "Status: 302 Found"
  echo "Location: /?a=band"
  echo "Content-Type: text/html"
  echo ""
  echo "redirecting"
  exit 0
fi

# ---------- GET: show stored result once, then delete ----------
PW_RESULT=""
PW_RESULT_OK=""
[ -f /tmp/pw_result ] && PW_RESULT=$(cat /tmp/pw_result 2>/dev/null)
[ -f /tmp/pw_result_ok ] && PW_RESULT_OK=$(cat /tmp/pw_result_ok 2>/dev/null)
rm -f /tmp/pw_result /tmp/pw_result_ok
# 用户是否通过工具箱设过密码（决定是否显示"已设置"状态）
PW_USER_SET=""
# Same rule as the POST branch: the "current password" field appears only once the
# user has set a password through this page (marker present).  A never-configured
# device must be settable without knowing the factory password.
if [ -f /usr/aos/decloud_pw_set ] || [ -f /tmp/webimei/pw_set ]; then
  PW_USER_SET=1
fi

IMEI_RESULT=""
IMEI_RESULT_OK=""
if [ -f /tmp/imei_result ]; then
  IMEI_RESULT=$(sed -n 1p /tmp/imei_result)
  IMEI_RESULT_OK=$(sed -n 2p /tmp/imei_result)
  rm -f /tmp/imei_result
fi
if [ -f /tmp/band_result ]; then
  RESULT=$(sed -n 1p /tmp/band_result)
  RESULT_OK=$(sed -n 2p /tmp/band_result)
  APPLIED=$(sed -n 3p /tmp/band_result)
  rm -f /tmp/band_result
fi
PENDING_IMEI=""
if [ -f /usr/aos/imei_request ]; then
  PENDING_IMEI=$(cat /usr/aos/imei_request 2>/dev/null | grep -o '[0-9]*' | head -1)
fi

# ---------- render ----------
HASBAK=""
[ -f $BACKUP ] && HASBAK=1
ck(){ [ $(( ($1 / $2) % 2 )) -eq 1 ] && echo "checked"; }

SKIPLOAD=0
CURTEXT="当前状态：正在读取，请稍候…"
if [ -n "$APPLIED" ]; then
  RLOW=$(echo "$APPLIED" | cut -d, -f5)
  RHIGH=$(echo "$APPLIED" | cut -d, -f4)
  CURTEXT="$(band_human "$APPLIED")"
  SKIPLOAD=1
else
  RLOW=0; RHIGH=0
fi
B1=$(ck $RLOW 1); B3=$(ck $RLOW 4); B5=$(ck $RLOW 16); B8=$(ck $RLOW 128)
B34=$(ck $RHIGH 2); B38=$(ck $RHIGH 32); B39=$(ck $RHIGH 64); B40=$(ck $RHIGH 128); B41=$(ck $RHIGH 256)
if [ -z "$APPLIED" ]; then
  B1=checked; B3=checked; B5=checked; B8=checked
  B34=checked; B38=checked; B39=checked; B40=checked; B41=checked
fi

# ---------- ③ 锁定频点/小区：渲染变量 ----------
CELL_RESULT=""
CELL_RESULT_OK=""
[ -f /tmp/cell_result ] && CELL_RESULT=$(sed -n 1p /tmp/cell_result 2>/dev/null)
[ -f /tmp/cell_result_ok ] && CELL_RESULT_OK=$(sed -n 1p /tmp/cell_result_ok 2>/dev/null)
rm -f /tmp/cell_result /tmp/cell_result_ok
CELL_LOCK=$(cell_state_human)
# 当前驻留（默认从最近缓存读；页面 JS 会用实时数据覆盖）
CELL_CUR="读取中…"
CELL_EARFCN=""
CELL_PCI=""
if [ -f /tmp/at_cached ]; then
  CC_E=$(sed -n 's/^CELLEARFCN=//p' /tmp/at_cached 2>/dev/null | head -1)
  CC_P=$(sed -n 's/^CELLPCI=//p' /tmp/at_cached 2>/dev/null | head -1)
  CC_B=$(sed -n 's/^BAND=//p' /tmp/at_cached 2>/dev/null | head -1)
  CC_D=$(sed -n 's/^DUPLEX=//p' /tmp/at_cached 2>/dev/null | head -1)
  case "$CC_B" in ''|'?'|*[!0-9]*) ;; *) CELL_CUR="B$CC_B ($CC_D)"; CELL_EARFCN="$CC_E"; CELL_PCI="$CC_P";; esac
fi

# ---------- ④ 网口与上网优先级：渲染变量 ----------
NET_RESULT=""
NET_RESULT_OK=""
[ -f /tmp/net_result ] && NET_RESULT=$(sed -n 1p /tmp/net_result 2>/dev/null)
[ -f /tmp/net_result_ok ] && NET_RESULT_OK=$(sed -n 1p /tmp/net_result_ok 2>/dev/null)
rm -f /tmp/net_result /tmp/net_result_ok
# 当前 WAN 口：/etc/net_port_mode 标记 NETPORT=p1/p2/all；无文件或 p0 = 出厂（LAN0）
NET_PORT="p0"
grep -q 'NETPORT=p1' /etc/net_port_mode 2>/dev/null && NET_PORT="p1"
grep -q 'NETPORT=p2' /etc/net_port_mode 2>/dev/null && NET_PORT="p2"
grep -q 'NETPORT=all' /etc/net_port_mode 2>/dev/null && NET_PORT="all"
# 当前模式：metric 5=有线优先；auto=0=仅4G；firewall.user 有拦截=仅有线；否则 4G 优先
NET_MODE="4g"
NMV=$(uci -q get network.wan.metric 2>/dev/null)
[ "$NMV" = "5" ] && NET_MODE="wan"
[ "$(uci -q get network.wan.auto 2>/dev/null)" = "0" ] && NET_MODE="only4g"
grep -q 'toolbox net-onlywan' /etc/firewall.user 2>/dev/null && NET_MODE="onlywan"
NP0=""; NP1=""; NP2=""; NALL=""
[ "$NET_PORT" = "p0" ] && NP0="checked"
[ "$NET_PORT" = "p1" ] && NP1="checked"
[ "$NET_PORT" = "p2" ] && NP2="checked"
[ "$NET_PORT" = "all" ] && NALL="checked"
NM4=""; NMW=""; NM4G=""; NMWG=""
[ "$NET_MODE" = "4g" ] && NM4="checked"
[ "$NET_MODE" = "wan" ] && NMW="checked"
[ "$NET_MODE" = "only4g" ] && NM4G="checked"
[ "$NET_MODE" = "onlywan" ] && NMWG="checked"

echo "Content-Type: text/html; charset=utf-8"
echo "Cache-Control: no-store, no-cache, must-revalidate"
echo "Pragma: no-cache"
echo ""

cat << CEOF
<!DOCTYPE html>
<html><head><meta charset=utf-8>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>蜂助手 S1 CPE 工具箱</title><style>
body{font-family:sans-serif;max-width:760px;margin:24px auto;font-size:16px;padding:0 12px}
table{border-collapse:collapse;margin:8px 0}
td,th{border:1px solid #bbb;padding:6px 14px}
.btn{padding:8px 22px;font-size:15px;margin-right:10px}
.msg{padding:12px;margin:12px 0;border-radius:6px}
.ok{background:#e6f7e6;border:1px solid #4caf50}
.err{background:#fdecea;border:1px solid #e57373}
.note{color:#888;font-size:13px;margin-top:6px}
.spinner{width:44px;height:44px;border:5px solid #ddd;border-top-color:#4caf50;border-radius:50%;animation:sp 1s linear infinite;margin:0 auto 14px}
.maskv{display:inline-block;width:180px;white-space:pre;font-family:monospace;letter-spacing:1px}
.eye{color:#888;cursor:pointer;opacity:.45;display:inline-block;vertical-align:-3px;transition:opacity .15s;user-select:none}
.eye:hover{opacity:.95}
.refresh{background:#fff;border:1px solid #ddd;border-radius:6px;cursor:pointer;
  padding:3px 9px;color:#777;font-size:13px;vertical-align:middle;line-height:1.6}
.refresh:hover{border-color:#4caf50;color:#2e7d32}
.refresh svg{vertical-align:-2px}
.refresh.spin svg{animation:spin .9s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.auto{color:#aaa;font-size:12px;margin-left:8px}
.pwin{width:220px;padding:5px 8px;border:1px solid #bbb;border-radius:4px;font-size:14px}
.pwin:focus{outline:none;border-color:#4caf50}
.pwmsg{font-size:13px;margin-left:8px}
.pwok{color:#2e7d32}
code{background:#f0f0f0;padding:1px 5px;border-radius:3px;font-size:13px}
.pwerr{color:#c62828}
@keyframes sp{to{transform:rotate(360deg)}}
.info{background:#f7f9fc;border:1px solid #ccd;border-radius:8px;padding:12px 16px;margin:10px 0}
.info b{display:inline-block;min-width:110px}
.stamp{color:#2e7d32;font-size:12px}   /* 数据面板底部的读取时间 */
/* ==== 功能块统一框（①~⑤ 同款；框内只放控件，标题/说明在框外） ==== */
.fbox{background:#f7f9fc;border:1px solid #ccd;border-radius:8px;padding:12px 16px;margin:10px 0}
.fbox input[type=text]{width:120px;padding:6px 8px;border:1px solid #bbb;border-radius:4px;font-size:14px;font-family:inherit}
.fbox input.imeiin{width:200px}   /* ① 的 IMEI 要放 15 位数字，比通用输入框宽 */
/* ==== ④ 端口条：仿设备背面（面向背面 LAN0 在最右） ==== */
.portstrip{display:flex;justify-content:center;gap:16px;background:#e8ebef;border:1px solid #ccd;border-radius:8px;padding:14px;margin:6px 0}
.port{position:relative;display:flex;flex-direction:column;align-items:center;cursor:pointer;padding:8px 10px;border-radius:8px}
.port input{position:absolute;opacity:0}
.port .jack{width:54px;height:36px;border:2px solid #9aa3ad;border-radius:4px;background:#f4f6f8;display:block;position:relative;transition:all .15s}
.port .jack i{position:absolute;left:50%;top:58%;transform:translateX(-50%);width:26px;height:13px;background:#c9cfd7;border:1px solid #9aa3ad;border-radius:0 0 3px 3px}
.port .plabel{font-size:13px;color:#555;margin-top:6px;font-family:monospace}
.port .rlan,.port .rwan{font-size:12px;margin-top:3px;padding:1px 9px;border-radius:3px}
.port .rlan{color:#888;background:#eef0f2}
.port .rwan{display:none;color:#fff;background:#4caf50;font-weight:bold}
.port input:checked ~ .jack{background:#e6f7e6;border-color:#4caf50;box-shadow:0 0 0 2px rgba(76,175,80,.35)}
.port input:checked ~ .jack i{background:#4caf50;border-color:#2e7d32}
.port input:checked ~ .plabel{color:#2e7d32;font-weight:bold}
.port input:checked ~ .rwan{display:inline}
.port input:checked ~ .rlan{display:none}
.port:hover .jack{border-color:#4caf50}
.fbox input[type=password]{width:220px;padding:5px 8px;border:1px solid #bbb;border-radius:4px;font-size:14px}
.fbox select{padding:6px 8px;border:1px solid #bbb;border-radius:4px;font-size:14px}
.fbox table{margin:0}
.fbox .row{margin:6px 0}
.fbox .sep{border-top:1px dashed #c5ccd8;margin:12px 0 10px}
.fbox .sub{color:#667;font-size:13px;margin:0 0 6px}
.cellstate{font-family:monospace;background:#eef3fb;border:1px solid #c5d4e8;border-radius:4px;padding:6px 10px;display:inline-block;margin:4px 0}
.locked{color:#2e7d32;font-weight:bold}
.unlocked{color:#888}
/* ==== 移动端适配 ==== */
@media (max-width:640px){
  body{font-size:16px;margin:12px auto;padding:0 10px}
  h2{font-size:20px}
  h3{font-size:17px;margin:18px 0 8px}
  /* 手机上说明性小字统一抬到 14px：13px 在手机上看偏小 */
  .note,.fbox .sub,.pwmsg,code,.stamp{font-size:14px}
  .auto{font-size:13px}
  table{width:100%}
  td,th{padding:5px 6px;font-size:14px}
  .btn{display:block;width:100%;margin:8px 0;padding:11px 0}
  .pwin{width:100%}
  .maskv{width:auto}
  .fbox input[type=text],.fbox input[type=password],.fbox select{width:100%;box-sizing:border-box;margin-bottom:6px}
  .cellstate{display:block;font-size:14px;word-break:break-all}
  .info b{display:block;min-width:0}
  .fbox{padding:10px 12px}
}
/* ==== 频段勾选网格（替代表格，移动端友好） ==== */
.bandgrid{display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;margin:8px 0}
.bandgrid label{display:block;padding:6px 4px;border-radius:4px;cursor:pointer}
.bandgrid label:hover{background:#f0f4f8}
.bandgrid .fdd{color:#333}
.bandgrid .tdd{color:#555}
@media (max-width:640px){
  .bandgrid{grid-template-columns:1fr 1fr;gap:2px 6px}
  .bandgrid label{padding:9px 4px;font-size:15px}
}
</style></head><body>
<h2>蜂助手 S1 CPE 工具箱</h2>
CEOF

cat << 'CEOF'
<script>
var busy=0;
var CELLBTN='';   // ③ 表单当前点击的按钮（lock/apply/clear），决定校验规则
function showWait(msg){
  PAUSED=1;
  if(timer) clearTimeout(timer);
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.55);display:flex;align-items:center;justify-content:center;text-align:center;z-index:9999';
  d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18)"><div class="spinner"></div><p style="font-size:17px;margin:0">'+msg+'</p><p style="font-size:13px;color:#888;margin:8px 0 0">请稍候，完成后自动刷新</p></div>';
  document.body.appendChild(d);
}
function buildNet(f){
  if(!confirm('将应用新的网络设置，期间网络会中断数秒。\n\n如果改动了 WAN 口，网线可能需要换到对应的插孔。\n\n确认应用？')) return false;
  showWait('正在应用网络设置，请稍候…');
  return true;
}
function build(f){
  var low=parseInt(f.low_base.value)||0, high=parseInt(f.high_base.value)||0;
  var nl=low & ~149, nh=high & ~482;
  if(f.b1.checked) nl|=1; if(f.b3.checked) nl|=4;
  if(f.b5.checked) nl|=16; if(f.b8.checked) nl|=128;
  if(f.b34.checked) nh|=2;
  if(f.b38.checked) nh|=32; if(f.b39.checked) nh|=64;
  if(f.b40.checked) nh|=128; if(f.b41.checked) nh|=256;
  if(nl==0 && nh==0){ alert('至少勾选一个频段！'); return false; }
  // 移动卡会优先驻留 TDD 频段；只保留 FDD 时，设备重启后可能反复重启数分钟才能
  // 重新驻网。这里只如实告知，不做任何自动改动（是否接受由用户决定）。
  var fbmsg='';
  if(nh==0 && nl!=0){ fbmsg='\n\n⚠ 注意：移动卡会优先使用 TDD 频段。本次未勾选任何 TDD 频段，只保留 FDD 频段时，设备重启后可能反复重启数分钟才能重新驻网（会自动重试），请耐心等待。\n需要固定使用 FDD 的，建议改用下方 ③ 锁定频点 / 小区。'; }
  f.low.value=''+nl; f.high.value=''+nh;
  if(!confirm('将应用频段：FDD='+nl+' TDD='+nh+'\n\n应用后设备将重新驻网并自动恢复拨号（约1分钟，无需重启）。'+fbmsg+'\n\n若约5分钟后仍无网络，点本页“恢复出厂频段”即可。')) return false;
  DIRTY=0;   // applied: let the boxes follow the module again
  showWait('正在应用频段，请稍候…');
  return true;
}
function waitRestore(msg){
  if(!confirm(msg+'\n\n确认继续？')) return false;
  DIRTY=0;   // the module is being reset to a known value; resume syncing boxes
  showWait(msg);
  return true;
}
function buildCell(f){
  // 三个按钮共用一个表单，校验规则各不相同：解除锁定无需参数；一键锁定由后端读
  // 当前驻留小区，也不依赖输入框；只有"应用以上参数"需要校验 EARFCN/PCI。
  // CELLBTN 用完即清，避免"上次点了哪个按钮"影响这次（如在输入框里按回车提交）。
  var btn=CELLBTN; CELLBTN='';
  if(btn==='clear'){
    if(!confirm('解除频点/小区锁定？\n\n设备将按正常规则重新驻网（约10-60秒）。')) return false;
    showWait('正在解除锁定，请稍候…');
    return true;
  }
  if(btn==='lock'){
    showWait('正在读取当前小区并锁定，请稍候…');
    return true;
  }
  var e=parseInt(f.cearfcn.value)||0;
  var p=(f.cpci.value||'').replace(/\s/g,'');
  if(!e){ alert('请填写频点（EARFCN）；想锁定当前驻留的小区，请点“一键锁定当前”'); return false; }
  if(e<0 || e>65535){ alert('频点数值超范围'); return false; }
  if(p!=='' && (isNaN(parseInt(p)) || parseInt(p)>503)){ alert('PCI 范围为 0-503，留空则锁频点'); return false; }
  var b=earfcnBand(e);
  if(!b) { alert('频点 '+e+' 不在本设备支持的频段范围内\n（支持：B1/B3/B5/B8/B34/B38/B39/B40/B41）'); return false; }
  var kind = (p==='') ? ('锁频点：B'+b+' / EARFCN '+e+'（同频点其他小区可接替）')
                      : ('锁小区：B'+b+' / EARFCN '+e+' / PCI '+p+'（该小区不可用时会无网）');
  var extra = (p==='') ? '' : '\n\n注意：锁小区后若该小区不可用，设备将无网，需点“解除锁定”恢复。';
  if(!confirm('将应用 '+kind+extra+'\n\n应用后设备会重新搜网（约10-60秒），期间短暂无网属正常。\n若 75 秒后仍无网，系统会自动解除锁定。')) return false;
  showWait('正在应用锁定，请稍候…');
  return true;
}
// EARFCN -> 频段（与后端 earfcn_to_band 同一张表，用于前端即时提示）
function earfcnBand(e){
  if(isNaN(e)) return '';
  if(e>=0 && e<=599) return 1;
  if(e>=1200 && e<=1949) return 3;
  if(e>=2400 && e<=2649) return 5;
  if(e>=3450 && e<=3799) return 8;
  if(e>=36200 && e<=36349) return 34;
  if(e>=37750 && e<=38249) return 38;
  if(e>=38250 && e<=38649) return 39;
  if(e>=38650 && e<=39649) return 40;
  if(e>=39650 && e<=41589) return 41;
  return '';
}
// 输入频点时即时显示对应频段（防手滑）。绑定时机见页尾脚本：本块在 <head> 里，
// 此时 ③ 表单尚未出现在 DOM 中，这里只能定义函数。
function bindEarfcnHint(){
  var i=document.getElementById('cearfcn'), h=document.getElementById('cearfcn_hint');
  if(!i || !h) return;
  function upd(){
    var v=parseInt(i.value)||0;
    if(!v){ h.textContent=''; return; }
    var b=earfcnBand(v);
    if(b){ h.textContent='→ 频段 B'+b; h.style.color='#2e7d32'; }
    else { h.textContent='→ 不在支持的频段范围'; h.style.color='#c62828'; }
  }
  i.oninput=upd; i.onchange=upd; upd();
}
var REAL={imei:'',iccid:''}, HID={imei:1,iccid:1};
var EYE_OPEN='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
var EYE_SHUT='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M1 1l22 22"/></svg>';
function dots(n){var s='';while(n-->0)s+='*';return s;}
function maskMid(v){
  v=v||'';
  // ICCIDs may contain hex letters (e.g. 898608461625D0576855), so accept
  // alphanumerics; error text is shown as-is.
  if(!/^[0-9A-Za-z]+$/.test(v)) return v;
  if(v.length<=8) return dots(v.length);
  return v.substr(0,4)+dots(v.length-8)+v.substr(v.length-4);
}
function paint(k){
  var e=document.getElementById(k+'Val');
  if(e) e.textContent=HID[k]?maskMid(REAL[k]):(REAL[k]||'');
  var b=document.getElementById('eye_'+k);
  if(b) b.innerHTML=HID[k]?EYE_OPEN:EYE_SHUT;
}
function tog(k){HID[k]=HID[k]?0:1;paint(k);}
// Both value boxes are set to one shared width, measured from the widest real
// value actually present.  This keeps the two eye icons in a single fixed
// column and stops them shifting when a value is shown or hidden, without
// relying on any particular glyph being monospaced.
function fitMask(){
  var im=document.getElementById('imeiVal'), ic=document.getElementById('iccidVal');
  if(!im||!ic) return;
  var probe=document.createElement('span');
  probe.style.cssText='position:absolute;visibility:hidden;white-space:pre;font-family:monospace;letter-spacing:1px';
  document.body.appendChild(probe);
  var w=0;
  [REAL.imei,REAL.iccid].forEach(function(v){
    probe.textContent=v||'';
    if(probe.offsetWidth>w) w=probe.offsetWidth;
  });
  document.body.removeChild(probe);
  if(w<60) w=60;
  im.style.width=(w+2)+'px';
  ic.style.width=(w+2)+'px';
}
var AUTO_MS=6000;      // 自动刷新间隔
var PAUSED=0;        // 频段操作期间暂停
var PENDING=0;       // 手动刷新撞上正在进行的读取时，读完立刻补一次
var DIRTY=0;         // 用户改过频段勾选、还没应用（自动刷新期间不清空）
var timer=null;
var RETRY=0;         // 连续重试次数
var MAX_RETRY=5;     // 重试上限（防止无限转圈）
var REQ_TIMEOUT=15000;  // 单次请求硬超时（毫秒）
function setSpin(on){
  var b=document.getElementById('rfbtn');
  if(!b) return;
  if(on) b.className='refresh spin'; else b.className='refresh';
}
function setNote(msg){
  var n=document.getElementById('rfnote');
  if(n) n.innerHTML=msg||'';
}
// Every terminal path goes through finish(), so the spinner can never be left
// turning.  This is the guarantee the old code lacked.
function finish(){
  busy=0; RETRY=0; setSpin(0); setNote(''); next();
}
// Bounded retry.  The vendor app polls the same AT port every 20s, so a read can
// lose the lock; retry a few times, then give up and release the spinner instead
// of spinning forever.
function again(){
  busy=0;
  RETRY++;
  if(RETRY>MAX_RETRY){
    RETRY=0; setSpin(0);
    setNote('<span style="color:#b26a00">设备持续忙碌，已停止重试；稍后再点刷新</span>');
    next();
    return;
  }
  setNote('<span style="color:#b26a00">设备忙碌，重试中 '+RETRY+'/'+MAX_RETRY+'…</span>');
  if(timer) clearTimeout(timer);
  timer=setTimeout(function(){ loadAll(0,1); },1500);
}
function schedule(){
  if(timer) clearTimeout(timer);
  if(PAUSED) return;
  timer=setTimeout(function(){ loadAll(1); }, AUTO_MS);
}
// End-of-request router: a click that arrived mid-read is honoured first,
// otherwise just queue the next automatic tick.
function next(){
  if(PENDING){ PENDING=0; loadAll(0,1); return; }
  schedule();
}
// 密码表单前端校验
function checkPw(f){
  var a=f.pw1.value, b=f.pw2.value, tip=document.getElementById('pwtip');
  if(f.pw0 && !f.pw0.value){ tip.className='pwmsg pwerr'; tip.textContent='请输入当前密码'; return false; }
  if(!a){ tip.className='pwmsg pwerr'; tip.textContent='请输入新密码'; return false; }
  if(a.length<8){ tip.className='pwmsg pwerr'; tip.textContent='密码至少 8 位'; return false; }
  if(a!==b){ tip.className='pwmsg pwerr'; tip.textContent='两次输入的密码不一致'; return false; }
  tip.className='pwmsg pwok'; tip.textContent='提交中…';
  return true;
}
function manualRefresh(){
  if(timer) clearTimeout(timer);
  // A manual click must always end in a real AT read, never in cached data.
  // If a read is already in flight, remember the click and re-run when it lands.
  if(busy){ PENDING=1; return; }
  loadAll(0,1);
}
// 页面切到后台就停，切回来立刻刷一次
document.addEventListener('visibilitychange',function(){
  if(document.hidden){ if(timer) clearTimeout(timer); }
  else { if(!busy) loadAll(1); }
});
function loadAll(silent,force){
  if(busy) return;
  busy=1;
  setSpin(1);
  var spinAt=Date.now();
  var e=document.getElementById('info');
  // Never blank the panel: clearing it shrinks the box and makes the whole page
  // jump.  The spinner already signals activity, so keep the previous readings
  // on screen until the new ones arrive.  Only the very first load, when there
  // is nothing to show yet, uses the placeholder text.
  if(!e.innerHTML || e.innerHTML.indexOf('info-empty')>=0){
    e.innerHTML='<span class=info-empty>正在读取设备数据，请稍候…</span>';
  }
  var x=new XMLHttpRequest();
  // Without a timeout, a stalled server leaves readyState below 4 forever, which
  // pins busy=1 and silently swallows every later click.
  try{ x.timeout=REQ_TIMEOUT; }catch(err){}
  var handled=0;
  function fail(){
    // Fires on timeout / network error.  Guarded so it cannot double-run with
    // the readyState handler.
    if(handled) return;
    handled=1;
    if(force){ again(); } else { finish(); }
  }
  x.ontimeout=fail;
  x.onerror=fail;
  x.onreadystatechange=function(){
    if(x.readyState==4){
      if(handled) return;
      handled=1;
      // A cache hit returns in ~0ms; hold the spinner briefly so the click still
      // registers visually instead of flashing for a single frame.
      var hold=Math.max(0,450-(Date.now()-spinAt));
      setTimeout(function(){
      // The spinner is stopped only at a terminal outcome below, so a forced read
      // that has to wait for the throttle window or the AT lock keeps turning.
      var t=(x.responseText||'').trim();
      if(t=='BUSY'){
        // Module busy: keep what is displayed and retry (bounded).
        if(force){ again(); } else { finish(); }
        return;
      }
      if(x.status==200 && t.indexOf('BANDVAL=')>=0){
        var d={};
        t.split('\n').forEach(function(l){
          var p=l.indexOf('=');
          if(p>0) d[l.substring(0,p)]=l.substring(p+1);
        });
        // A forced read that lost the AT lock comes back as the previous cache
        // with CACHED=-1.  Retry (bounded) rather than presenting stale data.
        if(force && d.CACHED=='-1'){ again(); return; }
        var h='';
        if(d.DUPLEX!='?' && d.BAND!='?') h+='<b>当前驻网：</b>LTE '+d.DUPLEX+' 频段 B'+d.BAND+'<br>';
        else h+='<b>当前驻网：</b>未驻网（设备重启中或搜网中）<br>';
        var csq=parseInt(d.CSQ)||0;
        var rsrp=(d.RSRP&&d.RSRP!='?')?parseInt(d.RSRP):null;
        var q,lvl,dbm;
        if(rsrp!==null&&!isNaN(rsrp)){
          dbm='（RSRP '+rsrp+' dBm）';
          if(rsrp>=-85){q='很强';lvl=4;}
          else if(rsrp>=-95){q='良好';lvl=3;}
          else if(rsrp>=-105){q='一般';lvl=2;}
          else{q='较弱';lvl=1;}
        }else if(d.CSQ=='?'){
          q='未知';lvl=0;dbm='';
        }else{
          dbm='（约 '+(2*csq-113)+' dBm）';
          if(csq>=26){q='很强';lvl=4;}
          else if(csq>=18){q='良好';lvl=3;}
          else if(csq>=10){q='一般';lvl=2;}
          else{q='较弱';lvl=1;}
        }
        var bt='';
        for(var bi=1;bi<=4;bi++){
          var col=bi<=lvl?'#4caf50':'#ddd';
          var hh=6+bi*4;
          bt+='<span style="display:inline-block;width:5px;height:'+hh+'px;background:'+col+';margin-right:2px;vertical-align:bottom;border-radius:1px"></span>';
        }
        h+='<b>信号强度：</b>'+bt+' <span style="vertical-align:bottom">'+q+' '+dbm+'</span><br>';
        if(d.OPER) h+='<b>运营商：</b>'+d.OPER+'<br>';
        REAL.imei=d.IMEI||''; REAL.iccid=d.ICCID||'';
        h+='<b>IMEI：</b><span class=maskv id="imeiVal"></span><span class=eye id="eye_imei" onclick="tog(\'imei\')" title="显示 / 隐藏"></span><br>';
        h+='<b>ICCID：</b><span class=maskv id="iccidVal"></span><span class=eye id="eye_iccid" onclick="tog(\'iccid\')" title="显示 / 隐藏"></span><br>';
        // Only the timestamp is shown.  With a short auto-refresh interval there
        // is no need to explain caching to the user any more.  The label says
        // "read time" rather than "updated", because the time now stays put while
        // the panel is served from cache.
        h+='<span class=stamp>数据读取时间 '+d.STAMP+'</span>';
        e.innerHTML=h;
        // paint() must run AFTER the innerHTML above, otherwise the target
        // spans do not exist yet and the fields render blank.
        fitMask(); paint('imei'); paint('iccid');
        // Rendering must never return early: an early return here would skip
        // finish() and leave the spinner turning forever.  Wrap it in try/catch
        // so a DOM surprise cannot strand the button either.
        try{
          if(d.BANDVAL!='READFAIL'){
            var b=d.BANDVAL.split(',');
            var low=parseInt(b[4])||0, high=parseInt(b[3])||0;
            var f=document.getElementById('bandform');
            // Don't overwrite the user's in-progress selection.  The panel
            // auto-refreshes every few seconds, and repainting the checkboxes
            // from the module's live value would silently undo ticks the user
            // just made but has not applied yet.  Once they touch a box we stop
            // syncing the boxes (the "current band" line above still updates),
            // and normal syncing resumes after they apply or reset.
            if(f && !DIRTY){
              f.b1.checked=!!(low&1); f.b3.checked=!!(low&4);
              f.b5.checked=!!(low&16); f.b8.checked=!!(low&128);
              f.b34.checked=!!(high&2); f.b38.checked=!!(high&32);
              f.b39.checked=!!(high&64); f.b40.checked=!!(high&128); f.b41.checked=!!(high&256);
              f.low_base.value=low; f.high_base.value=high;
              f.low.value=low; f.high.value=high;
            }
            var c=document.getElementById('cur');
            if(c) c.innerHTML=d.HUMAN+(DIRTY?'<br><span style="color:#b26a00">已修改勾选，点下方“应用勾选”生效（自动刷新不会覆盖你的选择）</span>':'');
            var fo=document.getElementById('followstat');
            if(fo){
              var fv=(d.FOLLOW||'');
              if(fv==''){ fo.style.display='none'; fo.innerHTML=''; }
              else{
                fo.style.display='';
                fo.innerHTML = fv=='RUN' ? '⏳ 正在重新驻网并恢复拨号（严格锁定 TDD=0 时设备可能挣扎数分钟，会自动重试，请耐心等待）…'
                             : (fv=='1' ? '✓ 频段已应用，网络已恢复上网'
                             : '✗ 暂未自动恢复拨号：设备可能仍在挣扎驻网（稍后可能自行恢复）；或再点一次“应用勾选”、点“恢复出厂频段”、重启设备');
              }
            }
          } else {
            var c2=document.getElementById('cur');
            if(c2) c2.innerHTML='当前状态：读取失败（设备忙/重启中）— 不影响下方操作';
          }
          // ③ 锁定频点/小区：实时更新"当前驻留"，并在用户没动过输入框时预填
          var cc=document.getElementById('cellcur');
          if(cc){
            if(d.BAND && d.BAND!='?'){
              cc.textContent='B'+d.BAND+' / EARFCN '+(d.CELLEARFCN||'?')+' / PCI '+(d.CELLPCI||'?');
            }else{
              cc.textContent='未驻网（设备搜网中）';
            }
          }
          // 预填：仅当输入框为空且用户未手动改过（避免打断用户输入）
          var ine=document.getElementById('cearfcn'), inp=document.getElementById('cpci');
          if(ine && !ine.value && d.CELLEARFCN) ine.value=d.CELLEARFCN;
          if(inp && !inp.value && d.CELLPCI) inp.value=d.CELLPCI;
        }catch(err){}
        // No return here: control falls through to the finish() below, which
        // releases the spinner and schedules the next round exactly once.
      } else if(!silent){
        e.innerHTML='读取失败（设备忙/重启中），可点刷新重试';
      }
      // The success path already ended in finish(); this covers the non-200 /
      // malformed-response branch so no path can leave the spinner turning.
      finish();
      }, hold);
    }
  };
  x.open('GET','?a=data'+(force?'&force=1':''),true);
  x.send();
}
</script>
CEOF

echo "<div class='info' id='info'><span class=info-empty>正在读取设备数据，请稍候…</span></div>"
echo "<p><button class=refresh id=rfbtn type=button onclick='manualRefresh()' title='立即刷新'>"
echo "<svg width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\"><path d=\"M21 12a9 9 0 1 1-2.64-6.36\"/><path d=\"M21 3v6h-6\"/></svg>"
echo " 刷新</button><span class=auto>每 $((AUTO_SEC)) 秒自动刷新</span>"
echo "<span class=auto id=rfnote></span></p>"
echo "<p class=note>信号强度参考：-80 很好、-95 良好、-105 一般、-110 以下较弱。</p>"

echo "<h3>① IMEI 改串</h3>"
if [ -n "$IMEI_RESULT" ]; then
  if [ -n "$IMEI_RESULT_OK" ]; then
    echo "<div class='msg ok'>$IMEI_RESULT</div>"
  else
    echo "<div class='msg err'>$IMEI_RESULT</div>"
  fi
fi
if [ -n "$PENDING_IMEI" ]; then
  echo "<div class='msg ok'>待应用的新 IMEI：<b>$PENDING_IMEI</b><br>点下方按钮重启设备，重启后自动写入生效。<br><span style='color:#c62828'>改串重启比平常久，约需 2-3 分钟，请耐心等待。</span></div>"
  echo "<form method=POST action='?a=band' onsubmit=\"return rebootOnly()\">"
  echo "<button class=btn type=submit name=reboot value='1'>立即重启设备生效</button>"
  echo "</form>"
fi
cat << 'IEOF'
<script>
function luhnCheck(s){
  var sum=0, dbl=false;
  for(var i=s.length-1;i>=0;i--){
    var d=parseInt(s.charAt(i),10);
    if(isNaN(d)) return false;
    if(dbl){ d*=2; if(d>9) d-=9; }
    sum+=d; dbl=!dbl;
  }
  return sum%10===0;
}
function luhnFix(s14){
  var sum=0, dbl=true;
  for(var i=s14.length-1;i>=0;i--){
    var d=parseInt(s14.charAt(i),10);
    if(dbl){ d*=2; if(d>9) d-=9; }
    sum+=d; dbl=!dbl;
  }
  var c=(10-(sum%10))%10;
  return s14+''+c;
}
function buildImei(f){
  var raw=f.imei.value.replace(/[^0-9]/g,'');
  var v=raw;
  if(v.length==14){
    var fixed=luhnFix(v);
    if(!confirm('你输入了 14 位数字，已自动补全校验位：\n\n  '+v+'  →  '+fixed+'\n\n使用这个 IMEI 吗？')){
      return false;
    }
    v=fixed;
  } else if(!/^[0-9]{15}$/.test(v)){
    alert('IMEI 格式不对：需要 15 位数字（当前 '+v.length+' 位）');
    return false;
  } else if(!luhnCheck(v)){
    var fixed15=luhnFix(v.substring(0,14));
    if(confirm('这个 IMEI 的校验位不合法，设备会拒绝写入！\n\n  你的输入：'+v+'\n  建议修正：'+fixed15+'\n\n使用修正后的值吗？\n（如果确定原始值没错，请点"取消"并重新核对）')){
      v=fixed15;
    } else {
      return false;
    }
  }
  f.imei.value=v;
  if(confirm('将 IMEI 改为：'+v+'\n\n是否立即重启设备生效？\n（注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待）')){
    f.reboot.value='1';
    var d=document.createElement('div');
    d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999';
    d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0">正在保存并重启设备…</p></div>';
    document.body.appendChild(d);
  } else {
    f.reboot.value='';
  }
  return true;
}
function rebootOnly(){
  if(!confirm('设备将立即重启，重启时自动把新 IMEI 写入。\n\n注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待。\n\n确认重启？')) return false;
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999';
  d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0">正在重启设备…</p></div>';
  document.body.appendChild(d);
  return true;
}
</script>
<form method=POST action="?a=band" onsubmit="return buildImei(this)">
<input type=hidden name=reboot value=''>
<div class=fbox>
<p style="margin:0">新 IMEI：<input class=imeiin type=text name=imei maxlength=20 size=20 placeholder="15位数字" autocomplete=on> <input class=btn type=submit value='保存'></p>
</div>
</form>
<p class=note>点保存后会校验 IMEI 合法性（含校验位），可自动修正；确认后询问是否立即重启生效。</p>
<p class=note style="color:#c62828">改串后的重启比平常久（约 2-3 分钟），请耐心等待。</p>
IEOF
echo "<hr>"
echo "<h3>② 锁频段</h3>"
if [ -n "$RESULT" ]; then
  if [ -n "$RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $RESULT</div>"
  else
    echo "<div class='msg err'>✗ $RESULT</div>"
  fi
fi
echo "<p id=cur style='color:#555;margin:14px 0 6px'>$CURTEXT</p>"
echo "<form id='bandform' method=POST action='?a=band' onsubmit='return build(this)'>"
echo "<input type=hidden name=low_base value='$RLOW'>"
echo "<input type=hidden name=high_base value='$RHIGH'>"
echo "<input type=hidden name=low value='$RLOW'>"
echo "<input type=hidden name=high value='$RHIGH'>"
cat << CEOF
<div class=fbox>
<div class=bandgrid>
<label class=fdd><input type=checkbox name=b1 $B1> B1 (2100M)</label>
<label class=tdd><input type=checkbox name=b34 $B34> B34 (2000M)</label>
<label class=fdd><input type=checkbox name=b3 $B3> B3 (1800M)</label>
<label class=tdd><input type=checkbox name=b38 $B38> B38 (1900M)</label>
<label class=fdd><input type=checkbox name=b5 $B5> B5 (850M)</label>
<label class=tdd><input type=checkbox name=b39 $B39> B39 (1900M)</label>
<label class=fdd><input type=checkbox name=b8 $B8> B8 (900M)</label>
<label class=tdd><input type=checkbox name=b40 $B40> B40 (2300M)</label>
<label class=tdd><input type=checkbox name=b41 $B41> B41 (2500M)</label>
</div>
<p style="margin:10px 0 0"><input class=btn type=submit value='应用勾选'></p>
</div>
</form>
<div id=followstat class=note style="display:none;margin:10px 0 0"></div>
<p class=note>点“应用勾选”后设备会重新驻网并自动恢复拨号（约1分钟，无需重启）；想立即看结果可点上方“刷新数据”。</p>
<p class=note style="color:#666">锁频段只限定“允许使用哪些频段”，实际优先驻留哪个频段由运营商网络策略决定。
移动卡会优先使用 TDD 频段，如果只保留 FDD 频段，设备重启后可能反复重启数分钟才能重新驻网。
想让设备固定在某个<b>频点或小区</b>上（例如锁定 FDD），请用下方 <b>③ 锁定频点 / 小区</b>。</p>
<p style="color:#666;margin:16px 0 6px;font-size:14px">锁频段后一直无网？可以恢复到已知可用的频段（任何时候都能点）：</p>
<form method=POST action="?a=band" style="display:inline" onsubmit="return waitRestore('正在恢复出厂频段…')">
<input class=btn type=submit name=restore value='恢复出厂频段'>
</form>
CEOF

if [ -n "$HASBAK" ]; then
  echo "<form method=POST action='?a=band' style='display:inline' onsubmit=\"return waitRestore('正在恢复上次频段…')\">"
  echo "<input class=btn type=submit name=restore_bak value='恢复上次频段'>"
  echo "</form>"
fi

echo "<hr>"
echo "<h3>③ 锁定频点 / 小区</h3>"
echo "<p>将设备锁定在指定的<b>频点或小区</b>上，保持固定使用。</p>"
if [ -n "$CELL_RESULT" ]; then
  if [ -n "$CELL_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $CELL_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $CELL_RESULT</div>"
  fi
fi
echo "<div class=fbox>"
echo "<div class=row>当前驻留：<span class=cellstate id=cellcur>$CELL_CUR</span></div>"
echo "<div class=row>当前锁定：<span class=cellstate id=celllock>$CELL_LOCK</span></div>"
echo "<form method=POST action='?a=cell' onsubmit=\"return buildCell(this)\">"
echo "<div class=row><input class=btn type=submit name=cell_lock value='一键锁定当前' onclick=\"CELLBTN='lock'\"></div>"
echo "<p class=sub style='margin:4px 0 0'>自动识别并锁定当前驻留的频点与小区（推荐）</p>"
echo "<div class=sep></div>"
echo "<p class=sub style='margin:0 0 6px'>或手动指定：</p>"
echo "<div class=row>频点(EARFCN) <input type=text name=cearfcn id=cearfcn value='$CELL_EARFCN' maxlength=7 autocomplete=on placeholder='如 1300'>"
echo " <span class=note id=cearfcn_hint style='display:inline'></span></div>"
echo "<div class=row>PCI <input type=text name=cpci id=cpci value='$CELL_PCI' maxlength=3 placeholder='选填' autocomplete=on>"
echo " <span class=note style='display:inline'>（留空 = 锁频点；填写 = 锁小区）</span></div>"
echo "<div class=row><input class=btn type=submit name=cell_apply value='应用以上参数' onclick=\"CELLBTN='apply'\"> <input class=btn type=submit name=cell_clear value='解除锁定' onclick=\"CELLBTN='clear'\"></div>"
echo "</form>"
echo "</div>"
echo "<p class=note style='margin:8px 0 0'>· <b>只填频点</b>：锁定该频点，同频点其他小区可接替，较稳定<br>"
echo "· <b>频点 + PCI</b>：精确锁定某个小区，该小区不可用时设备将无网<br>"
echo "· 应用后设备会重新搜网（约 10-60 秒），期间短暂无网属正常；若 75 秒后仍无网会自动解除</p>"
echo "<p class=note style='color:#999'>与 ② 锁频段相互独立，可同时使用。</p>"

echo "<hr>"
echo "<h3>④ 网口与上网优先级</h3>"
echo "<p>把三个网口之一设为有线 WAN（也可以全部保持 LAN，仅用 4G 上网），并选择 4G 与有线之间的上网优先级。</p>"
if [ -n "$NET_RESULT" ]; then
  if [ -n "$NET_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $NET_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $NET_RESULT</div>"
  fi
fi
echo "<form method=POST action='?a=net' onsubmit=\"return buildNet(this)\">"
echo "<div class=fbox>"
echo "<p class=sub style='margin:0 0 8px'><b>有线 WAN 口</b>：点选要插网线的口（点谁谁亮，与设备背面丝印一致）：</p>"
echo "<div class=portstrip>"
echo "<label class=port><input type=radio name=net_port value=p2 $NP2><span class=jack><i></i></span><span class=plabel>LAN2</span><span class=rlan>LAN</span><span class=rwan>WAN</span></label>"
echo "<label class=port><input type=radio name=net_port value=p1 $NP1><span class=jack><i></i></span><span class=plabel>LAN1</span><span class=rlan>LAN</span><span class=rwan>WAN</span></label>"
echo "<label class=port><input type=radio name=net_port value=p0 $NP0><span class=jack><i></i></span><span class=plabel>LAN0</span><span class=rlan>LAN</span><span class=rwan>WAN</span></label>"
echo "<label style=display:none><input type=radio name=net_port value=all $NALL></label>"
echo "</div>"
echo "<p class=note style='margin:4px 0 0'>· 点亮的口再点一次可熄灭：全部熄灭 = 三个口都是 LAN（仅 4G 上网，无法插网线）</p>"
echo "<div class=sep></div>"
echo "<p class=sub style='margin:0 0 6px'><b>上网优先级</b>：</p>"
echo "<div class=row><label><input type=radio name=net_mode value=4g $NM4> 4G 优先（出厂默认，插网线仅作备用）</label></div>"
echo "<div class=row><label><input type=radio name=net_mode value=wan $NMW> 有线优先（插网线走网线，拔线自动回 4G）</label></div>"
echo "<div class=row><label><input type=radio name=net_mode value=only4g $NM4G> 仅 4G（有线口停用）</label></div>"
echo "<div class=row><label><input type=radio name=net_mode value=onlywan $NMWG> 仅 有线（4G 停止上网；请先确认网线已插好且能上网）</label></div>"
echo "<p style='margin:10px 0 0'><input class=btn type=submit value='应用网络设置'></p>"
echo "</div>"
echo "</form>"
echo "<p class=note style='margin:8px 0 0'>· 上图的排列方向与设备背面一致：面对背面时，LAN0 在最右边<br>"
echo "· 应用时网络会中断数秒，页面恢复后即可继续操作<br>"
echo "· 选“仅 有线”前请确认网线已插好且能上网，否则设备将无法上网（可随时改回）<br>"
echo "· 4G 拨号始终保持在线，切换优先级不影响锁频段、锁频点等功能</p>"
echo "<script>"
echo "(function(){"
echo "  var pr=document.getElementsByName('net_port');"
echo "  var pm=document.getElementsByName('net_mode');"
echo "  var last=null;"
echo "  for(var i=0;i<pr.length;i++){ if(pr[i].checked) last=pr[i]; }"
echo "  function setPort(v){ for(var j=0;j<pr.length;j++){ if(pr[j].value===v) pr[j].checked=true; } }"
echo "  function curPort(){ for(var j=0;j<pr.length;j++){ if(pr[j].checked) return pr[j].value; } return 'p0'; }"
echo "  function syncPrio(){"
echo "    var allOn=(curPort()==='all');"
echo "    for(var j=0;j<pm.length;j++){"
echo "      if(pm[j].value==='wan'||pm[j].value==='onlywan'){"
echo "        pm[j].disabled=allOn;"
echo "        if(allOn && pm[j].checked){ for(var k=0;k<pm.length;k++){ if(pm[k].value==='4g') pm[k].checked=true; } }"
echo "      }"
echo "    }"
echo "  }"
echo "  for(var i=0;i<pr.length;i++){"
echo "    pr[i].onclick=function(){"
echo "      if(this===last){ this.checked=false; setPort('all'); last=null; }"
echo "      else { last=this; }"
echo "      syncPrio();"
echo "    };"
echo "  }"
echo "  for(var i=0;i<pm.length;i++){ pm[i].onclick=syncPrio; }"
echo "  syncPrio();"
echo "})();"
echo "</script>"

echo "<hr>"
echo "<h3>⑤ 管理后台密码</h3>"
echo "<p>本设备内置 <b>OpenWrt 管理后台</b>（端口 8888），可配置网口、无线、防火墙等更多功能。"
echo "设置一个密码后，即可用 <b>root</b> + 该密码登录："
echo "<br><a href=\"http://192.168.1.1:8888\" target=\"_blank\">http://192.168.1.1:8888</a></p>"
# 结果提示紧贴表单，避免用户看不到
if [ -n "$PW_RESULT" ]; then
  if [ -n "$PW_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $PW_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $PW_RESULT</div>"
  fi
fi
echo "<form method=POST action='?a=pw' onsubmit=\"return checkPw(this)\">"
echo "<div class=fbox><table>"
if [ -n "$PW_USER_SET" ]; then
  echo "<tr><td>当前密码</td><td><input class=pwin type=password name=pw0 id=pw0 maxlength=64 autocomplete=current-password></td></tr>"
fi
echo "<tr><td>新密码</td><td><input class=pwin type=password name=pw1 id=pw1 maxlength=64 autocomplete=new-password></td></tr>"
echo "<tr><td>确认密码</td><td><input class=pwin type=password name=pw2 id=pw2 maxlength=64 autocomplete=new-password></td></tr>"
echo "<tr><td></td><td><button class=btn type=submit>设置密码</button>"
echo "<span class=pwmsg id=pwtip></span></td></tr>"
echo "</table></div>"
echo "</form>"
if [ -n "$PW_USER_SET" ]; then
  echo "<p class=note>修改密码需要先输入当前密码。"
  echo "<br>忘记当前密码时，可通过「系统命令行」执行 <code>passwd -d root</code> 清除后回到本页重设。</p>"
else
  echo "<p class=note>要求：至少 8 位。设置后修改需要先输入当前密码。</p>"
fi

# Mark the band checkboxes as user-modified.  The panel repaints them from the
# module on every auto-refresh; without this the ticks a user makes are wiped
# before they can press "apply".  Applying or resetting clears the flag again.
echo "<script>(function(){var f=document.getElementById('bandform');if(!f)return;"
echo "function mark(){DIRTY=1;var c=document.getElementById('cur');"
echo "if(c&&c.innerHTML.indexOf('已修改勾选')<0)c.innerHTML+='<br><span style=\"color:#b26a00\">已修改勾选，点下方“应用勾选”生效（自动刷新不会覆盖你的选择）</span>';}"
echo "var ns=['b1','b3','b5','b8','b34','b38','b39','b40','b41'];"
echo "for(var i=0;i<ns.length;i++){if(f[ns[i]])f[ns[i]].onchange=mark;}})();</script>"

# 首次加载显示"正在读取"，之后由 schedule() 静默轮询
echo "<script>bindEarfcnHint();setTimeout(function(){loadAll(0);},300);</script>"
echo "</body></html>"
