#!/bin/sh
# toolbox.cgi - decloud edition v6
# single AJAX endpoint (one microcom session), at-port mutex, single auto-refresh
FACTORY_BAND="12,78,145,482,149,0,2,2"
AUTO_SEC=6
BACKUP=/etc/band_backup

at_port(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in *1.1:1.4*) echo "${t##*/}"; return;; esac
  done
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in
      *:1.4*)
        PP=${t##*/}
        at_clearlock "$PP"
        R=$( (echo -e 'ATI
'; sleep 1) | microcom -t 1500 -s 115200 /dev/$PP 2>/dev/null )
        at_clearlock "$PP"
        case "$R" in *EC200T*) echo "$PP"; return;; esac;;
    esac
  done
}
at_lock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    if [ -n "$LP" ] && kill -0 $LP 2>/dev/null; then
      i=0
      while [ $i -lt 12 ]; do
        LP=$(cat /tmp/at_busy.lock 2>/dev/null)
        kill -0 $LP 2>/dev/null || break
        sleep 1
        i=$((i+1))
      done
    fi
  fi
  echo $$ > /tmp/at_busy.lock
}
at_unlock(){ rm -f /tmp/at_busy.lock; }

# ---------- ④ 网口与上网优先级：辅助 ----------
# "仅 有线"模式：4G 保持拨号（拨号守卫无感知），只在防火墙拦断其转发/出站。
# 规则同步写入 /etc/firewall.user（fw3 reload / 重启后自动恢复）。
net_block(){
  if ! iptables -C FORWARD -o usb1 -j REJECT 2>/dev/null; then
    iptables -I FORWARD 1 -o usb1 -j REJECT
  fi
  if ! iptables -C OUTPUT -o usb1 -j REJECT 2>/dev/null; then
    iptables -I OUTPUT 1 -o usb1 -j REJECT
  fi
  if ! grep -q 'toolbox net-onlywan' /etc/firewall.user 2>/dev/null; then
    printf '%s\n' '# toolbox net-onlywan (managed block)' \
      'iptables -I FORWARD 1 -o usb1 -j REJECT' \
      'iptables -I OUTPUT 1 -o usb1 -j REJECT' >> /etc/firewall.user
  fi
}
net_unblock(){
  iptables -D FORWARD -o usb1 -j REJECT 2>/dev/null
  iptables -D OUTPUT -o usb1 -j REJECT 2>/dev/null
  # busybox sed 不支持 /re/,+2d，按行匹配逐条删除
  sed -i '/toolbox net-onlywan/d;/^iptables -I FORWARD 1 -o usb1 -j REJECT$/d;/^iptables -I OUTPUT 1 -o usb1 -j REJECT$/d' /etc/firewall.user 2>/dev/null
}
# 厂商 udhcpc 脚本在 WAN 租约到达时会加 metric0 的 WAN 默认路由并删光其他默认路由
# （路由谋杀之二）。官方扩展点 /etc/udhcpc.user 在每次 DHCP 事件后被 source——在此按
# 工具箱当前模式校正：metric5 模式补 WAN(m5)+4G(m10) 双默认，出厂模式不动（保持 v19.6 行为）。
net_udhcpc_hook(){
  cat > /etc/udhcpc.user << 'UEOF'
# toolbox net-mode guard: sourced by udhcpc script after every DHCP event
[ "$interface" = "eth0.2" ] || exit 0
M=$(uci -q get network.wan.metric 2>/dev/null); [ -z "$M" ] && M=30
A=$(uci -q get network.wan.auto 2>/dev/null); [ -z "$A" ] && A=1
G4=$(ip route show table 102 2>/dev/null | awk '/^default/{print $3; exit}')
if [ "$1" = "deconfig" ]; then
  route del default dev eth0.2 2>/dev/null
  [ "$M" = "5" ] && [ -n "$G4" ] && route add default gw $G4 dev usb1 metric 10 2>/dev/null
  exit 0
fi
if [ "$M" = "5" ]; then
  [ -n "$router" ] && route add default gw $router dev $interface metric 5 2>/dev/null
  [ -n "$G4" ] && route add default gw $G4 dev usb1 metric 10 2>/dev/null
else
  route del default dev eth0.2 2>/dev/null
  [ -n "$G4" ] && route add default gw $G4 dev usb1 metric 10 2>/dev/null
fi
exit 0
UEOF
}
net_port_human(){
  case "$1" in
    p1) echo "LAN1 作 WAN";;
    p2) echo "LAN2 作 WAN";;
    all) echo "全部 LAN（不做有线 WAN）";;
    *)  echo "LAN0 作 WAN（出厂默认）";;
  esac
}
net_mode_human(){
  case "$1" in
    wan) echo "有线优先";;
    only4g) echo "仅 4G";;
    onlywan) echo "仅 有线";;
    *) echo "4G 优先";;
  esac
}
# microcom creates /var/lock/LCK..ttyUSBn and removes it on a clean exit.  If the
# process is killed (our watchdog does exactly that) the lock is left behind and
# every later open fails with "File exists" -- the module looks dead even though
# it is fine.  Clear the lock when its owner is gone.  Called before and after
# each microcom run so a stale lock can never wedge the AT port permanently.
at_clearlock(){
  L=/var/lock/LCK..$1
  [ -f "$L" ] || return 0
  LP=$(cat "$L" 2>/dev/null | tr -d '\0\r\n ')
  case "$LP" in
    ''|*[!0-9]*) rm -f "$L"; return 0 ;;
  esac
  kill -0 "$LP" 2>/dev/null || rm -f "$L"
}
at_trylock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    [ -n "$LP" ] && kill -0 $LP 2>/dev/null && return 1
  fi
  echo $$ > /tmp/at_busy.lock
  return 0
}

# 换频段后的后台收尾：等模组重新驻网 -> 补一次拨号（固件自己不重拨）-> 验证上网。
# 全程不动电源、不重启模组；固件的 AT 轮询与页面刷新照常，本脚本与其共用
# /tmp/at_busy.lock 串行化。状态写 /tmp/band_follow（RUN/1/0），页脚 4 分钟后自清。
band_follow_launch(){
  if [ -f /tmp/band_follow.pid ]; then
    FP=$(cat /tmp/band_follow.pid 2>/dev/null)
    kill -0 "$FP" 2>/dev/null && return 0
  fi
  cat > /tmp/band_follow.sh << 'FEOF'
#!/bin/sh
echo RUN > /tmp/band_follow
atc(){
  at_clearlock(){
    L=/var/lock/LCK..$1
    [ -f "$L" ] || return 0
    LP=$(cat "$L" 2>/dev/null | tr -d '\0\r\n ')
    case "$LP" in ''|*[!0-9]*) rm -f "$L"; return 0;; esac
    kill -0 "$LP" 2>/dev/null || rm -f "$L"
  }
  at_clearlock "$1"
  O=/tmp/atc_bf.txt; rm -f $O
  ( (echo -e "$2\r"; sleep 1) | microcom -t 1500 -s 115200 /dev/$1 > $O 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  R=$(cat $O 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  rm -f $O
  at_clearlock "$1"
  echo "$R"
}
findport(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t 2>/dev/null)
    case "$p" in */1-1.1/1-1.1:1.4/*) echo "${t##*/}"; return 0;; esac
  done
  return 1
}
lock(){ echo $$ > /tmp/at_busy.lock; }
unlock(){ rm -f /tmp/at_busy.lock; }
busy(){ [ -f /tmp/at_busy.lock ] && { LP=$(cat /tmp/at_busy.lock 2>/dev/null); [ -n "$LP" ] && kill -0 $LP 2>/dev/null && return 0; }; return 1; }
T0=$(cut -d. -f1 /proc/uptime)
REG=0
# 420s：严格 TDD=0 锁定时模组可能挣扎数分钟（模组固件已知缺陷，软恢复无害），多等
while [ $(( $(cut -d. -f1 /proc/uptime) - T0 )) -lt 420 ]; do
  P=$(findport) || { sleep 3; continue; }
  if ! busy; then
    lock
    R=$(atc "$P" 'AT+CEREG?')
    unlock
    case "$R" in *": 0,1"*|*": 2,1"*) REG=1; break;; esac
  fi
  sleep 4
done
if [ $REG -eq 0 ]; then
  echo 0 > /tmp/band_follow
  sleep 240; rm -f /tmp/band_follow /tmp/band_follow.pid
  exit 1
fi
sleep 3
P=$(findport)
if [ -n "$P" ] && ! busy; then
  lock
  atc "$P" 'AT+QNETDEVCTL=1,1'
  unlock
fi
T1=$(cut -d. -f1 /proc/uptime)
OK=0
while [ $(( $(cut -d. -f1 /proc/uptime) - T1 )) -lt 60 ]; do
  if ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; then OK=1; break; fi
  sleep 5
done
if [ $OK -eq 0 ]; then
  sleep 10
  P=$(findport)
  if [ -n "$P" ] && ! busy; then
    lock
    atc "$P" 'AT+QNETDEVCTL=1,1'
    unlock
  fi
  T2=$(cut -d. -f1 /proc/uptime)
  while [ $(( $(cut -d. -f1 /proc/uptime) - T2 )) -lt 60 ]; do
    if ping -c 1 -W 2 223.5.5.5 >/dev/null 2>&1; then OK=1; break; fi
    sleep 5
  done
fi
if ! ip addr show usb1 2>/dev/null | grep -q inet; then
  udhcpc -i usb1 -n -q -t 8 -T 2 >/dev/null 2>&1
fi
if [ $OK -eq 1 ]; then echo 1 > /tmp/band_follow; else echo 0 > /tmp/band_follow; fi
sleep 240
rm -f /tmp/band_follow /tmp/band_follow.pid
FEOF
  chmod 755 /tmp/band_follow.sh
  start-stop-daemon -S -b -m -p /tmp/band_follow.pid -x /bin/sh -- /tmp/band_follow.sh
  return 0
}
follow_out(){
  F=$(cat /tmp/band_follow 2>/dev/null)
  [ -n "$F" ] && echo "FOLLOW=$F"
  return 0
}

atc(){
  at_clearlock "$1"
  rm -f /tmp/atc_out_$$
  # -t is microcom's own silence timeout: it exits by itself once the line goes
  # quiet, so the 8s watchdog the old version needed (and its killall, which
  # killed other readers and stranded the lock file) is gone.  Measured: stdin 1s
  # + -t 1500 reads every response in full, and cuts each call from 8s to ~4s.
  ( (echo -e "$2\r"; sleep 1) | microcom -t 1500 -s 115200 /dev/$1 > /tmp/atc_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  cat /tmp/atc_out_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' '
  rm -f /tmp/atc_out_$$
  at_clearlock "$1"
}
band_write(){
  at_lock
  i=0
  while [ $i -lt 4 ]; do
    ATP=$(at_port)
    if [ -n "$ATP" ]; then
      W=$(atc $ATP "AT*BAND=$1")
      case "$W" in *OK*) at_unlock; return 0;; esac
    fi
    sleep 3
    i=$((i+1))
  done
  at_unlock
  return 1
}
band_human(){
  BH_LOW=$(echo "$1" | cut -d, -f5)
  BH_HIGH=$(echo "$1" | cut -d, -f4)
  BH_OUT=""; BH_N=0
  [ $(( BH_LOW & 1 )) -ne 0 ] && { BH_OUT="$BH_OUT B1"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 4 )) -ne 0 ] && { BH_OUT="$BH_OUT B3"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 16 )) -ne 0 ] && { BH_OUT="$BH_OUT B5"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B8"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 2 )) -ne 0 ] && { BH_OUT="$BH_OUT B34"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 32 )) -ne 0 ] && { BH_OUT="$BH_OUT B38"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 64 )) -ne 0 ] && { BH_OUT="$BH_OUT B39"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B40"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 256 )) -ne 0 ] && { BH_OUT="$BH_OUT B41"; BH_N=$((BH_N+1)); }
  if [ $BH_N -eq 0 ]; then echo "当前未启用任何频段"; else echo "已启用$BH_OUT"; fi
}

band_status_html(){
  BSH_LOW=$(echo "$1" | cut -d, -f5)
  BSH_HIGH=$(echo "$1" | cut -d, -f4)
  BSH_N=0; BSH_FDD=""; BSH_TDD=""
  [ $(( BSH_LOW & 1 )) -ne 0 ] && { BSH_FDD="$BSH_FDD<span class='band-badge fdd'>B1</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_LOW & 4 )) -ne 0 ] && { BSH_FDD="$BSH_FDD<span class='band-badge fdd'>B3</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_LOW & 16 )) -ne 0 ] && { BSH_FDD="$BSH_FDD<span class='band-badge fdd'>B5</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_LOW & 128 )) -ne 0 ] && { BSH_FDD="$BSH_FDD<span class='band-badge fdd'>B8</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_HIGH & 2 )) -ne 0 ] && { BSH_TDD="$BSH_TDD<span class='band-badge tdd'>B34</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_HIGH & 32 )) -ne 0 ] && { BSH_TDD="$BSH_TDD<span class='band-badge tdd'>B38</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_HIGH & 64 )) -ne 0 ] && { BSH_TDD="$BSH_TDD<span class='band-badge tdd'>B39</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_HIGH & 128 )) -ne 0 ] && { BSH_TDD="$BSH_TDD<span class='band-badge tdd'>B40</span>"; BSH_N=$((BSH_N+1)); }
  [ $(( BSH_HIGH & 256 )) -ne 0 ] && { BSH_TDD="$BSH_TDD<span class='band-badge tdd'>B41</span>"; BSH_N=$((BSH_N+1)); }
  BSH_FDD_N=$(echo "$BSH_FDD" | grep -o 'band-badge' | wc -l)
  BSH_TDD_N=$(echo "$BSH_TDD" | grep -o 'band-badge' | wc -l)
  BSH_BADGES="$BSH_FDD$BSH_TDD"
  if [ $BSH_N -eq 0 ]; then BSH_BADGES="<span class='band-badge empty'>未启用任何频段</span>"; fi
  echo "<div class='band-status-header'><div class='band-status-icon'><svg viewBox='0 0 24 24' fill='currentColor'><path d='M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z'/></svg></div><div><div class='band-status-title'>当前频段</div><div class='band-status-count'>$BSH_N 个频段已启用$([ $BSH_FDD_N -gt 0 ] && echo " · FDD $BSH_FDD_N")$([ $BSH_TDD_N -gt 0 ] && echo " · TDD $BSH_TDD_N")</div></div></div><div class='band-badges'>$BSH_BADGES</div>"
}

# ==================== ③ 锁定频点 / 小区（AT*CELL，ASR 私有命令） ====================
# 语法（实测确认）：AT*CELL=<mode>,3,<band>,<earfcn>[,<pci>]
#   mode=1 频率锁（4 参）/ mode=2 小区锁（5 参）/ AT*CELL=0 解除
# 注意：band 用【真实频段号】（传 3 锁 B3）；参数顺序是 <earfcn> 在前 <pci> 在后
CELL_LOCKFILE=/tmp/cell_lock_state
CELL_LOG=/tmp/cell_lock.log

cell_atc(){ # cell_atc <port> <cmd>
  CLC_D="$1"; CLC_C="$2"
  at_clearlock "$CLC_D"
  rm -f /tmp/cell_atc_$$
  ( (echo -e "$CLC_C\r"; sleep 1) | microcom -t 2000 -s 115200 /dev/$CLC_D > /tmp/cell_atc_$$ 2>/dev/null ) & CLC_MP=$!
  ( sleep 5; kill $CLC_MP 2>/dev/null ) & CLC_KT=$!
  wait $CLC_MP 2>/dev/null; kill $CLC_KT 2>/dev/null
  CLC_R=$(cat /tmp/cell_atc_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  rm -f /tmp/cell_atc_$$
  at_clearlock "$CLC_D"
  echo "$CLC_R"
}

cell_apply(){ # cell_apply <band> <earfcn> <pci|空>
  CA_B="$1"; CA_E="$2"; CA_P="$3"
  at_lock
  CA_OK=0
  CA_I=0
  while [ $CA_I -lt 4 ]; do
    CA_ATP=$(at_port)
    if [ -n "$CA_ATP" ]; then
      if [ -n "$CA_P" ]; then
        CA_R=$(cell_atc "$CA_ATP" "AT*CELL=2,3,$CA_B,$CA_E,$CA_P")
        CA_DESC="小区锁(B$CA_B/$CA_E/PCI$CA_P)"
      else
        CA_R=$(cell_atc "$CA_ATP" "AT*CELL=1,3,$CA_B,$CA_E")
        CA_DESC="频点锁(B$CA_B/$CA_E)"
      fi
      case "$CA_R" in
        *OK*)
          CA_OK=1
          printf '%s' "$CA_DESC" > $CELL_LOCKFILE
          break;;
      esac
    fi
    sleep 3
    CA_I=$((CA_I+1))
  done
  at_unlock
  [ $CA_OK -eq 1 ] && return 0
  return 1
}

cell_clear(){
  at_lock
  CC_OK=0
  CC_I=0
  while [ $CC_I -lt 4 ]; do
    CC_ATP=$(at_port)
    if [ -n "$CC_ATP" ]; then
      CC_R=$(cell_atc "$CC_ATP" 'AT*CELL=0')
      case "$CC_R" in *OK*) CC_OK=1; rm -f $CELL_LOCKFILE; break;; esac
    fi
    sleep 3
    CC_I=$((CC_I+1))
  done
  at_unlock
  [ $CC_OK -eq 1 ] && return 0
  return 1
}

# 锁定/解除后的兜底：写入后若仍未注册 → （锁定模式）自动解除锁定；
# 若已注册但未拨号 → 补一轮拨号（解除锁定后模组重新搜网会掉数据呼叫，同样需要）
cell_guard_launch(){ # cell_guard_launch <mode:lock|clear>
  CG_MODE="$1"
  cat > /tmp/cell_guard.sh << CGEOF
#!/bin/sh
# mode=$CG_MODE: lock=锁定后兜底（未驻网自动解除）；clear=解除后兜底（只补拨号）
sleep 20
# ---- 阶段 1：检查注册（最多 5 轮 × 15s = 75s） ----
i=0
OK=0
while [ \$i -lt 5 ]; do
  P=""
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=\$(readlink -f \$t 2>/dev/null)
    case "\$p" in */1-1.1/1-1.1:1.4/*) P="\${t##*/}";; esac
  done
  if [ -n "\$P" ]; then
    R=\$( ( (echo -e 'AT+QNWINFO\r'; sleep 1) | microcom -t 2000 -s 115200 /dev/\$P 2>/dev/null ) | tr -d '\r' | tr '\n' ' ')
    case "\$R" in *BAND*) OK=1; break;; esac
  fi
  sleep 15
  i=\$((i+1))
done
if [ \$OK -eq 0 ]; then
  # 未驻网 → 锁定模式下解除锁定（回正常驻网）；解除模式下继续等（没什么可撤的）
  if [ "$CG_MODE" = "lock" ]; then
    for t in /sys/bus/usb-serial/devices/ttyUSB*; do
      p=\$(readlink -f \$t 2>/dev/null)
      case "\$p" in */1-1.1/1-1.1:1.4/*) P="\${t##*/}";; esac
    done
    [ -n "\$P" ] && ( (echo -e 'AT*CELL=0\r'; sleep 1) | microcom -t 2000 -s 115200 /dev/\$P >/dev/null 2>&1 )
    rm -f /tmp/cell_lock_state
    echo "GUARD: 锁定后 75s 未驻网，已自动解除锁定" >> /tmp/cell_lock.log
  else
    echo "GUARD: 解除后 75s 未驻网（网络侧问题，非锁定残留）" >> /tmp/cell_lock.log
  fi
  rm -f /tmp/cell_guard.pid
  exit 0
fi
# ---- 阶段 2：已驻网，检查数据通道 ----
# 判据 = AT+QNETDEVCTL? 的末位（1=已拨号，0=未拨号）
# 注意：不能用"网卡有 192.168.43.x IP"判断 —— 那是模组侧固定地址，未拨号时也存在（踩过坑）
# 也不能用 ping 网关判断 —— 网关就是模组本身，未拨号时照通
# 补拨号用 停(=0,1)→起(=1,1) 两步：模组侧呼叫状态可能与查询值滞后，只发"起"无效（实测踩过）
cell_dialed(){ # 返回 1=已拨号
  [ -z "\$1" ] && return 1
  local Q
  Q=\$( ( (echo -e 'AT+QNETDEVCTL?\r'; sleep 1) | microcom -t 2000 -s 115200 /dev/\$1 2>/dev/null ) | tr -d '\r' | tr '\n' ' ')
  case "\$Q" in
    *"+QNETDEVCTL: 1,1,"*,1*) return 0;;
    *"+QNETDEVCTL: 1,1,"*,1" "*) return 0;;
  esac
  return 1
}
sleep 10
if [ -n "\$P" ] && ! cell_dialed "\$P"; then
  ( (echo -e 'AT+QNETDEVCTL=0,1\r'; sleep 2; echo -e 'AT+QNETDEVCTL=1,1\r'; sleep 2) | microcom -t 6000 -s 115200 /dev/\$P >/dev/null 2>&1 )
  echo "GUARD: 驻网正常但未拨号，已重拨（停→起）" >> /tmp/cell_lock.log
  sleep 20
  if cell_dialed "\$P"; then
    echo "GUARD: 重拨成功，数据通道已恢复" >> /tmp/cell_lock.log
  else
    echo "GUARD: 重拨后仍未连通（可点刷新，或稍后再试）" >> /tmp/cell_lock.log
  fi
else
  echo "GUARD: 服务与数据通道均正常" >> /tmp/cell_lock.log
fi
rm -f /tmp/cell_guard.pid
CGEOF
  chmod 755 /tmp/cell_guard.sh
  start-stop-daemon -S -b -m -p /tmp/cell_guard.pid -x /bin/sh -- /tmp/cell_guard.sh
}

cell_state_human(){ # 从状态文件读"当前锁定"描述
  if [ -f $CELL_LOCKFILE ]; then
    cat $CELL_LOCKFILE 2>/dev/null
  else
    echo "未锁定"
  fi
}

# 频段下拉选项：v19.6 起由 EARFCN 自动推导频段（3GPP TS 36.101，EARFCN 全局唯一），
# 用户不再需要手选频段，故本函数已不再被调用。

# EARFCN -> 频段自动推导（3GPP TS 36.101 标准范围；EARFCN 全局唯一，无需用户选频段）
# 返回频段号；不在支持范围时返回空
earfcn_to_band(){
  EB_E="$1"
  case "$EB_E" in ''|*[!0-9]*) echo ""; return;; esac
  if [ "$EB_E" -ge 0 ] && [ "$EB_E" -le 599 ]; then echo 1; return; fi
  if [ "$EB_E" -ge 1200 ] && [ "$EB_E" -le 1949 ]; then echo 3; return; fi
  if [ "$EB_E" -ge 2400 ] && [ "$EB_E" -le 2649 ]; then echo 5; return; fi
  if [ "$EB_E" -ge 3450 ] && [ "$EB_E" -le 3799 ]; then echo 8; return; fi
  if [ "$EB_E" -ge 36200 ] && [ "$EB_E" -le 36349 ]; then echo 34; return; fi
  if [ "$EB_E" -ge 37750 ] && [ "$EB_E" -le 38249 ]; then echo 38; return; fi
  if [ "$EB_E" -ge 38250 ] && [ "$EB_E" -le 38649 ]; then echo 39; return; fi
  if [ "$EB_E" -ge 38650 ] && [ "$EB_E" -le 39649 ]; then echo 40; return; fi
  if [ "$EB_E" -ge 39650 ] && [ "$EB_E" -le 41589 ]; then echo 41; return; fi
  echo ""
}

# MCC/MNC -> operator name.  Values come from the servingcell response we
# already read, so no extra AT command is needed.
op_name(){
  case "$1" in
    46000|46002|46004|46007|46008) echo "中国移动" ;;
    46001|46006|46009)             echo "中国联通" ;;
    46003|46005|46011)             echo "中国电信" ;;
    46015)                         echo "中国广电" ;;
    ""|"?"|"000")                  echo "" ;;
    *)                             echo "其他($1)" ;;
  esac
}

# one session, all data -> key=value lines
data_read(){
  ATP=$(at_port)
  [ -z "$ATP" ] && { echo "STATUSFAIL"; return 1; }
  rm -f /tmp/st_out_$$
  # Commands are pipelined in one burst and the reply is collected once at the
  # end.  Measured on-device: ~1s with this setting versus ~8s when each command
  # waited a full second, with the same 5/5 response rate.
  at_clearlock "$ATP"
  ( (echo -e 'AT*BAND?\r'; echo -e 'AT+QENG="servingcell"\r'; echo -e 'AT+CGSN\r'; echo -e 'AT+QCCID\r'; echo -e 'AT+CSQ\r'; sleep 1) | microcom -t 800 -s 115200 /dev/$ATP > /tmp/st_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  at_clearlock "$ATP"
  RAW=$(cat /tmp/st_out_$$ 2>/dev/null | tr -d '\r')
  rm -f /tmp/st_out_$$
  BANDV=$(echo "$RAW" | grep -o '\*BAND:[0-9,]*' | head -1 | sed 's/\*BAND://')
  CELL=$(echo "$RAW" | grep -o '+QENG: "servingcell".*' | head -1)
  DUPLEX=$(echo "$CELL" | cut -d, -f4 | tr -d '"')
  BAND=$(echo "$CELL" | cut -d, -f10)
  # PCI 与 EARFCN 也在 servingcell 响应里（字段 8/9），锁频点/小区功能要用
  CELLPCI=$(echo "$CELL" | cut -d, -f8 | tr -d '" ')
  CELLEARFCN=$(echo "$CELL" | cut -d, -f9 | tr -d '" ')
  case "$CELLPCI" in ''|*[!0-9]*) CELLPCI="";; esac
  case "$CELLEARFCN" in ''|*[!0-9]*) CELLEARFCN="";; esac
  RSRP=$(echo "$CELL" | cut -d, -f14 | tr -d '"')
  SINR=$(echo "$CELL" | cut -d, -f17 | tr -d '"')
  IMEI=$(echo "$RAW" | grep -oE '^[0-9]{15}$' | head -1)
  ICCID=$(echo "$RAW" | grep -o '+QCCID: [0-9A-Fa-f]*' | head -1 | sed 's/+QCCID: //')
  CSQ=$(echo "$RAW" | grep -o '+CSQ: [0-9]*' | head -1 | sed 's/+CSQ: //')
  # MCC/MNC live in fields 5/6 of the servingcell response
  MCC=$(echo "$CELL" | cut -d, -f5 | tr -d '"')
  MNC=$(echo "$CELL" | cut -d, -f6 | tr -d '"')
  MCCMNC="${MCC}${MNC}"
  case "$MCCMNC" in *[!0-9]*) MCCMNC="";; esac
  OPER=$(op_name "$MCCMNC")
  echo "BANDVAL=${BANDV:-READFAIL}"
  echo "DUPLEX=${DUPLEX:-?}"
  echo "BAND=${BAND:-?}"
  echo "IMEI=${IMEI:-读取失败}"
  echo "ICCID=${ICCID:-读取失败}"
  echo "CSQ=${CSQ:-?}"
  echo "RSRP=${RSRP:-?}"
  echo "SINR=${SINR:-?}"
  echo "OPER=$OPER"
  echo "CELLPCI=${CELLPCI:-}"
  echo "CELLEARFCN=${CELLEARFCN:-}"
  if [ -n "$BANDV" ]; then
    echo "HUMAN=$(band_human "$BANDV")"
  else
    echo "HUMAN=READFAIL"
  fi
  return 0
}

# The timestamp must describe when the data was actually read, not when it was
# served, so a cache hit re-emits the stored time instead of "now".  The panel
# therefore only shows a new time when a real AT read took place.
stamp_out(){
  ST=$(cat /tmp/at_stamp 2>/dev/null)
  [ -z "$ST" ] && ST=$(date +%H:%M:%S)
  echo "STAMP=$ST"
}

# ---------- 壁纸链接：存储路径 + 合法性校验 ----------
# 只接受 http(s) 链接；拒绝 引号/反斜杠/尖括号/反引号/竖线/分号/花括号/控制符。
# 校验通过的值只会流向两个地方：(a) 作为**数据**写进文件；(b) 作为**保证不含 " \ <**
# 的字符串放进页面。因此不存在命令注入 / HTML 注入 / CSS 逃逸路径。
WPFILE=/etc/decloud/wallpaper_url
wp_valid(){
  case "$1" in http://*|https://*) ;; *) return 1 ;; esac
  [ "$(printf '%s' "$1" | tr -d '\r\n\t')" = "$1" ] || return 1
  case "$1" in
    *'"'*|*"'"*|*'\'*|*'<'*|*'>'*|*'`'*|*'|'*|*';'*|*'{'*|*'}'*|*'$'*) return 1 ;;
  esac
  [ ${#1} -le 512 ] || return 1
  return 0
}

# ---------- ajax: all data (rate limited: min 3s between reads) ----------
case "$QUERY_STRING" in
  *a=data*)
    echo "Content-Type: text/plain; charset=utf-8"
    echo ""
    NOW=$(date +%s)
    LAST=""
    [ -f /tmp/at_lastdata ] && LAST=$(cat /tmp/at_lastdata 2>/dev/null)
    # A manual refresh sends force=1 and must always end in a real read, so it
    # bypasses the cache branch entirely and reads the module now.  The throttle
    # window is not waited out: at_trylock() below already serialises access, and
    # sleeping here only adds dead time (measured 5-6s instead of ~2s).
    # Auto-refresh omits the flag and still uses the cache, so the AT port is not
    # hit on every single tick.
    FORCE=0
    case "$QUERY_STRING" in *force=1*) FORCE=1 ;; esac
    if [ $FORCE -eq 0 ] && [ -n "$LAST" ] && [ $((NOW - LAST)) -lt 3 ] && [ -f /tmp/at_cached ]; then
      cat /tmp/at_cached
      # Keep the reported age at >=1.  A cache hit landing in the same second
      # would otherwise emit CACHED=0, which is the marker for "freshly read".
      AGE=$((NOW - LAST)); [ $AGE -lt 1 ] && AGE=1
      echo "CACHED=$AGE"
      stamp_out
      follow_out
      exit 0
    fi
    if ! at_trylock; then
      if [ -f /tmp/at_cached ]; then
        cat /tmp/at_cached
        echo "CACHED=-1"
        stamp_out
      else
        echo "BUSY"
      fi
      exit 0
    fi
    # The vendor app polls the same AT port every 20s and occasionally bursts a
    # SIM re-identification sequence; a read landing inside such a burst can come
    # back empty.  Retry before giving up, and only mark the result as fresh when
    # a retry actually succeeded (otherwise a stale cache would look fresh).
    GOT=0
    RT=0
    while [ $RT -lt 3 ]; do
      data_read > /tmp/at_try_$$ 2>/dev/null
      if grep -q 'BANDVAL=[0-9]' /tmp/at_try_$$ 2>/dev/null; then
        mv /tmp/at_try_$$ /tmp/at_cached
        GOT=1
        break
      fi
      RT=$((RT+1))
      [ $RT -lt 3 ] && sleep 2
    done
    rm -f /tmp/at_try_$$
    if [ ! -f /tmp/at_cached ]; then
      echo "STATUSFAIL"
    else
      cat /tmp/at_cached
    fi
    if [ $GOT -eq 1 ]; then
      date +%s > /tmp/at_lastdata
      date +%H:%M:%S > /tmp/at_stamp
    fi
    at_unlock
    echo "CACHED=0"
    stamp_out
    follow_out
    exit 0
    ;;
esac

LEN=$(echo -n "$CONTENT_LENGTH" | grep -o '[0-9]*' | head -1)
BODY=""
[ -n "$LEN" ] && BODY=$(dd bs=1 count=$LEN 2>/dev/null)

RESULT=""; RESULT_OK=""; APPLIED=""
POSTED=0

# ---------- imei POST (PRG; may trigger reboot) ----------
# ---------- root password POST (for the 8888 LuCI panel) ----------
case "$BODY" in
  *pw1=*)
    urldecode(){
      printf '%b' "$(echo "$1" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')"
    }
    PW0=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw0=\([^&]*\).*/\1/p' | head -1)")
    PW1=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw1=\([^&]*\).*/\1/p' | head -1)")
    PW2=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw2=\([^&]*\).*/\1/p' | head -1)")
    PW_RESULT=""; PW_OK=""
    # Whether the CURRENT PASSWORD must be verified depends on whether the user has
    # ever set one through this page -- NOT on whether root has a hash.  The factory
    # password is unknown to us and to the user, so a device that was never
    # configured here must be allowed to set one without knowing the old value;
    # otherwise the feature is unusable.  Once the user has set it themselves, every
    # later change must prove knowledge of it, so nobody else can take it over.
    PW_PREV=""
    if [ -f /usr/aos/decloud_pw_set ] || [ -f /tmp/webimei/pw_set ]; then PW_PREV=1; fi
    if [ -z "$PW1" ]; then
      PW_RESULT="密码不能为空"
    elif [ "$PW1" != "$PW2" ]; then
      PW_RESULT="两次输入的密码不一致"
    elif [ ${#PW1} -lt 8 ]; then
      PW_RESULT="密码太短，请至少 8 位"
    elif [ -n "$PW_PREV" ]; then
      # 已设过密码：校验当前密码（用 lua + nixio.crypt 比对 /etc/shadow）
      printf '%s' "$PW0" > /tmp/.pwchk
      PW_VALID=$(lua -e '
        local f=io.open("/tmp/.pwchk"); local p=f:read("*a"); f:close()
        local s=io.open("/etc/shadow"):read("*a")
        local h=s:match("^root:([^:]*):")
        local ok=require("nixio")
        if h and h~="" and h~="!" and h~="x" and ok.crypt(p,h)==h then print("1") else print("0") end
      ' 2>/dev/null)
      rm -f /tmp/.pwchk
      if [ "$PW_VALID" != "1" ]; then
        PW_RESULT="当前密码不正确，未做修改"
      else
        PW_SET_GO=1
      fi
    else
      PW_SET_GO=1
    fi
    if [ -n "$PW_SET_GO" ]; then
      BEFORE=$(grep '^root' /etc/shadow 2>/dev/null | cut -d: -f2)
      printf '%s\n%s\n' "$PW1" "$PW2" | passwd root >/tmp/pw_try 2>&1
      AFTER=$(grep '^root' /etc/shadow 2>/dev/null | cut -d: -f2)
      if [ -n "$AFTER" ] && [ "$BEFORE" != "$AFTER" ]; then
        # 用户已通过本界面设过密码：此后修改必须先验证旧密码
        echo 1 > /usr/aos/decloud_pw_set 2>/dev/null
        echo 1 > /tmp/webimei/pw_set 2>/dev/null
        PW_RESULT="密码设置成功！现在可用 root + 该密码登录 8888 管理后台"
        PW_OK=1
      else
        PW_RESULT="密码设置失败，请重试"
      fi
    fi
    echo "$PW_RESULT" > /tmp/pw_result
    echo "$PW_OK" > /tmp/pw_result_ok
    rm -f /tmp/pw_try
    echo "Status: 302 Found"
    echo "Location: /"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
  *imei=*)
    WANT=$(echo "$BODY" | grep -o 'imei=[0-9]*' | head -1 | cut -d= -f2)
    case "$WANT" in
      [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]) : ;;
      *) WANT="";;
    esac
    REBOOTNOW=0
    case "$BODY" in *reboot=1*) REBOOTNOW=1;; esac
    if [ -n "$WANT" ]; then
      # luhn sanity (server side; module enforces anyway)
      LS=0; LD=0
      i=14
      while [ $i -ge 0 ]; do
        D=$(echo "$WANT" | cut -c$((i+1)))
        if [ $LD -eq 1 ]; then D=$((D*2)); [ $D -gt 9 ] && D=$((D-9)); fi
        LS=$((LS+D)); LD=$((1-LD))
        i=$((i-1))
      done
      if [ $((LS % 10)) -ne 0 ]; then
        rm -f /usr/aos/imei_request
        {
          echo "IMEI 校验位不合法，已拒绝保存（设备会拒绝写入）。请核对后重试。"
          echo ""
          echo ""
        } > /tmp/imei_result
        echo "Status: 302 Found"
        echo "Location: /?a=band"
        echo "Content-Type: text/html"
        echo ""
        echo "redirecting"
        exit 0
      fi
      echo "$WANT" > /usr/aos/imei_request
      if [ $REBOOTNOW -eq 1 ]; then
        echo "Content-Type: text/html; charset=utf-8"
        echo ""
        echo "<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width, initial-scale=1'><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:17px}</style></head><body>"
        echo "<h2>IMEI 已保存，设备正在重启…</h2>"
        echo "<p style='color:#c62828'>重启时会把新 IMEI 写入设备，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
        echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
        echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
        echo "</body></html>"
        (sleep 2; sync; reboot) &
        exit 0
      fi
      {
        echo "IMEI 已保存：$WANT"
        echo "1"
        echo ""
      } > /tmp/imei_result
    else
      {
        echo "IMEI 格式错误（需要 15 位数字）"
        echo ""
        echo ""
      } > /tmp/imei_result
    fi
    echo "Status: 302 Found"
    echo "Location: /?a=band"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
esac

# ---------- reboot only (standalone button) ----------
case "$BODY" in
  *reboot=1*)
    echo "Content-Type: text/html; charset=utf-8"
    echo ""
    echo "<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width, initial-scale=1'><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:17px}</style></head><body>"
    echo "<h2>设备正在重启…</h2>"
    echo "<p style='color:#c62828'>重启时会把新 IMEI 写入设备，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
    echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
    echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
    echo "</body></html>"
    (sleep 2; sync; reboot) &
    exit 0
    ;;
esac

# ---------- actions (POST only) ----------
# order matters: restore_bak BEFORE restore (prefix collision)
case "$BODY" in
  *restore_bak*)
    POSTED=1
    if [ -f $BACKUP ]; then
      BK=$(cat $BACKUP)
      case "$BK" in
        [0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*) : ;;
        *) BK="";;
      esac
      if [ -z "$BK" ]; then
        RESULT="备份文件无效，请改用“恢复出厂频段”"
      elif band_write "$BK"; then
        band_follow_launch
        RESULT="已恢复上次配置，正在重新驻网并自动恢复拨号（约1分钟，无需重启）"; RESULT_OK=1; APPLIED="$BK"
      else
        RESULT="恢复失败：设备未响应，请重试"
      fi
    else
      RESULT="没有备份记录"
    fi
    ;;
esac
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *restore*)
    POSTED=1
    if band_write "$FACTORY_BAND"; then
      band_follow_launch
      RESULT="已恢复出厂频段，正在重新驻网并自动恢复拨号（约1分钟，无需重启）"; RESULT_OK=1; APPLIED="$FACTORY_BAND"
    else
      RESULT="恢复失败：设备未响应，请重试（设备可能正在重启）"
    fi
    ;;
esac
fi
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *low=*)
    POSTED=1
    LOWNEW=$(echo "$BODY" | grep -o 'low=[0-9]*' | head -1 | cut -d= -f2)
    HIGHNEW=$(echo "$BODY" | grep -o 'high=[0-9]*' | head -1 | cut -d= -f2)
    case "$LOWNEW" in ''|*[!0-9]*) LOWNEW=0;; esac
    case "$HIGHNEW" in ''|*[!0-9]*) HIGHNEW=0;; esac
    if [ "$LOWNEW" -eq 0 ] && [ "$HIGHNEW" -eq 0 ]; then
      RESULT="错误：至少勾选一个频段"
    elif [ "$LOWNEW" -gt 255 ] || [ "$HIGHNEW" -gt 4095 ]; then
      RESULT="错误：频段值超范围"
    else
      at_lock
      OLDV=""
      ATP=$(at_port)
      [ -n "$ATP" ] && OLDV=$(atc $ATP 'AT*BAND?' | grep -o '\*BAND:[0-9,]*' | sed 's/\*BAND://')
      [ -n "$OLDV" ] && echo "$OLDV" > $BACKUP
      R1=$(echo "$OLDV" | cut -d, -f1); R2=$(echo "$OLDV" | cut -d, -f2); R3=$(echo "$OLDV" | cut -d, -f3)
      T1=$(echo "$OLDV" | cut -d, -f6); T2=$(echo "$OLDV" | cut -d, -f7); T3=$(echo "$OLDV" | cut -d, -f8)
      [ -z "$R1" ] && R1=12; [ -z "$R2" ] && R2=78; [ -z "$R3" ] && R3=145
      [ -z "$T1" ] && T1=0; [ -z "$T2" ] && T2=2; [ -z "$T3" ] && T3=2
      NEW="$R1,$R2,$R3,$HIGHNEW,$LOWNEW,$T1,$T2,$T3"
      WR=0
      i=0
      while [ $i -lt 4 ]; do
        ATP=$(at_port)
        if [ -n "$ATP" ]; then
          W=$(atc $ATP "AT*BAND=$NEW")
          case "$W" in *OK*) WR=1; break;; esac
        fi
        sleep 3
        i=$((i+1))
      done
      at_unlock
      if [ $WR -eq 1 ]; then
        band_follow_launch
        RESULT="已应用新配置，正在重新驻网并自动恢复拨号（约1分钟，无需重启）"; RESULT_OK=1; APPLIED="$NEW"
      else
        RESULT="写入失败：设备未响应，请重试"
      fi
    fi
    ;;
esac
fi

# ---------- ③ 锁定频点 / 小区（POST） ----------
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *cell_clear*)
    POSTED=1
    if cell_clear; then
      # 解除后模组重新搜网会掉数据呼叫，守卫只负责把拨号补回来
      cell_guard_launch clear
      CELL_RESULT="已解除频点/小区锁定，设备正在重新搜网并自动恢复拨号（约 1 分钟）"; CELL_RESULT_OK=1
    else
      CELL_RESULT="解除失败：设备未响应，请重试"
    fi
    ;;
esac
fi
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *cell_lock*|*cell_apply*)
    POSTED=1
    CE_TMP=$(echo "$BODY" | grep -o 'cearfcn=[0-9]*' | head -1 | cut -d= -f2)
    CP_TMP=$(echo "$BODY" | grep -o 'cpci=[0-9]*' | head -1 | cut -d= -f2)
    case "$CE_TMP" in ''|*[!0-9]*) CE_TMP="";; esac
    case "$CP_TMP" in ''|*[!0-9]*) CP_TMP="";; esac
    # "一键锁定当前" 按钮：忽略表单值，直接读当前 servingcell 的频点与 PCI
    case "$BODY" in
      *cell_lock*)
        CUR_RAW=""
        at_lock
        ATP=$(at_port)
        if [ -n "$ATP" ]; then
          CUR_RAW=$(cell_atc "$ATP" 'AT+QENG="servingcell"')
        fi
        at_unlock
        CE_TMP=$(echo "$CUR_RAW" | cut -d, -f9 | tr -d '" ')
        CP_TMP=$(echo "$CUR_RAW" | cut -d, -f8 | tr -d '" ')
        case "$CE_TMP" in ''|*[!0-9]*) CE_TMP="";; esac
        case "$CP_TMP" in ''|*[!0-9]*) CP_TMP="";; esac
        ;;
    esac
    # 由 EARFCN 自动推导频段（不再需要用户选择）
    CB_TMP=""
    [ -n "$CE_TMP" ] && CB_TMP=$(earfcn_to_band "$CE_TMP")
    if [ -z "$CE_TMP" ]; then
      CELL_RESULT="错误：请填写频点（EARFCN），或先确保设备已驻网后点“一键锁定当前”"
    elif [ -z "$CB_TMP" ]; then
      CELL_RESULT="错误：频点 $CE_TMP 不在本设备支持的频段范围内"
    elif [ -n "$CP_TMP" ] && [ "$CP_TMP" -gt 503 ]; then
      CELL_RESULT="错误：PCI 范围为 0-503"
    else
      if [ -n "$CP_TMP" ]; then
        LOCKKIND="小区锁（B$CB_TMP / $CE_TMP / PCI $CP_TMP）"
      else
        LOCKKIND="频点锁（B$CB_TMP / $CE_TMP）"
      fi
      if cell_apply "$CB_TMP" "$CE_TMP" "$CP_TMP"; then
        cell_guard_launch lock
        CELL_RESULT="已下发 $LOCKKIND，设备正在重新搜网（约 10-60 秒）；若 75 秒后仍无网会自动解除锁定"; CELL_RESULT_OK=1
      else
        CELL_RESULT="锁定失败：设备未响应（可能忙或重启中），请稍后重试"
      fi
    fi
    ;;
esac
fi

# ---------- ④ 网口与上网优先级（POST） ----------
# 端口角色：写 /etc/net_port_mode（开机由 rc.local 钩子重放）并立即生效
# 优先级：network.wan.metric（30=4G优先 / 5=有线优先）+ wan.auto + 防火墙拦截
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *net_port=*|*net_mode=*)
    POSTED=1
    NP=$(echo "$BODY" | grep -o 'net_port=[a-z0-9]*' | head -1 | cut -d= -f2)
    NM2=$(echo "$BODY" | grep -o 'net_mode=[a-z0-9]*' | head -1 | cut -d= -f2)
    case "$NP" in p1|p2|all) ;; *) NP=p0;; esac
    case "$NM2" in wan|only4g|onlywan) ;; *) NM2=4g;; esac
    # 全部 LAN 时没有有线 WAN，有线优先/仅有线 自动回落为 4G 优先
    if [ "$NP" = "all" ] && [ "$NM2" != "only4g" ]; then NM2=4g; fi
    case "$NP" in
      p1)
        cat > /etc/net_port_mode << 'NPEOF'
#!/bin/sh
# NETPORT=p1  LAN1 (chip port2) as WAN
switch reg w 14 405555
switch reg w 50 2001
switch reg w 98 7f3f
switch reg w e4 3f
switch reg w 40 1001
switch reg w 44 1002
switch reg w 48 1001
switch reg w 70 ffff447b
switch reg w 74 ffffffff
switch clear
NPEOF
        ;;
      p2)
        cat > /etc/net_port_mode << 'NPEOF'
#!/bin/sh
# NETPORT=p2  LAN2 (chip port1) as WAN
switch reg w 14 405555
switch reg w 50 2001
switch reg w 98 7f3f
switch reg w e4 3f
switch reg w 40 2001
switch reg w 44 1001
switch reg w 48 1001
switch reg w 70 ffff427d
switch reg w 74 ffffffff
switch clear
NPEOF
        ;;
      all)
        cat > /etc/net_port_mode << 'NPEOF'
#!/bin/sh
# NETPORT=all  all three jacks LAN (no wired WAN)
switch reg w 14 405555
switch reg w 50 2001
switch reg w 98 7f3f
switch reg w e4 3f
switch reg w 40 1001
switch reg w 44 1001
switch reg w 48 1001
switch reg w 70 ffff407f
switch reg w 74 ffffffff
switch clear
NPEOF
        ;;
      *)
        rm -f /etc/net_port_mode
        # 恢复出厂寄存器（LLLLW：LAN0=4 号口在 WAN 侧）
        switch reg w 14 405555 >/dev/null 2>&1
        switch reg w 50 2001 >/dev/null 2>&1
        switch reg w 98 7f3f >/dev/null 2>&1
        switch reg w e4 3f >/dev/null 2>&1
        switch reg w 40 1001 >/dev/null 2>&1
        switch reg w 44 1001 >/dev/null 2>&1
        switch reg w 48 1002 >/dev/null 2>&1
        switch reg w 70 ffff506f >/dev/null 2>&1
        switch reg w 74 ffffffff >/dev/null 2>&1
        switch clear >/dev/null 2>&1
        ;;
    esac
    # 开机重放由包内 runapp.sh 负责（rc.local 在本固件不生效，实测）
    [ -f /etc/net_port_mode ] && sh /etc/net_port_mode >/dev/null 2>&1
    case "$NM2" in
      wan)
        uci set network.wan.metric='5'; uci set network.wan.auto='1'; uci commit network
        net_unblock
        net_udhcpc_hook
        ( ifup wan >/dev/null 2>&1 & )
        ;;
      only4g)
        uci set network.wan.metric='30'; uci set network.wan.auto='0'; uci commit network
        net_unblock
        net_udhcpc_hook
        route del default dev eth0.2 2>/dev/null
        ( ifdown wan >/dev/null 2>&1 & )
        ;;
      onlywan)
        uci set network.wan.metric='5'; uci set network.wan.auto='1'; uci commit network
        net_block
        net_udhcpc_hook
        route del default dev eth0.2 2>/dev/null
        ( ifup wan >/dev/null 2>&1 & )
        ;;
      *)
        uci set network.wan.metric='30'; uci set network.wan.auto='1'; uci commit network
        net_unblock
        net_udhcpc_hook
        route del default dev eth0.2 2>/dev/null
        ( ifup wan >/dev/null 2>&1 & )
        ;;
    esac
    NET_RESULT="已应用：$(net_port_human "$NP") + $(net_mode_human "$NM2")。网络已切换，若页面无响应请刷新"; NET_RESULT_OK=1
    ;;
esac
fi

# ---------- 壁纸链接 POST（存设备侧；全浏览器通用，图片本体不进设备）----------
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *wp_url=*)
    POSTED=1
    WP_RAW=$(echo "$BODY" | sed -n 's/.*wp_url=\([^&]*\).*/\1/p' | head -1)
    WP_RAW=$(printf '%b' "$(echo "$WP_RAW" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')")
    WP_NEW=$(printf '%s' "$WP_RAW" | sed 's/^[ ]*//; s/[ ]*$//')
    if [ -z "$WP_NEW" ]; then
      rm -f "$WPFILE"
      WP_RESULT="壁纸已清除（恢复纯色背景）"; WP_RESULT_OK=1
    elif wp_valid "$WP_NEW"; then
      mkdir -p /etc/decloud 2>/dev/null
      printf '%s\n' "$WP_NEW" > "$WPFILE"
      WP_RESULT="壁纸已保存到设备，任何浏览器打开都会显示这张图"; WP_RESULT_OK=1
    else
      WP_RESULT="链接无效：只支持 http:// 或 https:// 开头的图片链接，且不能含引号、空格等特殊字符"
    fi
    ;;
esac
fi

# ---------- PRG: POST -> store result -> 302 redirect ----------
if [ $POSTED -eq 1 ]; then
  {
    echo "$RESULT"
    echo "$RESULT_OK"
    echo "$APPLIED"
  } > /tmp/band_result
  if [ -n "$CELL_RESULT" ]; then
    echo "$CELL_RESULT" > /tmp/cell_result
    echo "$CELL_RESULT_OK" > /tmp/cell_result_ok
  fi
  if [ -n "$NET_RESULT" ]; then
    echo "$NET_RESULT" > /tmp/net_result
    echo "$NET_RESULT_OK" > /tmp/net_result_ok
  fi
  if [ -n "$WP_RESULT" ]; then
    echo "$WP_RESULT" > /tmp/wp_result
    echo "$WP_RESULT_OK" > /tmp/wp_result_ok
  fi
  echo "Status: 302 Found"
  echo "Location: /?a=band"
  echo "Content-Type: text/html"
  echo ""
  echo "redirecting"
  exit 0
fi

# ---------- GET: show stored result once, then delete ----------
PW_RESULT=""
PW_RESULT_OK=""
[ -f /tmp/pw_result ] && PW_RESULT=$(cat /tmp/pw_result 2>/dev/null)
[ -f /tmp/pw_result_ok ] && PW_RESULT_OK=$(cat /tmp/pw_result_ok 2>/dev/null)
rm -f /tmp/pw_result /tmp/pw_result_ok
# 用户是否通过工具箱设过密码（决定是否显示"已设置"状态）
PW_USER_SET=""
# Same rule as the POST branch: the "current password" field appears only once the
# user has set a password through this page (marker present).  A never-configured
# device must be settable without knowing the factory password.
if [ -f /usr/aos/decloud_pw_set ] || [ -f /tmp/webimei/pw_set ]; then
  PW_USER_SET=1
fi

IMEI_RESULT=""
IMEI_RESULT_OK=""
if [ -f /tmp/imei_result ]; then
  IMEI_RESULT=$(sed -n 1p /tmp/imei_result)
  IMEI_RESULT_OK=$(sed -n 2p /tmp/imei_result)
  rm -f /tmp/imei_result
fi
if [ -f /tmp/band_result ]; then
  RESULT=$(sed -n 1p /tmp/band_result)
  RESULT_OK=$(sed -n 2p /tmp/band_result)
  APPLIED=$(sed -n 3p /tmp/band_result)
  rm -f /tmp/band_result
fi
PENDING_IMEI=""
if [ -f /usr/aos/imei_request ]; then
  PENDING_IMEI=$(cat /usr/aos/imei_request 2>/dev/null | grep -o '[0-9]*' | head -1)
fi

# ---------- render ----------
HASBAK=""
[ -f $BACKUP ] && HASBAK=1
ck(){ [ $(( ($1 / $2) % 2 )) -eq 1 ] && echo "checked"; }

SKIPLOAD=0
CURTEXT='<div class="band-status-header"><div class="band-status-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z"/></svg></div><div><div class="band-status-title">当前频段</div><div class="band-status-count">正在读取…</div></div></div><div class="band-badges"><span class="band-badge empty">加载中</span></div>'
if [ -n "$APPLIED" ]; then
  RLOW=$(echo "$APPLIED" | cut -d, -f5)
  RHIGH=$(echo "$APPLIED" | cut -d, -f4)
  CURTEXT="$(band_status_html "$APPLIED")"
  SKIPLOAD=1
else
  RLOW=0; RHIGH=0
fi
B1=$(ck $RLOW 1); B3=$(ck $RLOW 4); B5=$(ck $RLOW 16); B8=$(ck $RLOW 128)
B34=$(ck $RHIGH 2); B38=$(ck $RHIGH 32); B39=$(ck $RHIGH 64); B40=$(ck $RHIGH 128); B41=$(ck $RHIGH 256)
if [ -z "$APPLIED" ]; then
  B1=checked; B3=checked; B5=checked; B8=checked
  B34=checked; B38=checked; B39=checked; B40=checked; B41=checked
fi

# ---------- ③ 锁定频点/小区：渲染变量 ----------
CELL_RESULT=""
CELL_RESULT_OK=""
[ -f /tmp/cell_result ] && CELL_RESULT=$(sed -n 1p /tmp/cell_result 2>/dev/null)
[ -f /tmp/cell_result_ok ] && CELL_RESULT_OK=$(sed -n 1p /tmp/cell_result_ok 2>/dev/null)
rm -f /tmp/cell_result /tmp/cell_result_ok
CELL_LOCK=$(cell_state_human)
# 当前驻留（默认从最近缓存读；页面 JS 会用实时数据覆盖）
CELL_CUR="读取中…"
CELL_EARFCN=""
CELL_PCI=""
if [ -f /tmp/at_cached ]; then
  CC_E=$(sed -n 's/^CELLEARFCN=//p' /tmp/at_cached 2>/dev/null | head -1)
  CC_P=$(sed -n 's/^CELLPCI=//p' /tmp/at_cached 2>/dev/null | head -1)
  CC_B=$(sed -n 's/^BAND=//p' /tmp/at_cached 2>/dev/null | head -1)
  CC_D=$(sed -n 's/^DUPLEX=//p' /tmp/at_cached 2>/dev/null | head -1)
  case "$CC_B" in ''|'?'|*[!0-9]*) ;; *) CELL_CUR="B$CC_B ($CC_D)"; CELL_EARFCN="$CC_E"; CELL_PCI="$CC_P";; esac
fi

# ---------- ④ 网口与上网优先级：渲染变量 ----------
NET_RESULT=""
NET_RESULT_OK=""
[ -f /tmp/net_result ] && NET_RESULT=$(sed -n 1p /tmp/net_result 2>/dev/null)
[ -f /tmp/net_result_ok ] && NET_RESULT_OK=$(sed -n 1p /tmp/net_result_ok 2>/dev/null)
rm -f /tmp/net_result /tmp/net_result_ok

# ---------- 壁纸：渲染变量（设备侧唯一真相）----------
WP_RESULT=""
[ -f /tmp/wp_result ] && WP_RESULT=$(sed -n 1p /tmp/wp_result 2>/dev/null)
[ -f /tmp/wp_result_ok ] && WP_RESULT_OK=$(sed -n 1p /tmp/wp_result_ok 2>/dev/null)
rm -f /tmp/wp_result /tmp/wp_result_ok
WP_URL=""
[ -f "$WPFILE" ] && WP_URL=$(head -c 512 "$WPFILE" 2>/dev/null | tr -d '\r\n')
wp_valid "$WP_URL" || WP_URL=""
# 当前 WAN 口：/etc/net_port_mode 标记 NETPORT=p1/p2/all；无文件或 p0 = 出厂（LAN0）
NET_PORT="p0"
grep -q 'NETPORT=p1' /etc/net_port_mode 2>/dev/null && NET_PORT="p1"
grep -q 'NETPORT=p2' /etc/net_port_mode 2>/dev/null && NET_PORT="p2"
grep -q 'NETPORT=all' /etc/net_port_mode 2>/dev/null && NET_PORT="all"
# 当前模式：metric 5=有线优先；auto=0=仅4G；firewall.user 有拦截=仅有线；否则 4G 优先
NET_MODE="4g"
NMV=$(uci -q get network.wan.metric 2>/dev/null)
[ "$NMV" = "5" ] && NET_MODE="wan"
[ "$(uci -q get network.wan.auto 2>/dev/null)" = "0" ] && NET_MODE="only4g"
grep -q 'toolbox net-onlywan' /etc/firewall.user 2>/dev/null && NET_MODE="onlywan"
NP0=""; NP1=""; NP2=""; NALL=""
[ "$NET_PORT" = "p0" ] && NP0="checked"
[ "$NET_PORT" = "p1" ] && NP1="checked"
[ "$NET_PORT" = "p2" ] && NP2="checked"
[ "$NET_PORT" = "all" ] && NALL="checked"
NM4=""; NMW=""; NM4G=""; NMWG=""
[ "$NET_MODE" = "4g" ] && NM4="checked"
[ "$NET_MODE" = "wan" ] && NMW="checked"
[ "$NET_MODE" = "only4g" ] && NM4G="checked"
[ "$NET_MODE" = "onlywan" ] && NMWG="checked"


echo "Content-Type: text/html; charset=utf-8"
echo "Cache-Control: no-store, no-cache, must-revalidate"
echo "Pragma: no-cache"
echo ""

cat << 'HTMLEOF'
<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>蜂助手 S1 工具箱</title>
<style>
:root{
  --accent:#4f46e5;--accent2:#6366f1;--accent-rgb:79,70,229;
  --danger:#e74c3c;--danger-rgb:231,76,60;--warn:#f39c12;--warn-rgb:243,156,18;
  --ok:#27ae60;--ok-rgb:39,174,96;
  --radius:16px;--radius-sm:10px;--radius-xs:6px;
  --transition:.28s cubic-bezier(.4,0,.2,1);
  --font:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif;
  --mono:'SF Mono','Fira Code',Consolas,'Courier New',monospace;
  --grad-1:linear-gradient(135deg,#4f46e5,#6366f1);
  --grad-2:linear-gradient(135deg,#6c5ce7,#a29bfe);
  --grad-3:linear-gradient(135deg,#e17055,#fab1a0);
  --grad-4:linear-gradient(135deg,#fd79a8,#e84393);
  --grad-5:linear-gradient(135deg,#0984e3,#74b9ff);
  --grad-6:linear-gradient(135deg,#fdcb6e,#f39c12);
  --grad-7:linear-gradient(135deg,#a29bfe,#6c5ce7);
  --sh-1:rgba(79,70,229,.25);--sh-2:rgba(108,92,231,.25);--sh-3:rgba(225,112,85,.25);
  --sh-4:rgba(253,121,168,.25);--sh-5:rgba(9,132,227,.25);--sh-6:rgba(243,156,18,.25);
}
html[data-theme="dark"]{
  --bg:#0d1117;--bg2:#161b22;--card:rgba(28,35,50,.72);--card2:rgba(33,41,58,.6);
  --border:rgba(48,54,61,.6);--border2:rgba(61,68,81,.5);
  --text:#e6edf3;--text2:#8b949e;--text3:#6e7681;
  --input-bg:rgba(13,17,23,.6);--input-border:rgba(48,54,61,.8);
  --tab-bg:transparent;--tab-active:rgba(28,35,50,.6);--tab-hover:rgba(33,41,58,.4);
  --header-bg:rgba(13,17,23,.44);--overlay:rgba(0,0,0,.6);
  --shadow:0 8px 32px rgba(0,0,0,.4);--shadow-sm:0 2px 12px rgba(0,0,0,.25);
  --page-bg:linear-gradient(135deg,#0d1117 0%,#111820 50%,#0d1117 100%);
}
html[data-theme="light"]{
  --bg:#f0f2f5;--bg2:#e8eaed;--card:rgba(255,255,255,.82);--card2:rgba(246,248,250,.7);
  --border:rgba(208,215,222,.5);--border2:rgba(201,209,217,.4);
  --text:#1f2328;--text2:#656d76;--text3:#8c959f;
  --input-bg:rgba(255,255,255,.9);--input-border:rgba(208,215,222,.8);
  --tab-bg:transparent;--tab-active:rgba(255,255,255,.5);--tab-hover:rgba(243,244,246,.5);
  --header-bg:rgba(255,255,255,.38);--overlay:rgba(255,255,255,.6);
  --shadow:0 8px 32px rgba(0,0,0,.06);--shadow-sm:0 2px 12px rgba(0,0,0,.04);
  --page-bg:linear-gradient(135deg,#f0f2f5 0%,#e8ecf1 50%,#f0f2f5 100%);
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:var(--font);font-size:15px;color:var(--text);background:var(--page-bg);min-height:100vh;-webkit-font-smoothing:antialiased}
#wallpaper{position:fixed;inset:0;z-index:-1;background-size:cover;background-position:center;background-repeat:no-repeat;opacity:0}
.header{position:sticky;top:0;z-index:100;background:transparent;border-bottom:none;transition:all var(--transition)}
/* 玻璃层独立成 ::before：均匀磨砂（不渐隐、无实线、去 saturate）—— 浓度/模糊经真机评审判定为 .38 / 34px */
.header::before{content:'';position:absolute;inset:0;z-index:-1;background:var(--header-bg);backdrop-filter:blur(34px);-webkit-backdrop-filter:blur(34px)}
.header-inner{max-width:1200px;margin:0 auto;padding:12px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px}
.logo{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:600;color:var(--text);white-space:nowrap}
.logo-box{width:34px;height:34px;border-radius:10px;background:var(--grad-1);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px var(--sh-1);flex-shrink:0}
.logo-box svg{width:18px;height:18px;color:#fff;stroke:#fff}
.header-actions{display:flex;align-items:center;gap:8px}
.icon-btn{width:38px;height:38px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text2);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all var(--transition);flex-shrink:0;backdrop-filter:blur(8px)}
.icon-btn:hover{color:var(--accent);border-color:var(--accent);transform:translateY(-2px);box-shadow:0 4px 14px var(--sh-1)}
.icon-btn svg{width:18px;height:18px}
.tabs{max-width:1200px;margin:0 auto;padding:0 8px;display:flex;gap:2px;overflow-x:auto;scrollbar-width:none}
.tabs::-webkit-scrollbar{display:none}
.tab{flex:1;min-width:64px;padding:10px 4px;border:none;background:var(--tab-bg);color:var(--text);opacity:.85;cursor:pointer;font-size:13px;font-family:var(--font);display:flex;flex-direction:column;align-items:center;gap:5px;border-radius:var(--radius-sm) var(--radius-sm) 0 0;transition:all var(--transition);position:relative;border-bottom:2px solid transparent}
.tab svg{width:20px;height:20px;transition:transform var(--transition)}
.tab:hover{color:var(--text);background:var(--tab-hover);opacity:1}
.tab.active{color:var(--accent);background:var(--tab-active);border-bottom-color:var(--accent);opacity:1}
.tab.active svg{transform:scale(1.15)}
.container{max-width:1200px;margin:0 auto;padding:18px}
.page{display:none}
.page.active{display:block}
@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
.card{background:var(--card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid var(--border);border-radius:var(--radius);padding:20px 22px;margin-bottom:18px;box-shadow:var(--shadow-sm);transition:transform var(--transition),box-shadow var(--transition),border-color var(--transition);position:relative;overflow:hidden}
.card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(var(--accent-rgb),.15),transparent);opacity:0;transition:opacity var(--transition)}
.card:hover::before{opacity:1}
.card-title{font-size:16px;font-weight:600;margin-bottom:14px;display:flex;align-items:center;gap:10px}
.card-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.card-icon svg{width:18px;height:18px;color:#fff;stroke:#fff}
.card-icon.g1{background:var(--grad-1);box-shadow:0 3px 10px var(--sh-1)}
.card-icon.g2{background:var(--grad-2);box-shadow:0 3px 10px var(--sh-2)}
.card-icon.g3{background:var(--grad-3);box-shadow:0 3px 10px var(--sh-3)}
.card-icon.g4{background:var(--grad-4);box-shadow:0 3px 10px var(--sh-4)}
.card-icon.g5{background:var(--grad-5);box-shadow:0 3px 10px var(--sh-5)}
.card-icon.g6{background:var(--grad-6);box-shadow:0 3px 10px var(--sh-6)}
.card-icon.g7{background:var(--grad-7);box-shadow:0 3px 10px var(--sh-2)}
.card-desc{color:var(--text2);font-size:13px;margin-bottom:14px;line-height:1.6}
.btn{padding:10px 22px;font-size:14px;font-family:var(--font);font-weight:500;border:none;background:var(--grad-1);color:#fff;border-radius:var(--radius-sm);cursor:pointer;transition:all var(--transition);display:inline-flex;align-items:center;gap:6px;box-shadow:0 3px 12px var(--sh-1)}
.btn:hover{transform:translateY(-2px);box-shadow:0 6px 20px var(--sh-1)}
.btn:active{transform:translateY(0);box-shadow:0 2px 8px var(--sh-1)}
.btn-danger{background:linear-gradient(135deg,#e74c3c,#c0392b);box-shadow:0 3px 12px rgba(231,76,60,.25)}
.btn-danger:hover{box-shadow:0 6px 20px rgba(231,76,60,.35)}
.btn-sm{padding:7px 16px;font-size:13px}
input[type=text],input[type=password],select{padding:9px 13px;border:1px solid var(--input-border);border-radius:var(--radius-sm);background:var(--input-bg);color:var(--text);font-size:14px;font-family:var(--font);transition:all var(--transition);outline:none}
input[type=text]:focus,input[type=password]:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.12)}
input.imeiin{width:200px}
label{cursor:pointer;display:inline-flex;align-items:center;gap:6px}
.row{margin:8px 0}
.sub{color:var(--text2);font-size:13px;margin-bottom:6px}
.sep{border-top:1px dashed var(--border2);margin:16px 0 12px}
.note{color:var(--text2);font-size:13px;margin-top:8px;line-height:1.6}
.msg{padding:12px 16px;margin:12px 0;border-radius:var(--radius-sm);font-size:14px}
.ok{background:rgba(var(--ok-rgb),.08);border:1px solid rgba(var(--ok-rgb),.3);color:var(--ok)}
.err{background:rgba(var(--danger-rgb),.08);border:1px solid rgba(var(--danger-rgb),.3);color:var(--danger)}
.info{background:var(--card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid var(--border);border-radius:var(--radius);padding:18px 22px;margin-bottom:18px;line-height:2.4;box-shadow:var(--shadow-sm);position:relative;overflow:hidden}
.info::before{content:'';position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--grad-1);border-radius:2px}
.info b{display:inline-block;min-width:100px;color:var(--text)}
.info-empty{color:var(--text3)}
.stamp{color:var(--accent);font-size:12px}
.maskv{display:inline-block;white-space:pre;font-family:var(--mono);letter-spacing:1px}
.eye{color:var(--text3);cursor:pointer;opacity:.5;display:inline-block;vertical-align:-3px;transition:opacity .15s;user-select:none}
.eye:hover{opacity:1}
.sig-bar{display:inline-block;width:5px;background:var(--grad-1);margin-right:2px;vertical-align:bottom;border-radius:1px;transition:all var(--transition)}
.refresh{background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);cursor:pointer;padding:6px 12px;color:var(--text2);font-size:13px;font-family:var(--font);display:inline-flex;align-items:center;gap:5px;transition:all var(--transition);backdrop-filter:blur(8px)}
.refresh:hover{border-color:var(--accent);color:var(--accent);transform:translateY(-1px)}
#page-dashboard{position:relative}
.rf-corner{position:absolute;top:14px;right:20px;z-index:6;display:flex;flex-direction:column;align-items:flex-end;gap:4px;max-width:calc(100% - 36px);text-align:right;transition:transform var(--transition),box-shadow var(--transition)}
.rf-line{display:flex;align-items:center;gap:6px;justify-content:flex-end;flex-wrap:wrap}
.rf-corner>.auto{margin-left:0}
.rf-corner>.auto:empty{display:none}
/* 让刷新区跟着上面那张卡的悬停浮动一起动（两者位移与过渡完全对齐） */
#info:has(> .gauge-card:hover) ~ .rf-corner{transform:translateY(-2px)}
#info:hover ~ .rf-corner{transform:translateY(-2px)}
.refresh.spin svg{animation:spin .9s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.auto{color:var(--text3);font-size:12px;margin-left:8px}
.spinner{width:40px;height:40px;border:4px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:sp 1s linear infinite;margin:0 auto 14px}
@keyframes sp{to{transform:rotate(360deg)}}
.bandgrid{display:grid;grid-template-columns:1fr 1fr;gap:8px 14px;margin:12px 0}
.bandgrid label{padding:10px 8px;border-radius:var(--radius-sm);transition:all var(--transition);border:1px solid transparent}
.bandgrid label:hover{background:var(--card2);border-color:var(--border)}
.bandgrid .fdd{color:var(--text)}
.bandgrid .tdd{color:var(--text2)}
.portstrip{display:flex;justify-content:center;gap:18px;background:var(--card2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin:8px 0}
.port{position:relative;display:flex;flex-direction:column;align-items:center;cursor:pointer;padding:10px 12px;border-radius:var(--radius-sm);transition:all var(--transition)}
.port input{position:absolute;opacity:0}
.port .jack{width:56px;height:38px;border:2px solid var(--border2);border-radius:6px;background:var(--bg2);display:block;position:relative;transition:all .18s}
.port .jack i{position:absolute;left:50%;top:58%;transform:translateX(-50%);width:28px;height:14px;background:var(--border);border:1px solid var(--border2);border-radius:0 0 4px 4px}
.port .plabel{font-size:13px;color:var(--text2);margin-top:7px;font-family:var(--mono)}
.port .rlan,.port .rwan{font-size:12px;margin-top:4px;padding:2px 10px;border-radius:4px}
.port .rlan{color:var(--text3);background:var(--card2)}
.port .rwan{display:none;color:#fff;background:var(--accent);font-weight:bold}
.port input:checked ~ .jack{background:rgba(var(--ok-rgb),.12);border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.2)}
.port input:checked ~ .jack i{background:var(--accent);border-color:var(--accent)}
.port input:checked ~ .plabel{color:var(--accent);font-weight:bold}
.port input:checked ~ .rwan{display:inline}
.port input:checked ~ .rlan{display:none}
.port:hover .jack{border-color:var(--accent)}
.cellstate{font-family:var(--mono);background:var(--card2);border:1px solid var(--border);border-radius:6px;padding:7px 12px;display:inline-block;margin:4px 0}
.locked{color:var(--ok);font-weight:bold}
.unlocked{color:var(--text3)}
code{background:var(--card2);padding:3px 7px;border-radius:4px;font-size:13px;font-family:var(--mono)}
.setting-row{display:flex;align-items:center;justify-content:space-between;padding:14px 0;border-bottom:1px solid var(--border)}
.setting-row:last-child{border-bottom:none}
.setting-label{font-size:14px}
.setting-desc{font-size:12px;color:var(--text3);margin-top:3px}
.theme-switch{display:flex;gap:4px;background:var(--card2);border-radius:var(--radius-sm);padding:3px}
.theme-opt{padding:6px 14px;border:none;background:transparent;color:var(--text2);cursor:pointer;border-radius:7px;font-size:13px;font-family:var(--font);transition:all var(--transition)}
.theme-opt.active{background:var(--grad-1);color:#fff;box-shadow:0 2px 8px var(--sh-1)}
table{border-collapse:collapse;margin:8px 0;width:100%}
td,th{border:1px solid var(--border);padding:7px 14px;text-align:left}
th{background:var(--card2);color:var(--text2);font-weight:500}
@media(max-width:640px){
  .container{padding:12px}.card{padding:16px 18px}
  .rf-corner{position:static;margin:10px 0 0;align-items:flex-start;text-align:left}
  .tab{font-size:11px;min-width:48px;padding:8px 2px}.tab svg{width:18px;height:18px}.tab-label{display:none}
  .bandgrid{grid-template-columns:1fr 1fr;gap:4px 8px}.bandgrid label{padding:10px 4px;font-size:14px}
  .btn{display:block;width:100%;text-align:center;margin:8px 0}
  input[type=text],input[type=password],select{width:100%}input.imeiin{width:100%}.maskv{width:auto}
  .info b{display:block;min-width:0}.portstrip{gap:8px;padding:10px}
  .logo{font-size:16px}.header-inner{padding:8px 12px}
}
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
/* === v3: Dashboard Redesign === */
.gauge-card{background:var(--card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid var(--border);border-radius:var(--radius);padding:24px 22px 20px;margin-bottom:18px;box-shadow:var(--shadow-sm);text-align:center;position:relative;overflow:hidden;transition:transform var(--transition),box-shadow var(--transition)}
.gauge-card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.gauge-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--grad-1);opacity:.6}
.gauge-wrap{display:flex;align-items:center;justify-content:center;gap:24px;flex-wrap:wrap}
.gauge{position:relative;width:160px;height:160px;flex-shrink:0}
.gauge-svg{width:160px;height:160px;transform:rotate(135deg)}
.gauge-bg-arc{fill:none;stroke:var(--border);stroke-width:10;stroke-linecap:round}
.gauge-arc{fill:none;stroke-width:10;stroke-linecap:round;transition:stroke-dashoffset .8s cubic-bezier(.4,0,.2,1)}
.gauge-center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}
.gauge-value{font-size:32px;font-weight:700;color:var(--text);font-variant-numeric:tabular-nums;letter-spacing:-1px}
.gauge-unit{font-size:13px;color:var(--text3);margin-top:-2px}
.gauge-label{font-size:13px;color:var(--text2);margin-top:8px}
.gauge-side{display:flex;flex-direction:column;gap:12px;min-width:140px}
.gauge-side-row{display:flex;align-items:center;gap:8px}
.gauge-side-label{font-size:12px;color:var(--text3);min-width:48px}
.gauge-side-val{font-size:15px;font-weight:600;color:var(--text);font-variant-numeric:tabular-nums}
.stat-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px}
.stat-card{background:var(--card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid var(--border);border-radius:var(--radius);padding:16px 18px;box-shadow:var(--shadow-sm);transition:all var(--transition);position:relative;overflow:hidden}
.stat-card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;opacity:.5}
.stat-card.sc1::before{background:var(--grad-1)}.stat-card.sc2::before{background:var(--grad-2)}
.stat-card.sc3::before{background:var(--grad-3)}.stat-card.sc4::before{background:var(--grad-5)}
.stat-icon{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;margin-bottom:10px}
.stat-icon svg{width:16px;height:16px;color:#fff;stroke:#fff}
.stat-card.sc1 .stat-icon{background:var(--grad-1);box-shadow:0 2px 8px var(--sh-1)}
.stat-card.sc2 .stat-icon{background:var(--grad-2);box-shadow:0 2px 8px var(--sh-2)}
.stat-card.sc3 .stat-icon{background:var(--grad-3);box-shadow:0 2px 8px var(--sh-3)}
.stat-card.sc4 .stat-icon{background:var(--grad-5);box-shadow:0 2px 8px var(--sh-5)}
.stat-label{font-size:12px;color:var(--text3);margin-bottom:4px}
.stat-value{font-size:18px;font-weight:600;color:var(--text);line-height:1.3}
.stat-sub{font-size:12px;color:var(--text2);margin-top:3px}
.id-card{background:var(--card);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid var(--border);border-radius:var(--radius);padding:18px 22px;margin-bottom:18px;box-shadow:var(--shadow-sm);transition:all var(--transition)}
.id-card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.id-row{display:flex;align-items:center;gap:10px;padding:8px 0}
.id-row+.id-row{border-top:1px solid var(--border2)}
.id-label{font-size:13px;color:var(--text3);min-width:56px;font-weight:500}
.id-val{font-family:var(--mono);font-size:16px;color:var(--text);letter-spacing:1px;flex:1}
.id-eye{color:var(--text3);cursor:pointer;opacity:.5;transition:opacity .15s;user-select:none}
.id-eye:hover{opacity:1}
.id-time{text-align:center;color:var(--accent);font-size:12px;margin-top:10px;padding-top:10px;border-top:1px solid var(--border2)}
/* Tab slide indicator */
.tab-indicator{position:absolute;bottom:0;height:2px;background:var(--grad-1);border-radius:2px;transition:left .3s cubic-bezier(.4,0,.2,1),width .3s cubic-bezier(.4,0,.2,1);box-shadow:0 0 8px var(--sh-1)}
/* Page slide transitions */
.page.slide-left{animation:slideLeft .25s cubic-bezier(.4,0,.2,1) both}
.page.slide-right{animation:slideRight .25s cubic-bezier(.4,0,.2,1) both}
@keyframes slideLeft{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:translateX(0)}}
@keyframes slideRight{from{opacity:0;transform:translateX(-12px)}to{opacity:1;transform:translateX(0)}}
/* Staggered card animation */
.stagger{animation:staggerIn .3s cubic-bezier(.4,0,.2,1) both}
@keyframes staggerIn{from{opacity:0}to{opacity:1}}
/* Skeleton loading */
.skeleton{background:linear-gradient(90deg,var(--card2) 25%,var(--border) 50%,var(--card2) 75%);background-size:200% 100%;animation:shimmer 1.5s infinite;border-radius:var(--radius-sm)}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
.skeleton-gauge{width:160px;height:160px;border-radius:50%;margin:0 auto}
.skeleton-text{height:16px;margin:8px 0;border-radius:4px}
.skeleton-stat{height:80px;border-radius:var(--radius)}
@media(max-width:640px){
  .gauge-wrap{flex-direction:column;gap:16px}
  .gauge-side{min-width:0;width:100%}
  .stat-grid{grid-template-columns:1fr 1fr;gap:10px}
  .stat-card{padding:14px 16px}
  .gauge-value{font-size:28px}
}
/* === v3 round 2: points 5,7,9,10 === */

/* Point 9: Dark mode personality - deep blue-purple base + inner glow */
html[data-theme="dark"]{
  --bg:#0a0e1a;--bg2:#111729;--card:rgba(18,24,45,.65);--card2:rgba(22,30,55,.5);
  --border:rgba(80,100,180,.12);--border2:rgba(80,100,180,.08);
  --text:#e2e8f0;--text2:#94a3b8;--text3:#64748b;
  --input-bg:rgba(10,14,26,.6);--input-border:rgba(80,100,180,.2);
  --tab-bg:transparent;--tab-active:rgba(30,40,70,.5);--tab-hover:rgba(25,35,60,.3);
  --header-bg:rgba(10,14,26,.44);--overlay:rgba(0,0,0,.7);
  --shadow:0 8px 32px rgba(0,0,0,.5);--shadow-sm:0 2px 12px rgba(0,0,0,.3);
  --page-bg:linear-gradient(135deg,#0a0e1a 0%,#0f1525 40%,#0a1020 70%,#0a0e1a 100%);
}
html[data-theme="dark"] .card{
  box-shadow:var(--shadow-sm),inset 0 1px 0 rgba(120,140,220,.06);
  border-color:rgba(80,100,180,.1);
}
html[data-theme="dark"] .card:hover{
  box-shadow:var(--shadow),inset 0 1px 0 rgba(120,140,220,.1);
}
html[data-theme="dark"] .gauge-card{
  box-shadow:0 8px 40px rgba(0,0,0,.4),inset 0 1px 0 rgba(120,140,220,.08);
}
html[data-theme="dark"] .stat-card{
  box-shadow:0 4px 20px rgba(0,0,0,.3),inset 0 1px 0 rgba(120,140,220,.05);
}

/* Point 5: Background blur orbs per page */
.bg-orbs{position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none}
.bg-orbs .orb{position:absolute;border-radius:50%;filter:blur(80px);opacity:.35;animation:orbFloat 20s ease-in-out infinite}
.bg-orbs .orb1{width:300px;height:300px;background:var(--accent);top:-100px;right:-80px;animation-delay:0s}
.bg-orbs .orb2{width:250px;height:250px;background:#6c5ce7;bottom:-80px;left:-60px;animation-delay:-7s}
.bg-orbs .orb3{width:200px;height:200px;background:#fd79a8;top:40%;left:60%;opacity:.2;animation-delay:-14s}
html[data-theme="dark"] .bg-orbs .orb{opacity:.15}
html[data-theme="dark"] .bg-orbs .orb3{opacity:.1}
@keyframes orbFloat{0%,100%{transform:translate(0,0) scale(1)}33%{transform:translate(30px,-20px) scale(1.1)}66%{transform:translate(-20px,30px) scale(.95)}}

/* Point 10: Toggle switches for band page */
.toggle-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}
.toggle-row{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-radius:var(--radius-sm);background:var(--card2);border:1px solid var(--border);transition:all var(--transition)}
.toggle-row:hover{border-color:rgba(var(--accent-rgb),.3)}
.toggle-row.active{border-color:var(--accent);background:rgba(var(--accent-rgb),.08)}
.toggle-row .tg-label{font-size:14px;font-weight:500;display:flex;align-items:center;gap:8px}
.toggle-row .tg-tag{font-size:11px;padding:2px 6px;border-radius:4px;font-weight:600}
.toggle-row .tg-tag.fdd{background:rgba(var(--accent-rgb),.15);color:var(--accent)}
.toggle-row .tg-tag.tdd{background:rgba(243,156,18,.15);color:var(--warn)}
.toggle-switch{position:relative;width:44px;height:24px;flex-shrink:0}
.toggle-switch input{opacity:0;width:0;height:0;position:absolute}
.toggle-slider{position:absolute;inset:0;cursor:pointer;background:var(--border2);border-radius:24px;transition:var(--transition);border:1px solid var(--border)}
.toggle-slider:before{position:absolute;content:"";height:18px;width:18px;left:2px;top:2px;background:#fff;border-radius:50%;transition:var(--transition);box-shadow:0 2px 4px rgba(0,0,0,.2);z-index:1}
.toggle-slider:after{position:absolute;content:"";left:6px;top:50%;width:10px;height:6px;border-left:2px solid #fff;border-bottom:2px solid #fff;transform:translateY(-65%) rotate(-45deg) scale(0);opacity:0;transition:all .2s ease .05s;z-index:2}
.toggle-switch input:checked+.toggle-slider{background:var(--grad-1);border-color:transparent}
.toggle-switch input:checked+.toggle-slider:before{transform:translateX(20px)}
.toggle-switch input:checked+.toggle-slider:after{opacity:1;transform:translateY(-65%) rotate(-45deg) scale(1);transition:all .25s ease .15s}
.toggle-switch input:disabled+.toggle-slider{opacity:.4;cursor:not-allowed}
.band-section-title{font-size:13px;font-weight:600;color:var(--text2);margin:16px 0 8px;display:flex;align-items:center;gap:6px}
.band-section-title .dot{width:6px;height:6px;border-radius:50%}
.band-section-title .dot.fdd{background:var(--accent)}
.band-section-title .dot.tdd{background:var(--warn)}
.cell-status-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 14px}
.cell-status-item{background:var(--card2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 12px;display:flex;flex-direction:column;gap:4px}
.cell-status-label{font-size:11px;color:var(--text3);font-weight:500}
.cell-status-item .cellstate{font-size:14px;font-weight:600;color:var(--text)}
.cell-info-card{background:var(--card2);border:1px solid var(--border);border-radius:var(--radius);padding:14px 16px;margin:0 0 12px;transition:all var(--transition)}
.cell-info-header{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.cell-info-icon{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:#fff}
.cell-info-icon.live{background:var(--grad-1)}
.cell-info-icon.lock{background:linear-gradient(135deg,#6c5ce7,#a55eea)}
.cell-info-icon.offline{background:var(--text3);opacity:.6}
.cell-info-icon svg{width:18px;height:18px}
.cell-info-title{font-size:14px;font-weight:600;color:var(--text)}
.cell-info-sub{font-size:11px;color:var(--text3);margin-top:1px}
.cell-info-metrics{display:flex;gap:8px;flex-wrap:wrap}
.cell-metric{flex:1;min-width:70px;text-align:center;background:var(--card);border:1px solid var(--border);border-radius:8px;padding:8px 10px}
.cell-metric-label{font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.5px}
.cell-metric-value{font-size:18px;font-weight:700;color:var(--text);margin-top:3px;font-variant-numeric:tabular-nums}
.cell-metric.band .cell-metric-value{color:var(--accent)}
.cell-info-empty{font-size:13px;color:var(--text3);padding:10px 0;text-align:center;background:var(--card);border:1px solid var(--border);border-radius:8px}
.cell-lock-card{background:var(--card2);border:1px solid var(--border);border-radius:var(--radius);padding:12px 16px;margin:0 0 14px;display:flex;align-items:center;gap:10px;transition:all var(--transition)}
.cell-lock-card.locked{border-color:rgba(108,92,231,.3)}
.cell-lock-text{font-size:13px;color:var(--text2);line-height:1.4}
.cell-lock-text .lock-detail{font-weight:600;color:var(--text)}
.band-status-card{background:var(--card2);border:1px solid var(--border);border-radius:var(--radius);padding:14px 16px;margin:0 0 14px;transition:all var(--transition)}
.band-status-header{display:flex;align-items:center;gap:10px;margin-bottom:10px}
.band-status-icon{width:32px;height:32px;border-radius:8px;background:var(--grad-1);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:#fff}
.band-status-icon svg{width:18px;height:18px}
.band-status-title{font-size:14px;font-weight:600;color:var(--text)}
.band-status-count{font-size:12px;color:var(--text3);margin-top:2px}
.band-badges{display:flex;flex-wrap:wrap;gap:6px}
.band-badge{font-size:12px;font-weight:600;padding:3px 10px;border-radius:20px;display:inline-flex;align-items:center;gap:4px}
.band-badge.fdd{background:rgba(var(--accent-rgb),.12);color:var(--accent);border:1px solid rgba(var(--accent-rgb),.25)}
.band-badge.tdd{background:rgba(243,156,18,.12);color:var(--warn);border:1px solid rgba(243,156,18,.25)}
.band-badge.empty{background:var(--card);color:var(--text3);border:1px solid var(--border)}
.band-status-dirty{font-size:12px;color:var(--warn);margin-top:8px;display:flex;align-items:center;gap:4px}
#page-settings.active{display:grid;gap:14px}
#page-settings .card{margin-bottom:0}
@media(min-width:520px){#page-settings.active{grid-template-columns:1fr 1fr}#page-settings .card:last-child{grid-column:1/-1}}

/* Point 7: Toast notifications */
.toast-wrap{position:fixed;top:0;left:0;right:0;z-index:9999;pointer-events:none;display:flex;flex-direction:column;align-items:center;padding-top:70px}
.toast{pointer-events:auto;margin-bottom:8px;padding:12px 20px;border-radius:var(--radius-sm);background:var(--card);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:0 8px 32px rgba(0,0,0,.2);border:1px solid var(--border);font-size:14px;display:flex;align-items:center;gap:10px;animation:toastIn .35s cubic-bezier(.4,0,.2,1);max-width:90vw}
.toast.ok{border-left:3px solid var(--ok)}
.toast.err{border-left:3px solid var(--danger)}
.toast.warn{border-left:3px solid var(--warn)}
.toast.out{animation:toastOut .3s cubic-bezier(.4,0,.2,1) forwards}
@keyframes toastIn{from{transform:translateY(-120%);opacity:0}to{transform:translateY(0);opacity:1}}
@keyframes toastOut{to{transform:translateY(-120%);opacity:0}}
.toast-icon{width:20px;height:20px;flex-shrink:0}

/* Point 7: Button ripple */
.btn{position:relative;overflow:hidden}
.ripple{position:absolute;border-radius:50%;background:rgba(255,255,255,.3);transform:scale(0);animation:rippleAnim .6s ease-out;pointer-events:none}
@keyframes rippleAnim{to{transform:scale(4);opacity:0}}

/* Point 6: Card hierarchy */
.card.compact{padding:14px 16px;margin-bottom:12px}
.card.compact .card-title{font-size:14px;margin-bottom:8px}
.card.compact .card-icon{width:30px;height:30px}
.card.compact .card-icon svg{width:15px;height:15px}

/* Better note styling */
.note{color:var(--text3);font-size:12px;line-height:1.7;margin:8px 0;padding:8px 12px;border-radius:var(--radius-xs);background:var(--card2);border:1px solid var(--border)}
.note,.cellstate,.card-desc,.rf-corner>.auto{overflow-wrap:anywhere}
span.note{display:inline-block;padding:4px 10px;margin:5px 0;line-height:1.5;font-size:12px}
#wp-status{color:var(--text2)}   /* 壁纸链接是要核对的数据，不用最浅的提示灰 */
.pwmsg{font-size:13px;margin-left:8px;vertical-align:middle}
input[type=file]{font-size:13px;color:var(--text2);max-width:100%}
input[type=file]::file-selector-button{margin-right:10px;padding:7px 14px;border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--card);color:var(--text);cursor:pointer;font-size:13px}
input[type=file]::file-selector-button:hover{border-color:var(--accent);color:var(--accent)}
/* ==== 宽屏（≥1024px）：铺开内容，桌面不再是一条窄带 ==== */
@media(min-width:1024px){
  .stat-grid{grid-template-columns:repeat(4,1fr)}
  .toggle-grid{grid-template-columns:repeat(4,1fr)}
  .bandgrid{grid-template-columns:repeat(4,1fr)}
  #page-settings.active{grid-template-columns:repeat(3,1fr)}
  #page-settings .card:last-child{grid-column:auto}
  .card,.info,.gauge-card{padding:22px 26px}
  .gauge-wrap{justify-content:space-evenly}
  .gauge{width:190px;height:190px}
  .gauge-svg{width:190px;height:190px}
  .gauge-value{font-size:36px}
  .container{padding:22px}
}
</style>
</head>
<body>
<div id="wallpaper"></div>
<div class="bg-orbs"><div class="orb orb1"></div><div class="orb orb2"></div><div class="orb orb3"></div></div>
HTMLEOF
cat << 'HTMLEOF'
<div class="header">
  <div class="header-inner">
    <div class="logo">
      <div class="logo-box">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7l10 5 10-5-10-5zM2 12l10 5 10-5-10-5-10 5zM2 17l10 5 10-5-10-5-10 5z"/></svg>
      </div>
      蜂助手 S1 工具箱
    </div>
    <div class="header-actions">
      <button class="icon-btn" id="themeToggle" onclick="toggleTheme()" title="切换主题">
        <svg id="themeIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
      </button>
      <button class="icon-btn" onclick="switchTab('settings')" title="设置">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
      </button>
    </div>
  </div>
  <div class="tabs" id="tabs">
    <button class="tab active" onclick="switchTab('dashboard')" data-tab="dashboard">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 3h8v8H3V3zm10 0h8v5h-8V3zm0 7h8v11h-8V10zM3 13h8v8H3v-8z"/></svg>
      <span class="tab-label">数据面板</span>
    </button>
    <button class="tab" onclick="switchTab('imei')" data-tab="imei">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 1h10a2 2 0 0 1 2 2v18a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm5 19a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/></svg>
      <span class="tab-label">IMEI 改串</span>
    </button>
    <button class="tab" onclick="switchTab('band')" data-tab="band">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z"/></svg>
      <span class="tab-label">锁频段</span>
    </button>
    <button class="tab" onclick="switchTab('cell')" data-tab="cell">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg>
      <span class="tab-label">锁频点/小区</span>
    </button>
    <button class="tab" onclick="switchTab('network')" data-tab="network">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-8 10c0-.7.09-1.36.26-2h15.48c.17.64.26 1.3.26 2s-.09 1.36-.26 2H4.26A8.04 8.04 0 0 1 4 12zm1.07-4h13.86A8 8 0 0 1 12 4a8 8 0 0 1-6.93 4zm0 8h13.86A8 8 0 0 1 12 20a8 8 0 0 1-6.93-4z"/></svg>
      <span class="tab-label">网口优先级</span>
    </button>
    <button class="tab" onclick="switchTab('password')" data-tab="password">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 10V8a6 6 0 0 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h1zm2 0h8V8a4 4 0 0 0-8 0v2z"/></svg>
      <span class="tab-label">管理密码</span>
    </button>
    <button class="tab" onclick="switchTab('settings')" data-tab="settings">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
      <span class="tab-label">设置</span>
    </button>
    <div class="tab-indicator" style="left:0;width:0"></div>
  </div>
</div>
<div class="container">
HTMLEOF
echo "<script>var WP_SERVER=\"$WP_URL\";</script>"
cat << 'JSEOF'
<script>
var LS={get:function(k){try{return localStorage.getItem(k)}catch(e){return null}},set:function(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
function getTheme(){return document.documentElement.getAttribute('data-theme')||'light'}
function setTheme(t){
  document.documentElement.setAttribute('data-theme',t);
  LS.set('ui-theme',t);
  var icon=document.getElementById('themeIcon');
  if(t==='dark'){icon.innerHTML='<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';}
  else{icon.innerHTML='<circle cx="12" cy="12" r="5"/><path d="M12 1v2"/><path d="M12 21v2"/><path d="M4.22 4.22l1.42 1.42"/><path d="M18.36 18.36l1.42 1.42"/><path d="M1 12h2"/><path d="M21 12h2"/><path d="M4.22 19.78l1.42-1.42"/><path d="M18.36 5.64l1.42-1.42"/>';}
  var opts=document.querySelectorAll('.theme-opt');
  opts.forEach(function(o){o.classList.toggle('active',o.dataset.theme===t);});
}
function toggleTheme(){setTheme(getTheme()==='dark'?'light':'dark');}
function switchTab(name){
  var TABS=['dashboard','imei','band','cell','network','password','settings'];
  var newIdx=TABS.indexOf(name),oldIdx=TABS.indexOf(LS.get('ui-tab')||'dashboard');
  var dir=newIdx>oldIdx?'slide-left':'slide-right';
  document.querySelectorAll('.tab').forEach(function(t){t.classList.toggle('active',t.dataset.tab===name);});
  /* Hide all pages and show active synchronously — no empty frame */
  var pages=document.querySelectorAll('.page');
  var activePage=null;
  pages.forEach(function(p){
    var isActive=p.id==='page-'+name;
    if(isActive){activePage=p;}
    p.className='page';
  });
  /* Move tab indicator immediately */
  var activeTab=document.querySelector('.tab.active');
  var indicator=document.querySelector('.tab-indicator');
  if(activeTab&&indicator){indicator.style.left=activeTab.offsetLeft+'px';indicator.style.width=activeTab.offsetWidth+'px';}
  /* Show active page immediately (same frame) — CSS animation still triggers */
  if(activePage){
    activePage.className='page active '+dir;
    activePage.addEventListener('animationend',function(){activePage.className='page active';},{once:true});
    /* Stagger cards */
    var cards=activePage.querySelectorAll('.card,.gauge-card,.stat-card,.id-card');
    cards.forEach(function(c,i){
      c.classList.remove('stagger');
      c.style.animationDelay=(i*30)+'ms';
    });
    void activePage.offsetHeight;
    cards.forEach(function(c){c.classList.add('stagger');});
  }
  if(name==='dashboard'&&!busy)loadAll(1);
  LS.set('ui-tab',name);
}
function wallpaperUrl(){return (typeof WP_SERVER==='string'&&WP_SERVER)?WP_SERVER:'';}
function wpStatus(url){
  var st=document.getElementById('wp-status');if(!st)return;
  if(url===undefined)url=wallpaperUrl();
  st.textContent=url?('当前壁纸（本机全局，所有浏览器一致）：'+url):'当前：纯色背景';
}
function applyWallpaper(url){
  if(url===undefined)url=wallpaperUrl();
  var el=document.getElementById('wallpaper');
  if(!el){wpStatus(url);return;}
  if(!url){el.style.backgroundImage='none';el.style.opacity='0';wpStatus('');return;}
  /* 用 CSS 背景直接显示：CSS 背景图【不参与】文档 load 事件，
     绝不会把桥接页 Toolbox.htm 的 8 秒超时拖出来（曾经就是这里用 <img> 预探测把 iframe 拖挂了） */
  el.style.backgroundImage='url("'+url+'")';el.style.opacity='1';
  wpStatus(url);
  /* 失败提示改成 load 之后再探测——此时无论快慢都影响不到任何东西 */
  if(document.readyState==='complete'){setTimeout(function(){wpProbe(url);},0);}
  else if(!window.__wpQueued){window.__wpQueued=1;window.addEventListener('load',function(){setTimeout(function(){wpProbe(wallpaperUrl());},0);});}
}
/* 只读探测：仅为"链接打不开时回退纯色 + 给提示"，不参与页面加载 */
function wpProbe(url){
  if(!url)return;
  var el=document.getElementById('wallpaper');if(!el)return;
  var p=new Image();
  p.onload=function(){wpStatus(url);};
  p.onerror=function(){
    el.style.backgroundImage='none';el.style.opacity='0';
    var st=document.getElementById('wp-status');
    if(st)st.textContent='壁纸加载失败（链接打不开 / 图床挂了 / 当前无外网）— 已回退纯色背景';
  };
  p.src=url;
}
function wpSubmit(f){
  var i=document.getElementById('wp-url');if(!i)return true;
  var u=(i.value||'').trim();
  if(u&&!/^https?:\/\//i.test(u)){alert('请填写 http:// 或 https:// 开头的图片链接');return false;}
  i.value=u;return true;
}
function wpClearField(){var i=document.getElementById('wp-url');if(i)i.value='';}
setTheme(LS.get('ui-theme')||'light');applyWallpaper();
var busy=0;var CELLBTN='';
function showWait(msg){
  PAUSED=1;if(timer)clearTimeout(timer);
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:var(--overlay);display:flex;align-items:center;justify-content:center;text-align:center;z-index:9999;backdrop-filter:blur(4px)';
  d.innerHTML='<div style="background:var(--card);padding:28px 40px;border-radius:12px;box-shadow:var(--shadow)"><div class="spinner"></div><p style="font-size:17px;margin:0;color:var(--text)">'+msg+'</p><p style="font-size:13px;color:var(--text3);margin:8px 0 0">请稍候，完成后自动刷新</p></div>';
  document.body.appendChild(d);
}
function buildNet(f){if(!confirm('将应用新的网络设置，期间网络会中断数秒。\n\n如果改动了 WAN 口，网线可能需要换到对应的插孔。\n\n确认应用？'))return false;showWait('正在应用网络设置，请稍候…');return true;}
/* Sync toggle-row active state with checkbox */
document.addEventListener("change",function(e){if(e.target.type==="checkbox"){var row=e.target.closest(".toggle-row");if(row)row.classList.toggle("active",e.target.checked);}});
function build(f){
  var low=parseInt(f.low_base.value)||0,high=parseInt(f.high_base.value)||0;
  var nl=low&~149,nh=high&~482;
  if(f.b1.checked)nl|=1;if(f.b3.checked)nl|=4;if(f.b5.checked)nl|=16;if(f.b8.checked)nl|=128;
  if(f.b34.checked)nh|=2;if(f.b38.checked)nh|=32;if(f.b39.checked)nh|=64;if(f.b40.checked)nh|=128;if(f.b41.checked)nh|=256;
  if(nl==0&&nh==0){alert('至少勾选一个频段！');return false;}
  var fbmsg='';
  if(nh==0&&nl!=0){fbmsg='\n\n⚠ 注意：移动卡会优先使用 TDD 频段。本次未勾选任何 TDD 频段，只保留 FDD 频段时，设备重启后可能反复重启数分钟才能重新驻网（会自动重试），请耐心等待。\n需要固定使用 FDD 的，建议改用下方 ③ 锁定频点 / 小区。';}
  f.low.value=''+nl;f.high.value=''+nh;
  if(!confirm('将应用频段：FDD='+nl+' TDD='+nh+'\n\n应用后设备将重新驻网并自动恢复拨号（约1分钟，无需重启）。'+fbmsg+'\n\n若约5分钟后仍无网络，点本页"恢复出厂频段"即可。'))return false;
  DIRTY=0;showWait('正在应用频段，请稍候…');return true;
}
function waitRestore(msg){if(!confirm(msg+'\n\n确认继续？'))return false;DIRTY=0;showWait(msg);return true;}
function buildCell(f){
  var btn=CELLBTN;CELLBTN='';
  if(btn==='clear'){if(!confirm('解除频点/小区锁定？\n\n设备将按正常规则重新驻网（约10-60秒）。'))return false;showWait('正在解除锁定，请稍候…');return true;}
  if(btn==='lock'){showWait('正在读取当前小区并锁定，请稍候…');return true;}
  var e=parseInt(f.cearfcn.value)||0;var p=(f.cpci.value||'').replace(/\s/g,'');
  if(!e){alert('请填写频点（EARFCN）；想锁定当前驻留的小区，请点"一键锁定当前"');return false;}
  if(e<0||e>65535){alert('频点数值超范围');return false;}
  if(p!==''&&(isNaN(parseInt(p))||parseInt(p)>503)){alert('PCI 范围为 0-503，留空则锁频点');return false;}
  var b=earfcnBand(e);
  if(!b){alert('频点 '+e+' 不在本设备支持的频段范围内\n（支持：B1/B3/B5/B8/B34/B38/B39/B40/B41）');return false;}
  var kind=(p==='')?('锁频点：B'+b+' / EARFCN '+e+'（同频点其他小区可接替）'):('锁小区：B'+b+' / EARFCN '+e+' / PCI '+p+'（该小区不可用时会无网）');
  var extra=(p==='')?'':'\n\n注意：锁小区后若该小区不可用，设备将无网，需点"解除锁定"恢复。';
  if(!confirm('将应用 '+kind+extra+'\n\n应用后设备会重新搜网（约10-60秒），期间短暂无网属正常。\n若 75 秒后仍无网，系统会自动解除锁定。'))return false;
  showWait('正在应用锁定，请稍候…');return true;
}
function earfcnBand(e){if(isNaN(e))return'';if(e>=0&&e<=599)return 1;if(e>=1200&&e<=1949)return 3;if(e>=2400&&e<=2649)return 5;if(e>=3450&&e<=3799)return 8;if(e>=36200&&e<=36349)return 34;if(e>=37750&&e<=38249)return 38;if(e>=38250&&e<=38649)return 39;if(e>=38650&&e<=39649)return 40;if(e>=39650&&e<=41589)return 41;return'';}
function bindEarfcnHint(){var i=document.getElementById('cearfcn'),h=document.getElementById('cearfcn_hint');if(!i||!h)return;function upd(){var v=parseInt(i.value)||0;if(!v){h.textContent='';return;}var b=earfcnBand(v);if(b){h.textContent='\u2192 频段 B'+b;h.style.color='var(--ok)';}else{h.textContent='\u2192 不在支持的频段范围';h.style.color='var(--danger)';}}i.oninput=upd;i.onchange=upd;upd();}
JSEOF

cat << 'JSEOF'
var REAL={imei:'',iccid:''},HID={imei:1,iccid:1};
var EYE_OPEN='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
var EYE_SHUT='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M1 1l22 22"/></svg>';
function dots(n){var s='';while(n-->0)s+='*';return s;}
function maskMid(v){v=v||'';if(!/^[0-9A-Za-z]+$/.test(v))return v;if(v.length<=8)return dots(v.length);return v.substr(0,4)+dots(v.length-8)+v.substr(v.length-4);}
function paint(k){var e=document.getElementById(k+'Val');if(e)e.textContent=HID[k]?maskMid(REAL[k]):(REAL[k]||'');var b=document.getElementById('eye_'+k);if(b)b.innerHTML=HID[k]?EYE_OPEN:EYE_SHUT;}
function tog(k){HID[k]=HID[k]?0:1;paint(k);}
function fitMask(){var im=document.getElementById('imeiVal'),ic=document.getElementById('iccidVal');if(!im||!ic)return;var probe=document.createElement('span');probe.style.cssText='position:absolute;visibility:hidden;white-space:pre;font-family:var(--mono);letter-spacing:1px';document.body.appendChild(probe);var w=0;[REAL.imei,REAL.iccid].forEach(function(v){probe.textContent=v||'';if(probe.offsetWidth>w)w=probe.offsetWidth;});document.body.removeChild(probe);if(w<60)w=60;im.style.width=(w+2)+'px';ic.style.width=(w+2)+'px';}
var AUTO_MS=6000,PAUSED=0,PENDING=0,DIRTY=0,timer=null,RETRY=0,MAX_RETRY=5,REQ_TIMEOUT=15000;
function setSpin(on){var b=document.getElementById('rfbtn');if(!b)return;if(on)b.className='refresh spin';else b.className='refresh';}
function setNote(msg){var n=document.getElementById('rfnote');if(n)n.innerHTML=msg||'';}
function finish(){busy=0;RETRY=0;setSpin(0);setNote('');next();}
function again(){busy=0;RETRY++;if(RETRY>MAX_RETRY){RETRY=0;setSpin(0);setNote('<span style="color:var(--warn)">设备持续忙碌，已停止重试；稍后再点刷新</span>');next();return;}setNote('<span style="color:var(--warn)">设备忙碌，重试中 '+RETRY+'/'+MAX_RETRY+'…</span>');if(timer)clearTimeout(timer);timer=setTimeout(function(){loadAll(0,1);},1500);}
function schedule(){if(timer)clearTimeout(timer);if(PAUSED)return;timer=setTimeout(function(){loadAll(1);},AUTO_MS);}
function next(){if(PENDING){PENDING=0;loadAll(0,1);return;}schedule();}
function checkPw(f){var a=f.pw1.value,b=f.pw2.value,tip=document.getElementById('pwtip');if(f.pw0&&!f.pw0.value){tip.className='pwmsg';tip.style.color='var(--danger)';tip.textContent='请输入当前密码';return false;}if(!a){tip.className='pwmsg';tip.style.color='var(--danger)';tip.textContent='请输入新密码';return false;}if(a.length<8){tip.className='pwmsg';tip.style.color='var(--danger)';tip.textContent='密码至少 8 位';return false;}if(a!==b){tip.className='pwmsg';tip.style.color='var(--danger)';tip.textContent='两次输入的密码不一致';return false;}tip.className='pwmsg';tip.style.color='var(--ok)';tip.textContent='提交中…';return true;}
function manualRefresh(){if(timer)clearTimeout(timer);if(busy){PENDING=1;return;}loadAll(0,1);}
document.addEventListener('visibilitychange',function(){if(document.hidden){if(timer)clearTimeout(timer);}else{if(!busy)loadAll(1);}});

/* Toast notifications (point 7) */
function showToast(msg,type){
  type=type||'ok';
  var wrap=document.querySelector('.toast-wrap');
  if(!wrap){wrap=document.createElement('div');wrap.className='toast-wrap';document.body.appendChild(wrap);}
  var icons={ok:'<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15l-5-5 1.4-1.4L10 14.2l7.6-7.6L19 8l-9 9z"/></svg>',err:'<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>',warn:'<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 21h22L12 2zm1 15h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>'};
  var t=document.createElement('div');t.className='toast '+type;
  t.innerHTML=(icons[type]||'')+'<span>'+msg+'</span>';
  wrap.appendChild(t);
  setTimeout(function(){t.classList.add('out');setTimeout(function(){t.remove();},300);},3000);
}
/* Button ripple (point 7) —— 仅 <button> 能承载子节点，<input type=submit> 跳过 */
document.addEventListener('click',function(e){
  var btn=e.target.closest('.btn');
  if(!btn||btn.tagName==='INPUT')return;
  var r=document.createElement('span');r.className='ripple';
  var rect=btn.getBoundingClientRect();var size=Math.max(rect.width,rect.height);
  r.style.width=r.style.height=size+'px';
  r.style.left=(e.clientX-rect.left-size/2)+'px';
  r.style.top=(e.clientY-rect.top-size/2)+'px';
  btn.appendChild(r);setTimeout(function(){r.remove();},600);
},true);
/* 结果提示条转 Toast：必须等消息元素渲染后再跑，故放到 body 末尾脚本 */
function loadAll(silent,force){
  if(busy)return;busy=1;setSpin(1);var spinAt=Date.now();var e=document.getElementById('info');
  if(!e.innerHTML||e.innerHTML.indexOf("skeleton")>=0){e.innerHTML='<span class="info-empty">正在读取设备数据，请稍候…</span>';}
  var x=new XMLHttpRequest();try{x.timeout=REQ_TIMEOUT;}catch(err){}
  var handled=0;
  function fail(){if(handled)return;handled=1;if(force){again();}else{finish();}}
  x.ontimeout=fail;x.onerror=fail;
  x.onreadystatechange=function(){
    if(x.readyState==4){if(handled)return;handled=1;var hold=Math.max(0,450-(Date.now()-spinAt));setTimeout(function(){
      var t=(x.responseText||'').trim();
      if(t=='BUSY'){if(force){again();}else{finish();}return;}
      if(x.status==200&&t.indexOf('BANDVAL=')>=0){
        var d={};t.split('\n').forEach(function(l){var p=l.indexOf('=');if(p>0)d[l.substring(0,p)]=l.substring(p+1);});
        if(force&&d.CACHED=='-1'){again();return;}
        var csq=parseInt(d.CSQ)||0;var rsrp=(d.RSRP&&d.RSRP!='?')?parseInt(d.RSRP):null;var q,lvl,dbm,dbmNum;
        if(rsrp!==null&&!isNaN(rsrp)){dbmNum=rsrp;dbm='RSRP '+rsrp+' dBm';if(rsrp>=-85){q='很强';lvl=4;}else if(rsrp>=-95){q='良好';lvl=3;}else if(rsrp>=-105){q='一般';lvl=2;}else{q='较弱';lvl=1;}}
        else if(d.CSQ=='?'){q='未知';lvl=0;dbm='';dbmNum=null;}
        else{dbmNum=2*csq-113;dbm='约 '+dbmNum+' dBm';if(csq>=26){q='很强';lvl=4;}else if(csq>=18){q='良好';lvl=3;}else if(csq>=10){q='一般';lvl=2;}else{q='较弱';lvl=1;}}
        var pct=0;if(dbmNum!==null){pct=Math.max(0,Math.min(100,(dbmNum+140)/96*100));}else{pct=lvl/4*100;}
        var R=70,C=2*Math.PI*R,arcLen=C*0.75,fillLen=arcLen*pct/100;
        var gc=pct>=75?'#27ae60':pct>=50?'#f39c12':pct>=25?'#e67e22':'#e74c3c';
        var netStatus=(d.DUPLEX!='?'&&d.BAND!='?')?('LTE '+d.DUPLEX+' B'+d.BAND):'未驻网';
        var operName=d.OPER||'未知';
        var gh='<div class="gauge-card"><div class="gauge-wrap"><div class="gauge"><svg class="gauge-svg" viewBox="0 0 160 160"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e74c3c"/><stop offset="0.5" stop-color="#f39c12"/><stop offset="1" stop-color="#27ae60"/></linearGradient></defs><circle class="gauge-bg-arc" cx="80" cy="80" r="'+R+'" stroke-dasharray="'+arcLen.toFixed(1)+' '+C.toFixed(1)+'"/><circle class="gauge-arc" cx="80" cy="80" r="'+R+'" stroke="url(#gg)" stroke-dasharray="'+fillLen.toFixed(1)+' '+C.toFixed(1)+'"/></svg><div class="gauge-center"><div class="gauge-value">'+(dbmNum!==null?dbmNum:'--')+'</div><div class="gauge-unit">dBm</div></div></div><div class="gauge-side"><div class="gauge-side-row"><span class="gauge-side-label">等级</span><span class="gauge-side-val" style="color:'+gc+'">'+q+'</span></div><div class="gauge-side-row"><span class="gauge-side-label">CSQ</span><span class="gauge-side-val">'+(d.CSQ=='?'?'--':csq)+'</span></div><div class="gauge-side-row"><span class="gauge-side-label">RSRP</span><span class="gauge-side-val">'+(rsrp!==null?rsrp:'--')+'</span></div></div></div></div>';
        var sh='<div class="stat-grid">';
        sh+='<div class="stat-card sc1"><div class="stat-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 21h18v-2H3v2zM6 17v-6h3v6H6zm5 0V7h3v10h-3zm5 0v-4h3v4h-3z"/></svg></div><div class="stat-label">运营商</div><div class="stat-value">'+operName+'</div></div>';
        sh+='<div class="stat-card sc2"><div class="stat-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z"/></svg></div><div class="stat-label">驻网频段</div><div class="stat-value">'+netStatus+'</div></div>';
        sh+='<div class="stat-card sc3"><div class="stat-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg></div><div class="stat-label">信号等级</div><div class="stat-value" style="color:'+gc+'">'+q+'</div><div class="stat-sub">'+dbm+'</div></div>';
        sh+='<div class="stat-card sc4"><div class="stat-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm4.2 14.2L11 13V7h2v5.2l3.8 2.8-1.6 1.4z"/></svg></div><div class="stat-label">刷新时间</div><div class="stat-value" style="font-size:14px">'+(d.STAMP||'--')+'</div></div>';
        sh+='</div>';
        REAL.imei=d.IMEI||'';REAL.iccid=d.ICCID||'';
        var ih='<div class="id-card"><div class="id-row"><span class="id-label">IMEI</span><span class="id-val" id="imeiVal"></span><span class="id-eye" id="eye_imei" onclick="tog(\'imei\')" title="显示/隐藏"></span></div><div class="id-row"><span class="id-label">ICCID</span><span class="id-val" id="iccidVal"></span><span class="id-eye" id="eye_iccid" onclick="tog(\'iccid\')" title="显示/隐藏"></span></div></div>';
        e.style.opacity='0';e.style.transition='opacity .35s ease';e.innerHTML=gh+sh+ih;fitMask();paint('imei');paint('iccid');void e.offsetHeight;e.style.opacity='1';
        try{
          if(d.BANDVAL!='READFAIL'){
            var b=d.BANDVAL.split(',');var low=parseInt(b[4])||0,high=parseInt(b[3])||0;var f=document.getElementById('bandform');
            if(f&&!DIRTY){f.b1.checked=!!(low&1);f.b3.checked=!!(low&4);f.b5.checked=!!(low&16);f.b8.checked=!!(low&128);f.b34.checked=!!(high&2);f.b38.checked=!!(high&32);f.b39.checked=!!(high&64);f.b40.checked=!!(high&128);f.b41.checked=!!(high&256);f.low_base.value=low;f.high_base.value=high;f.low.value=low;f.high.value=high;}
            var c=document.getElementById('cur');if(c){var bands=[{n:'B1',f:1,t:'fdd'},{n:'B3',f:4,t:'fdd'},{n:'B5',f:16,t:'fdd'},{n:'B8',f:128,t:'fdd'},{n:'B34',f:2,t:'tdd'},{n:'B38',f:32,t:'tdd'},{n:'B39',f:64,t:'tdd'},{n:'B40',f:128,t:'tdd'},{n:'B41',f:256,t:'tdd'}];var fddB=[],tddB=[];bands.forEach(function(b){var on=b.t==='fdd'?(low&b.f):(high&b.f);if(on){if(b.t==='fdd')fddB.push(b.n);else tddB.push(b.n);}});var total=fddB.length+tddB.length;var badges='';if(total===0){badges='<span class="band-badge empty">未启用任何频段</span>';}else{fddB.forEach(function(b){badges+='<span class="band-badge fdd">'+b+'</span>';});tddB.forEach(function(b){badges+='<span class="band-badge tdd">'+b+'</span>';});}c.innerHTML='<div class="band-status-header"><div class="band-status-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z"/></svg></div><div><div class="band-status-title">当前频段</div><div class="band-status-count">'+total+' 个频段已启用'+(fddB.length?' · FDD '+fddB.length:'')+(tddB.length?' · TDD '+tddB.length:'')+'</div></div></div><div class="band-badges">'+badges+'</div>'+(DIRTY?'<div class="band-status-dirty">⚠ 已修改勾选，点下方"应用勾选"生效</div>':'');}
            var fo=document.getElementById('followstat');
            if(fo){var fv=(d.FOLLOW||'');if(fv==''){fo.style.display='none';fo.innerHTML='';}else{fo.style.display='';fo.innerHTML=fv=='RUN'?'\u23f3 正在重新驻网并恢复拨号（严格锁定 TDD=0 时设备可能挣扎数分钟，会自动重试，请耐心等待）…':(fv=='1'?'\u2713 频段已应用，网络已恢复上网':'\u2717 暂未自动恢复拨号：设备可能仍在挣扎驻网（稍后可能自行恢复）；或再点一次"应用勾选"、点"恢复出厂频段"、重启设备');}}
          }else{var c2=document.getElementById('cur');if(c2)c2.innerHTML='<div class="band-status-header"><div class="band-status-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z"/></svg></div><div><div class="band-status-title">当前频段</div><div class="band-status-count" style="color:var(--warn)">读取失败（设备忙/重启中）— 不影响下方操作</div></div></div>';}
          var cc=document.getElementById('cellcur'),ccs=document.getElementById('cellcur-sub'),cci=document.getElementById('cellcur-icon');
          if(cc){if(d.BAND&&d.BAND!='?'){
            var dup=d.DUPLEX||'LTE';
            if(ccs)ccs.textContent='LTE '+dup;
            if(cci)cci.className='cell-info-icon live';
            cc.innerHTML='<div class="cell-metric band"><div class="cell-metric-label">频段</div><div class="cell-metric-value">B'+d.BAND+'</div></div><div class="cell-metric earfcn"><div class="cell-metric-label">EARFCN</div><div class="cell-metric-value">'+(d.CELLEARFCN||'?')+'</div></div><div class="cell-metric pci"><div class="cell-metric-label">PCI</div><div class="cell-metric-value">'+(d.CELLPCI||'?')+'</div></div>';
          }else{
            if(ccs)ccs.textContent='设备搜网中…';
            if(cci)cci.className='cell-info-icon offline';
            cc.innerHTML='<div class="cell-info-empty">⏳ 未驻网（设备正在搜索网络）</div>';
          }}
          var ine=document.getElementById('cearfcn'),inp=document.getElementById('cpci');
          if(ine&&!ine.value&&d.CELLEARFCN)ine.value=d.CELLEARFCN;
          if(inp&&!inp.value&&d.CELLPCI)inp.value=d.CELLPCI;
          var cl=document.getElementById('celllock'),clc=document.getElementById('celllock-card'),cli=document.getElementById('celllock-icon');
          if(cl&&clc&&cli){var lt=cl.textContent||'';if(lt.indexOf('未锁定')>=0){clc.classList.remove('locked');cli.className='cell-info-icon offline';cli.innerHTML='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6h1.9c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg>';}else{clc.classList.add('locked');cli.className='cell-info-icon lock';cli.innerHTML='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3-9H8V6c0-1.66 1.34-3 3-3s3 1.34 3 3v2z"/></svg>';cl.innerHTML='<span class="lock-detail">'+lt+'</span>';}}
        }catch(err){}
      }else if(!silent){e.style.opacity='0';e.style.transition='opacity .35s ease';e.innerHTML='<div class="gauge-card" style="text-align:center;padding:40px"><div style="font-size:48px;margin-bottom:12px">⚠</div><div style="font-size:16px;color:var(--text2)">读取失败（设备忙/重启中）</div><div style="font-size:13px;color:var(--text3);margin-top:8px">可点刷新重试</div></div>';void e.offsetHeight;e.style.opacity='1';}
      finish();
    },hold);}
  };
  x.open('GET','?a=data'+(force?'&force=1':''),true);x.send();
}
function luhnCheck(s){var sum=0,dbl=false;for(var i=s.length-1;i>=0;i--){var d=parseInt(s.charAt(i),10);if(isNaN(d))return false;if(dbl){d*=2;if(d>9)d-=9;}sum+=d;dbl=!dbl;}return sum%10===0;}
function luhnFix(s14){var sum=0,dbl=true;for(var i=s14.length-1;i>=0;i--){var d=parseInt(s14.charAt(i),10);if(dbl){d*=2;if(d>9)d-=9;}sum+=d;dbl=!dbl;}var c=(10-(sum%10))%10;return s14+''+c;}
function buildImei(f){
  var raw=f.imei.value.replace(/[^0-9]/g,'');var v=raw;
  if(v.length==14){var fixed=luhnFix(v);if(!confirm('你输入了 14 位数字，已自动补全校验位：\n\n  '+v+'  \u2192  '+fixed+'\n\n使用这个 IMEI 吗？')){return false;}v=fixed;}
  else if(!/^[0-9]{15}$/.test(v)){alert('IMEI 格式不对：需要 15 位数字（当前 '+v.length+' 位）');return false;}
  else if(!luhnCheck(v)){var fixed15=luhnFix(v.substring(0,14));if(confirm('这个 IMEI 的校验位不合法，设备会拒绝写入！\n\n  你的输入：'+v+'\n  建议修正：'+fixed15+'\n\n使用修正后的值吗？\n（如果确定原始值没错，请点"取消"并重新核对）')){v=fixed15;}else{return false;}}
  f.imei.value=v;
  if(confirm('将 IMEI 改为：'+v+'\n\n是否立即重启设备生效？\n（注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待）')){f.reboot.value='1';var d=document.createElement('div');d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:var(--overlay);display:flex;align-items:center;justify-content:center;z-index:9999;backdrop-filter:blur(4px)';d.innerHTML='<div style="background:var(--card);padding:28px 40px;border-radius:12px;box-shadow:var(--shadow);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0;color:var(--text)">正在保存并重启设备…</p></div>';document.body.appendChild(d);}
  else{f.reboot.value='';}
  return true;
}
function rebootOnly(){if(!confirm('设备将立即重启，重启时自动把新 IMEI 写入。\n\n注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待。\n\n确认重启？'))return false;var d=document.createElement('div');d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:var(--overlay);display:flex;align-items:center;justify-content:center;z-index:9999;backdrop-filter:blur(4px)';d.innerHTML='<div style="background:var(--card);padding:28px 40px;border-radius:12px;box-shadow:var(--shadow);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0;color:var(--text)">正在重启设备…</p></div>';document.body.appendChild(d);return true;}
</script>
JSEOF

echo "<!-- 数据面板 Tab -->"
echo "<div class='page active' id='page-dashboard'>"
echo "<div id='info'><div class='gauge-card'><div class='gauge-wrap'><div class='skeleton skeleton-gauge'></div><div class='gauge-side'><div class='skeleton skeleton-text' style='width:100px'></div><div class='skeleton skeleton-text' style='width:80px'></div><div class='skeleton skeleton-text' style='width:90px'></div></div></div></div><div class='stat-grid'><div class='skeleton skeleton-stat'></div><div class='skeleton skeleton-stat'></div><div class='skeleton skeleton-stat'></div><div class='skeleton skeleton-stat'></div></div><div class='id-card'><div class='skeleton skeleton-text' style='width:60%'></div><div class='skeleton skeleton-text' style='width:70%'></div></div></div>"
echo "<div class='rf-corner'>"
echo "<div class='rf-line'><button class='refresh' id='rfbtn' type='button' onclick='manualRefresh()' title='立即刷新'>"
echo "<svg width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\"><path d=\"M21 12a9 9 0 1 1-2.64-6.36\"/><path d=\"M21 3v6h-6\"/></svg>"
echo " 刷新</button><span class='auto'>每 $((AUTO_SEC)) 秒自动刷新</span></div>"
echo "<span class='auto' id='rfnote'></span>"
echo "</div>"
echo "</div>"

echo "<!-- IMEI Tab -->"
echo "<div class='page' id='page-imei'>"
echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g2'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M7 1h10a2 2 0 0 1 2 2v18a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm5 19a1 1 0 1 0 0-2 1 1 0 0 0 0 2z\"/></svg></div>"
echo "IMEI 改串</div>"
if [ -n "$IMEI_RESULT" ]; then
  if [ -n "$IMEI_RESULT_OK" ]; then
    echo "<div class='msg ok'>$IMEI_RESULT</div>"
  else
    echo "<div class='msg err'>$IMEI_RESULT</div>"
  fi
fi
if [ -n "$PENDING_IMEI" ]; then
  echo "<div class='msg ok'>待应用的新 IMEI：<b>$PENDING_IMEI</b><br>点下方按钮重启设备，重启后自动写入生效。<br><span style='color:var(--danger)'>改串重启比平常久，约需 2-3 分钟，请耐心等待。</span></div>"
  echo "<form method=POST action='?a=band' onsubmit=\"return rebootOnly()\">"
  echo "<button class='btn' type=submit name=reboot value='1'>立即重启设备生效</button>"
  echo "</form>"
fi
echo "<form method=POST action=\"?a=band\" onsubmit=\"return buildImei(this)\">"
echo "<input type=hidden name=reboot value=''>"
echo "<div class='row'>新 IMEI：<input class=imeiin type=text name=imei maxlength=20 size=20 placeholder=\"15位数字\" autocomplete=on></div>"
echo "<button class='btn' type=submit>保存</button>"
echo "</form>"
echo "<p class='note'>点保存后会校验 IMEI 合法性（含校验位），可自动修正；确认后询问是否立即重启生效。</p>"
echo "<p class='note' style='color:var(--danger)'>改串后的重启比平常久（约 2-3 分钟），请耐心等待。</p>"
echo "</div></div>"

echo "<!-- 锁频段 Tab -->"
echo "<div class='page' id='page-band'>"
echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g3'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M2 20h3v-4H2v4zm5 0h3v-8H7v8zm5 0h3V8h-3v12zm5 0h3V4h-3v16z\"/></svg></div>"
echo "锁频段</div>"
if [ -n "$RESULT" ]; then
  if [ -n "$RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $RESULT</div>"
  else
    echo "<div class='msg err'>✗ $RESULT</div>"
  fi
fi
echo "<div class='band-status-card' id='cur'>$CURTEXT</div>"
echo "<form id='bandform' method=POST action='?a=band' onsubmit='return build(this)'>"
echo "<input type=hidden name=low_base value='$RLOW'>"
echo "<input type=hidden name=high_base value='$RHIGH'>"
echo "<input type=hidden name=low value='$RLOW'>"
echo "<input type=hidden name=high value='$RHIGH'>"
echo "<div class='band-section-title'><span class='dot fdd'></span> FDD 频段（联通/电信主流）</div>"
echo "<div class='toggle-grid'>"
echo "<div class='toggle-row'><span class='tg-label'>B1 <span class='tg-tag fdd'>2100M</span></span><label class='toggle-switch'><input type=checkbox name=b1 $B1><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B3 <span class='tg-tag fdd'>1800M</span></span><label class='toggle-switch'><input type=checkbox name=b3 $B3><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B5 <span class='tg-tag fdd'>850M</span></span><label class='toggle-switch'><input type=checkbox name=b5 $B5><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B8 <span class='tg-tag fdd'>900M</span></span><label class='toggle-switch'><input type=checkbox name=b8 $B8><span class='toggle-slider'></span></label></div>"
echo "</div>"
echo "<div class='band-section-title'><span class='dot tdd'></span> TDD 频段（移动主流）</div>"
echo "<div class='toggle-grid'>"
echo "<div class='toggle-row'><span class='tg-label'>B34 <span class='tg-tag tdd'>2000M</span></span><label class='toggle-switch'><input type=checkbox name=b34 $B34><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B38 <span class='tg-tag tdd'>1900M</span></span><label class='toggle-switch'><input type=checkbox name=b38 $B38><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B39 <span class='tg-tag tdd'>1900M</span></span><label class='toggle-switch'><input type=checkbox name=b39 $B39><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B40 <span class='tg-tag tdd'>2300M</span></span><label class='toggle-switch'><input type=checkbox name=b40 $B40><span class='toggle-slider'></span></label></div>"
echo "<div class='toggle-row'><span class='tg-label'>B41 <span class='tg-tag tdd'>2500M</span></span><label class='toggle-switch'><input type=checkbox name=b41 $B41><span class='toggle-slider'></span></label></div>"
echo "</div>"
cat << CEOF
<p style="margin:10px 0 0"><input class="btn" type=submit value="应用勾选"></p>
</form>
<div id="followstat" class="note" style="display:none;margin:10px 0 0"></div>
<p class="note">点"应用勾选"后设备会重新驻网并自动恢复拨号（约1分钟，无需重启）；想立即看结果可点"数据面板"刷新。</p>
<p class="note">锁频段只限定"允许使用哪些频段"，实际优先驻留哪个频段由运营商网络策略决定。
移动卡会优先使用 TDD 频段，如果只保留 FDD 频段，设备重启后可能反复重启数分钟才能重新驻网。
想让设备固定在某个<b>频点或小区</b>上（例如锁定 FDD），请用"锁频点 / 小区"页。</p>
<p style="color:var(--text2);margin:14px 0 6px;font-size:14px">锁频段后一直无网？可以恢复到已知可用的频段（任何时候都能点）：</p>
<form method=POST action="?a=band" style="display:inline" onsubmit="return waitRestore('正在恢复出厂频段…')">
<input class="btn" type=submit name=restore value="恢复出厂频段">
</form>
CEOF
if [ -n "$HASBAK" ]; then
  echo "<form method=POST action='?a=band' style='display:inline' onsubmit=\"return waitRestore('正在恢复上次频段…')\">"
  echo "<input class='btn' type=submit name=restore_bak value='恢复上次频段'>"
  echo "</form>"
fi
echo "</div></div>"

echo "<!-- 锁频点/小区 Tab -->"
echo "<div class='page' id='page-cell'>"
echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g4'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4z\"/></svg></div>"
echo "锁定频点 / 小区</div>"
echo "<p class='card-desc'>将设备锁定在指定的<b>频点或小区</b>上，保持固定使用。</p>"
if [ -n "$CELL_RESULT" ]; then
  if [ -n "$CELL_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $CELL_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $CELL_RESULT</div>"
  fi
fi
echo "<div class='cell-info-card' id='cellcur-card'>"
echo "<div class='cell-info-header'><div class='cell-info-icon live' id='cellcur-icon'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4z\"/></svg></div><div><div class='cell-info-title'>当前驻留小区</div><div class='cell-info-sub' id='cellcur-sub'>$CELL_CUR</div></div></div>"
echo "<div class='cell-info-metrics' id='cellcur'><div class='cell-metric band'><div class='cell-metric-label'>频段</div><div class='cell-metric-value'>--</div></div><div class='cell-metric earfcn'><div class='cell-metric-label'>EARFCN</div><div class='cell-metric-value'>--</div></div><div class='cell-metric pci'><div class='cell-metric-label'>PCI</div><div class='cell-metric-value'>--</div></div></div>"
echo "</div>"
echo "<div class='cell-lock-card' id='celllock-card'><div class='cell-info-icon lock' id='celllock-icon'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3-9H8V6c0-1.66 1.34-3 3-3s3 1.34 3 3v2z\"/></svg></div><div class='cell-lock-text' id='celllock'>$CELL_LOCK</div></div>"
echo "<form method=POST action='?a=cell' onsubmit=\"return buildCell(this)\">"
echo "<div class='row'><input class='btn' type=submit name=cell_lock value='一键锁定当前' onclick=\"CELLBTN='lock'\"></div>"
echo "<p class='sub' style='margin:4px 0 0'>自动识别并锁定当前驻留的频点与小区（推荐）</p>"
echo "<div class='sep'></div>"
echo "<p class='sub' style='margin:0 0 6px'>或手动指定：</p>"
echo "<div class='row'>频点(EARFCN) <input type=text name=cearfcn id=cearfcn value='$CELL_EARFCN' maxlength=7 autocomplete=on placeholder='如 1300'>"
echo " <span class='note' id=cearfcn_hint></span></div>"
echo "<div class='row'>PCI <input type=text name=cpci id=cpci value='$CELL_PCI' maxlength=3 placeholder='选填' autocomplete=on>"
echo " <span class='note'>（留空 = 锁频点；填写 = 锁小区）</span></div>"
echo "<div class='row'><input class='btn' type=submit name=cell_apply value='应用以上参数' onclick=\"CELLBTN='apply'\"> <input class='btn btn-danger' type=submit name=cell_clear value='解除锁定' onclick=\"CELLBTN='clear'\"></div>"
echo "</form>"
echo "<p class='note'>· <b>只填频点</b>：锁定该频点，同频点其他小区可接替，较稳定<br>"
echo "· <b>频点 + PCI</b>：精确锁定某个小区，该小区不可用时设备将无网<br>"
echo "· 应用后设备会重新搜网（约 10-60 秒），期间短暂无网属正常；若 75 秒后仍无网会自动解除</p>"
echo "<p class='note' style='color:var(--text3)'>与锁频段相互独立，可同时使用。</p>"
echo "</div></div>"

echo "<!-- 网口优先级 Tab -->"
echo "<div class='page' id='page-network'>"
echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g5'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-8 10c0-.7.09-1.36.26-2h15.48c.17.64.26 1.3.26 2s-.09 1.36-.26 2H4.26A8.04 8.04 0 0 1 4 12zm1.07-4h13.86A8 8 0 0 1 12 4a8 8 0 0 1-6.93 4zm0 8h13.86A8 8 0 0 1 12 20a8 8 0 0 1-6.93-4z\"/></svg></div>"
echo "网口与上网优先级</div>"
echo "<p class='card-desc'>把三个网口之一设为有线 WAN（也可以全部保持 LAN，仅用 4G 上网），并选择 4G 与有线之间的上网优先级。</p>"
if [ -n "$NET_RESULT" ]; then
  if [ -n "$NET_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $NET_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $NET_RESULT</div>"
  fi
fi
echo "<form method=POST action='?a=net' onsubmit=\"return buildNet(this)\">"
echo "<p class='sub' style='margin:0 0 8px'><b>有线 WAN 口</b>：点选要插网线的口（点谁谁亮，与设备背面丝印一致）：</p>"
echo "<div class='portstrip'>"
echo "<label class=port><input type=radio name=net_port value=p2 $NP2><span class=jack><i></i></span><span class=plabel>LAN2</span><span class=rlan>LAN</span><span class=rwan>WAN</span></label>"
echo "<label class=port><input type=radio name=net_port value=p1 $NP1><span class=jack><i></i></span><span class=plabel>LAN1</span><span class=rlan>LAN</span><span class=rwan>WAN</span></label>"
echo "<label class=port><input type=radio name=net_port value=p0 $NP0><span class=jack><i></i></span><span class=plabel>LAN0</span><span class=rlan>LAN</span><span class=rwan>WAN</span></label>"
echo "<label style=display:none><input type=radio name=net_port value=all $NALL></label>"
echo "</div>"
echo "<p class='note' style='margin:4px 0 0'>· 点亮的口再点一次可熄灭：全部熄灭 = 三个口都是 LAN（仅 4G 上网，无法插网线）</p>"
echo "<div class='sep'></div>"
echo "<p class='sub' style='margin:0 0 6px'><b>上网优先级</b>：</p>"
echo "<div class='row'><label><input type=radio name=net_mode value=4g $NM4> 4G 优先（出厂默认，插网线仅作备用）</label></div>"
echo "<div class='row'><label><input type=radio name=net_mode value=wan $NMW> 有线优先（插网线走网线，拔线自动回 4G）</label></div>"
echo "<div class='row'><label><input type=radio name=net_mode value=only4g $NM4G> 仅 4G（有线口停用）</label></div>"
echo "<div class='row'><label><input type=radio name=net_mode value=onlywan $NMWG> 仅 有线（4G 停止上网；请先确认网线已插好且能上网）</label></div>"
echo "<p style='margin:10px 0 0'><input class='btn' type=submit value='应用网络设置'></p>"
echo "</form>"
echo "<p class='note'>· 上图的排列方向与设备背面一致：面对背面时，LAN0 在最右边<br>"
echo "· 应用时网络会中断数秒，页面恢复后即可继续操作<br>"
echo "· 选"仅 有线"前请确认网线已插好且能上网，否则设备将无法上网（可随时改回）<br>"
echo "· 4G 拨号始终保持在线，切换优先级不影响锁频段、锁频点等功能</p>"
echo "</div></div>"

echo "<!-- 管理密码 Tab -->"
echo "<div class='page' id='page-password'>"
echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g6'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M6 10V8a6 6 0 0 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h1zm2 0h8V8a4 4 0 0 0-8 0v2z\"/></svg></div>"
echo "管理后台密码</div>"
echo "<p class='card-desc'>本设备内置 <b>OpenWrt 管理后台</b>（端口 8888），可配置网口、无线、防火墙等更多功能。"
echo "设置一个密码后，即可用 <b>root</b> + 该密码登录："
echo "<br><a href=\"http://192.168.1.1:8888\" target=\"_blank\" style=\"color:var(--accent)\">http://192.168.1.1:8888</a></p>"
if [ -n "$PW_RESULT" ]; then
  if [ -n "$PW_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $PW_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $PW_RESULT</div>"
  fi
fi
echo "<form method=POST action='?a=pw' onsubmit=\"return checkPw(this)\">"
echo "<table>"
if [ -n "$PW_USER_SET" ]; then
  echo "<tr><td>当前密码</td><td><input type=password name=pw0 id=pw0 maxlength=64 autocomplete=current-password></td></tr>"
fi
echo "<tr><td>新密码</td><td><input type=password name=pw1 id=pw1 maxlength=64 autocomplete=new-password></td></tr>"
echo "<tr><td>确认密码</td><td><input type=password name=pw2 id=pw2 maxlength=64 autocomplete=new-password></td></tr>"
echo "<tr><td></td><td><button class='btn' type=submit>设置密码</button>"
echo "<span class='pwmsg' id=pwtip></span></td></tr>"
echo "</table>"
echo "</form>"
if [ -n "$PW_USER_SET" ]; then
  echo "<p class='note'>修改密码需要先输入当前密码。"
  echo "<br>忘记当前密码时，可通过「系统命令行」执行 <code>passwd -d root</code> 清除后回到本页重设。</p>"
else
  echo "<p class='note'>要求：至少 8 位。设置后修改需要先输入当前密码。</p>"
fi
echo "</div></div>"

echo "<!-- 设置 Tab -->"
echo "<div class='page' id='page-settings'>"

echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g7'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM12 1a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0V2a1 1 0 0 1 1-1zm0 18a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1zM4.2 4.2a1 1 0 0 1 1.42 0l1.4 1.4a1 1 0 1 1-1.4 1.4L4.2 5.6a1 1 0 0 1 0-1.4zm12.7 12.7a1 1 0 0 1 1.42 0l1.4 1.4a1 1 0 0 1-1.4 1.4l-1.4-1.4a1 1 0 0 1 0-1.4zM1 12a1 1 0 0 1 1-1h2a1 1 0 0 1 0 2H2a1 1 0 0 1-1-1zm18 0a1 1 0 0 1 1-1h2a1 1 0 0 1 0 2h-2a1 1 0 0 1-1-1zM4.2 19.8a1 1 0 0 1 0-1.42l1.4-1.4a1 1 0 1 1 1.4 1.4l-1.4 1.4a1 1 0 0 1-1.4 0zm12.7-12.7a1 1 0 0 1 0-1.42l1.4-1.4a1 1 0 0 1 1.4 1.4l-1.4 1.4a1 1 0 0 1-1.4 0z\"/></svg></div>"
echo "主题模式</div>"
echo "<div class='setting-row'>"
echo "<div><div class='setting-label'>深色 / 浅色模式</div><div class='setting-desc'>选择界面的配色方案</div></div>"
echo "<div class='theme-switch'>"
echo "<button class='theme-opt' data-theme='dark' onclick=\"setTheme('dark')\">深色</button>"
echo "<button class='theme-opt' data-theme='light' onclick=\"setTheme('light')\">浅色</button>"
echo "</div></div>"
echo "</div>"

echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g1'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M3 3h18a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm3 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm4 3l-3 3-2-2-3 4h16l-5-7-3 2z\"/></svg></div>"
echo "背景壁纸</div>"
echo "<p class='card-desc'>填一个图片链接（http/https），保存在<b>设备</b>上——换浏览器、换手机、换电脑打开都是同一张，图片本身不占设备空间。留空点保存即清除。</p>"
if [ -n "$WP_RESULT" ]; then
  if [ -n "$WP_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $WP_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $WP_RESULT</div>"
  fi
fi
echo "<form method=POST action='?a=wp' onsubmit=\"return wpSubmit(this)\">"
echo "<div class='row'><input type='text' id='wp-url' name='wp_url' placeholder='http(s)://…图片链接' autocomplete=on style='width:100%;max-width:520px'></div>"
echo "<div class='row'><button class='btn btn-sm' type='submit'>保存</button> <button class='btn btn-sm btn-danger' type='submit' onclick='wpClearField()'>清除</button></div>"
echo "</form>"
echo "<p class='note' id='wp-status'>当前：纯色背景</p>"
echo "</div>"

echo "<div class='card'><div class='card-title'>"
echo "<div class='card-icon g2'><svg viewBox=\"0 0 24 24\" fill=\"currentColor\"><path d=\"M12 2L2 7l10 5 10-5-10-5zM2 12l10 5 10-5-10-5-10 5zM2 17l10 5 10-5-10-5-10 5z\"/></svg></div>"
echo "关于</div>"
echo "<p class='note'>蜂助手 S1 工具箱<br>"
echo "设备：MIBOX-668M2 / MT7628DAN / OpenWrt 14.07</p>"
echo "</div>"

echo "</div>"

echo "</div><!-- /container -->"

echo "<script>"
echo "(function(){"
echo "  var pr=document.getElementsByName('net_port');"
echo "  var pm=document.getElementsByName('net_mode');"
echo "  var last=null;"
echo "  for(var i=0;i<pr.length;i++){if(pr[i].checked)last=pr[i];}"
echo "  function setPort(v){for(var j=0;j<pr.length;j++){if(pr[j].value===v)pr[j].checked=true;}}"
echo "  function curPort(){for(var j=0;j<pr.length;j++){if(pr[j].checked)return pr[j].value;}return 'p0';}"
echo "  function syncPrio(){var allOn=(curPort()==='all');for(var j=0;j<pm.length;j++){if(pm[j].value==='wan'||pm[j].value==='onlywan'){pm[j].disabled=allOn;if(allOn&&pm[j].checked){for(var k=0;k<pm.length;k++){if(pm[k].value==='4g')pm[k].checked=true;}}}}}"
echo "  for(var i=0;i<pr.length;i++){pr[i].onclick=function(){if(this===last){this.checked=false;setPort('all');last=null;}else{last=this;}syncPrio();};}"
echo "  for(var i=0;i<pm.length;i++){pm[i].onclick=syncPrio;}"
echo "  syncPrio();"
echo "})();"
echo "</script>"

echo "<script>(function(){var f=document.getElementById('bandform');if(!f)return;"
echo "function mark(){DIRTY=1;var c=document.getElementById('cur');"
echo "if(c&&c.innerHTML.indexOf('已修改勾选')<0)c.innerHTML+='<br><span style=\"color:var(--warn)\">已修改勾选，点下方\"应用勾选\"生效（自动刷新不会覆盖你的选择）</span>';}"
echo "var ns=['b1','b3','b5','b8','b34','b38','b39','b40','b41'];"
echo "for(var i=0;i<ns.length;i++){if(f[ns[i]])f[ns[i]].onchange=mark;}})();</script>"

echo "<script>(function(){"
echo "  var st=LS.get('ui-tab')||'dashboard';"
echo "  if(st!=='dashboard')switchTab(st);"
echo "  setTheme(getTheme());applyWallpaper();"
echo "  var wu=document.getElementById('wp-url');if(wu&&typeof WP_SERVER==='string'&&WP_SERVER)wu.value=WP_SERVER;"
echo "  var at=document.querySelector('.tab.active'),ind=document.querySelector('.tab-indicator');"
echo "  if(at&&ind){ind.style.left=at.offsetLeft+'px';ind.style.width=at.offsetWidth+'px';}"
echo "  var msgs=document.querySelectorAll('.msg.ok,.msg.err');"
echo "  msgs.forEach(function(m){var t=m.textContent.replace(/^[\u2713\u2717]\s*/,'');showToast(t,m.classList.contains('ok')?'ok':'err');});"
echo "})();bindEarfcnHint();setTimeout(function(){loadAll(0);},300);</script>"
echo "</body></html>"
