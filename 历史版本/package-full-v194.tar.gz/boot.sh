#!/bin/sh
SYS_RUN_DIR="/tmp/aos_tmp"

echo "start boot.sh..." > /dev/kmsg

#modem power on
chmod 777 $SYS_RUN_DIR/sim_start.sh
$SYS_RUN_DIR/sim_start.sh&