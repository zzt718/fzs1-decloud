#!/bin/sh
count=0
not_count=0
echo "dhcp_check..." 
while [ 1 ]
do
ret=`netstat -apn |grep :67`

if [ "$ret"x == x ]
then
	echo "don not find dhcp. $not_count" > /dev/kmsg
	count=0
	if [ $not_count -gt 5 ]
	then
		/etc/init.d/dnsmasq restart
		echo "restart dnsmasq." > /dev/kmsg
		not_count=0
	fi	
	not_count=$((not_count+1))
else
	not_count=0
fi

sleep 5

done


