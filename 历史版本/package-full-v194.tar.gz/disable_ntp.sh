#!/bin/sh
		
local ntp_enable="$(uci show system.ntp.enabled | tr -cd "[0-9]")"

echo "ntp_enable : $ntp_enable"

if [ $ntp_enable == "1" ]; then
	uci set system.ntp.enabled=0
	uci commit
	/etc/init.d/sysntpd stop
	echo "stop ntp services." 
fi



