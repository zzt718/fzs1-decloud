#!/bin/sh


usage()
{
	echo "usage: dnsmasq.sh [option]..."
	echo "options:"
	echo "-h: print this help"
	echo "stop : kill dnsmasq"
	echo "start : start dnsmasq"
	echo "restart : restart dnsmasq"
	exit
}

dnsmasq_start()
{
	echo "[dnsmasq.sh]dnsmasq_start..."
	dnsmasq -C /var/etc/dnsmasq.conf -k &

}

dnsmasq_stop()
{	
	PID=`cat /var/run/dnsmasq.pid`
	kill -9 $PID
	echo "[dnsmasq.sh]dnsmasq_stop,pid=$PID..."
}

case "$1" in
	"start")
		dnsmasq_start ;;
	"stop")
		dnsmasq_stop ;;
	"restart")
		dnsmasq_stop
		dnsmasq_start		
		;;
	"-h")
		usage ;;
	*)
		echo "illegal option -- $1"
		usage ;;
esac


