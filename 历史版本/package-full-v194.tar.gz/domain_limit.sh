#!/bin/sh
# domain_limit.sh - decloud edition: cloud blacklist enforcement disabled
echo "decloud: domain_limit disabled"
exit 0
