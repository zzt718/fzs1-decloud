#!/bin/sh
# firewall.sh - decloud edition
# community mod: route murder removed, blacklist chains removed, INPUT/OUTPUT preserved
# + directional no-flush firewall (fw3 rules survive) + multi-uplink metric

usage()
{
        echo "usage: firewall.sh [option]..."
        echo "-h                : print this help"
        echo "clear : clear firewall"
        exit
}

firewall_clear()
{
        echo "decloud: clear is no-op (enable rebuilds what it needs)"
        exit
}

firewall_enable()
{
        echo "firewall enable $1 $2 $3 $4"
        if ! iptables -t nat -C POSTROUTING -o br-lan -j ACCEPT 2>/dev/null; then
                iptables -t nat -I POSTROUTING 1 -o br-lan -j ACCEPT
                iptables -t nat -A POSTROUTING -j MASQUERADE
        fi
        iptables -N MIBOX_FW 2>/dev/null
        iptables -F MIBOX_FW
        iptables -C FORWARD -j MIBOX_FW 2>/dev/null || iptables -I FORWARD 1 -j MIBOX_FW
        iptables -A MIBOX_FW -i br-lan -j ACCEPT
        # return traffic must pass even if fw3 failed to start (factory-equivalent robustness)
        iptables -A MIBOX_FW -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
        # re-attach fw3 hook if the chain exists but is not hooked (guarded, no fw3 dependency)
        if ! iptables -C FORWARD -j delegate_forward 2>/dev/null; then
                iptables -n -L delegate_forward >/dev/null 2>&1 && iptables -A FORWARD -j delegate_forward
        fi
        # MSS clamp: interface-agnostic (covers 4G / dongle / WAN regardless of device name)
        if ! iptables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null; then
                iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
        fi
        if route -n | grep '^0.0.0.0' | grep -q " $1 *$"; then
                route del default dev $1
        fi
        if [ "$4" != "" ]; then
                route add default gw $4 dev $1 metric 10
        else
                route add default dev $1 metric 10
        fi
        echo 1 > /proc/sys/net/ipv4/ip_forward
        cp $3 /tmp/resolv.conf.auto
        if [ "$4" != "" ]; then
                route del -host $4
                route add -host $4 dev $1
        fi
        echo "firewall enable $1 end."
        exit
}

for arg in $*
        do
                if [ "$1" != "" ]; then
                        case "$1" in
                                "clear")
                                        firewall_clear
                                        shift ;;
                                "enable")
                                        firewall_enable $2 $3 $4 $5
                                        shift ;;
                                "-h")
                                        usage ;;
                                *)
                                        echo "illegal option -- $2"
                                        usage ;;
                        esac
                        shift
                fi
        done

echo "test end..."
