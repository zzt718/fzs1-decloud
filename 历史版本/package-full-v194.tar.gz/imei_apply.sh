#!/bin/sh
# ============ decloud imei apply (runs BEFORE mibox) ============
# reads /usr/aos/imei_request, applies IMEI via ASR factory commands.
# safe: no request file = no action; any failure keeps request for next boot.
DECLOUD_IMEI_REQ=/usr/aos/imei_request
DECLOUD_IMEI_LOG=/usr/aos/imei_apply.log

dc_log(){ echo "$(date '+%m-%d %H:%M:%S') $1" >> $DECLOUD_IMEI_LOG; }
dc_feed(){ ( echo w > /dev/watchdog ) 2>/dev/null || true; }
DECLOUD_IMEI_TRY=/usr/aos/imei_attempts

dc_at_port(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in *1.1:1.4*) echo "${t##*/}"; return;; esac
  done
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in
      *:1.4*)
        PP=${t##*/}
        R=$( (echo -e 'ATI\r'; sleep 1) | microcom -t 1500 -s 115200 /dev/$PP 2>/dev/null )
        case "$R" in *EC200T*) echo "$PP"; return;; esac;;
    esac
  done
}

dc_atc(){  # $1=port $2=cmd ; prints response one-line
  rm -f /tmp/dc_at_$$
  ( (echo -e "$2\r"; sleep 2) | microcom -t 3000 -s 115200 /dev/$1 > /tmp/dc_at_$$ 2>/dev/null ) & MP=$!
  ( sleep 8; kill $MP 2>/dev/null; killall microcom 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  cat /tmp/dc_at_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' '
  rm -f /tmp/dc_at_$$
}

dc_cgsn(){
  dc_atc "$1" 'AT+CGSN' | grep -oE '[0-9]{15}' | head -1
}

dc_wait_port(){
  # wait up to $1 seconds for a port that answers ATI
  i=0
  while [ $i -lt $1 ]; do
    P=$(dc_at_port)
    if [ -n "$P" ]; then
      R=$(dc_atc "$P" 'ATI')
      case "$R" in *EC200T*|*Quectel*) echo "$P"; return 0;; esac
    fi
    dc_feed
    sleep 5
    i=$((i+5))
  done
  return 1
}

dc_apply_imei(){
  REQ=$(cat $DECLOUD_IMEI_REQ 2>/dev/null | tr -d ' \r\n')
  FORCE=0
  case "$REQ" in FORCE:*) FORCE=1; REQ=${REQ#FORCE:};; esac
  case "$REQ" in
    [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]) : ;;
    *) dc_log "bad request [$REQ], removing"; rm -f $DECLOUD_IMEI_REQ; return 1;;
  esac
  dc_log "start: target=$REQ force=$FORCE"
  P=$(dc_wait_port 75)
  if [ -z "$P" ]; then dc_log "no AT port (90s), keep request"; return 1; fi
  dc_log "port=$P"

  CUR=""
  i=0
  while [ $i -lt 12 ]; do
    CUR=$(dc_cgsn "$P")
    if [ -n "$CUR" ] && [ "$CUR" != "0" ]; then break; fi
    dc_feed
    sleep 5
    i=$((i+1))
  done
  dc_log "current=$CUR"
  if [ -z "$CUR" ]; then dc_log "cannot read IMEI, keep request"; return 1; fi
  if [ "$CUR" = "$REQ" ] && [ $FORCE -eq 0 ]; then
    dc_log "already equal, done"
    rm -f $DECLOUD_IMEI_REQ
    return 0
  fi

  R=$(dc_atc "$P" 'AT*PROD=1'); dc_log "prod1: $R"
  case "$R" in *OK*) : ;; *) dc_log "PROD=1 failed, keep request"; return 1;; esac
  R=$(dc_atc "$P" 'AT*MRD_IMEI=D'); dc_log "del: $R"
  sleep 3
  R=$(dc_atc "$P" "AT*MRD_IMEI=W,0,01JAN1970,$REQ"); dc_log "write: $R"
  case "$R" in *OK*) : ;; *) dc_log "WRITE failed, keep request + PROD=0"; dc_atc "$P" 'AT*PROD=0'; return 1;; esac
  R=$(dc_atc "$P" 'AT*PROD=0'); dc_log "prod0: $R"

  dc_atc "$P" 'AT+CFUN=1,1' > /dev/null 2>&1
  dc_log "cfun sent, waiting module back"
  P2=$(dc_wait_port 90)
  if [ -z "$P2" ]; then dc_log "module not back after CFUN, keep request"; return 1; fi
  i=0
  FIN=""
  while [ $i -lt 12 ]; do
    FIN=$(dc_cgsn "$P2")
    [ -n "$FIN" ] && [ "$FIN" != "0" ] && break
    dc_feed
    sleep 5
    i=$((i+1))
  done
  dc_log "final=$FIN"
  if [ "$FIN" = "$REQ" ]; then
    dc_log "SUCCESS"
    rm -f $DECLOUD_IMEI_REQ
    return 0
  fi
  dc_log "verify failed (want $REQ), keep request for retry"
  return 1
}

if [ -f $DECLOUD_IMEI_REQ ]; then
  TRY=0
  [ -f $DECLOUD_IMEI_TRY ] && TRY=$(cat $DECLOUD_IMEI_TRY 2>/dev/null | grep -o '[0-9]*' | head -1)
  TRY=$((TRY+1))
  if [ $TRY -gt 5 ]; then
    dc_log "ABORT after $TRY attempts; request kept as .failed for manual review"
    mv $DECLOUD_IMEI_REQ ${DECLOUD_IMEI_REQ}.failed 2>/dev/null
    rm -f $DECLOUD_IMEI_TRY
  else
    echo "$TRY" > $DECLOUD_IMEI_TRY
    dc_apply_imei
    if [ ! -f $DECLOUD_IMEI_REQ ]; then rm -f $DECLOUD_IMEI_TRY; fi
  fi
fi
