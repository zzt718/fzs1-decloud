#!/bin/sh
#

iptables -t mangle -F PREROUTING 
iptables -t nat -F PREROUTING

iptables -t mangle -i bridge0 -A PREROUTING -p udp --dport 67 -j ACCEPT
iptables -t mangle -i bridge0 -A PREROUTING -p udp --dport 68 -j ACCEPT
iptables -t mangle -i bridge0 -A PREROUTING -p udp --dport 53 -j ACCEPT
iptables -t mangle -A PREROUTING -i bridge0 -d 192.168.0.1 -j ACCEPT
iptables -t mangle -A PREROUTING -i bridge0 -p tcp -j ACCEPT

iptables -t mangle -i bridge0 -A PREROUTING -j DROP
iptables -t nat -i bridge0 -A PREROUTING -d $1 -j ACCEPT

iptables -t nat -I PREROUTING -i bridge0 -d 192.168.0.1 -j ACCEPT
iptables -t nat -A PREROUTING -p tcp -i bridge0 --dport 443 -j DNAT --to 192.168.0.1:443
iptables -t nat -A PREROUTING -p tcp -i bridge0 -j DNAT --to 192.168.0.1:8090
