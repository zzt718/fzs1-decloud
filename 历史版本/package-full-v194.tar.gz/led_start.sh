#!/bin/sh

while [ 1 ]
do

	if [ -f "/tmp/aos_ready" ];then
		echo "[led_start.sh]stop." > /dev/kmsg		
		exit
	fi
	gpio w 3 1
	sleep 1
	
	if [ -f "/tmp/aos_ready" ];then
		echo "[led_start.sh]stop." > /dev/kmsg	
		exit         
	fi
	gpio w 3 0
	sleep 1

done


