#!/bin/sh

LOG_FOLDER=/tmp/aos_tmp/log
COMPRESS_LOG=/tmp/aos_tmp/log/log.tar.gz
usage (){
    echo "usage: log_http_upload.sh [option]..."
    echo "options:"
    echo "-h		: print this help"
    echo "-f .,.,.	: set input file list"
    echo "-r remote file name	: set remote file name"
    echo "-s ftp server	: set ftp server name"
    echo "-i interface"
    echo "-d dns server"
    exit
}

for arg in $*
  do
    if [ "$1" != "" ] 
    then
      case "$1" in
    	  "-f")
    	    FILELIST="$2"
    	    shift ;;
    	  "-s")
    	  	SERVERNAME="$2"
    	  	shift ;;
    	  "-r")
    	  	REMOTEFILE="$2"
    	  	shift ;;
    	  "-i")
    	  	INTERFACE="$2"
    	  	shift ;;
	  "-d")
    	  	DNSSERVER="$2"
    	  	shift ;;	
        "-h")
	  usage ;;
        *) 
	  echo "illegal option -- $2" 
	  usage ;;
      esac
      shift
  fi
  done
  
COMPRESS_LOG=$LOG_FOLDER/$REMOTEFILE.tar.gz
LOG_FOLDER=$LOG_FOLDER/$REMOTEFILE
mkdir -p $LOG_FOLDER


arr=$(echo $FILELIST|busybox tr "," "\n")

for s in $arr
do
echo "$s"
if [ -f "$s" ]
then
    cp $s $LOG_FOLDER
fi

done

tar -cvzf $COMPRESS_LOG  -C $LOG_FOLDER .

curl --connect-timeout 10 --interface $INTERFACE -F file=@$COMPRESS_LOG http://server02.dimiccs.com/putFile.action?remotePath=/provision/provision/log/mibox_log --dns-servers $DNSSERVER 

rm -rf $LOG_FOLDER

rm $COMPRESS_LOG


