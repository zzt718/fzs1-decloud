#!/bin/sh

PAP_AUTH_SCRIPT=/etc/ppp/pap-secrets
CHAP_AUTH_SCRIPT=/etc/ppp/chap-secrets
IP_UP_SCRIPT=/etc/ppp/ip-up

usage (){
    echo "usage: mibox_ppp.sh [option]..."
    echo "options:"
    echo "-h		: print this help"
    echo "-p password	: set password"
    echo "-u username	: set username"
    echo "-b baud	: set baudrate"
    echo "-m dev	: set modem device"
    echo "-i interface	: set ppp interface"
    echo "-a apn	: set apn"
    echo "-t auth	: set auth mode"
    echo "-d		: debug mode"
    exit
}

if [ ! -d "/etc/ppp/peers/" ];then
	mkdir /etc/ppp/peers/
fi

for arg in $*
  do
    if [ "$1" != "" ] 
    then
      case "$1" in
        "-p")
          PASSWORD="password $2" 
    	  AUTH_PASS="$2"
	  shift ;;
        "-u")
          USERNAME="user $2"
	  AUTH_USER="$2" 
    	  shift ;;
        "-b")
          BAUD="$2"
	  shift ;;
        "-m")
          MODEM="/dev/$2" 
	  shift ;;
        "-i")
          INF="$2" 
	  shift ;;
        "-a")
          APN="$2"
          shift ;;
	"-t")
	  AUTH="$2"
 	  shift ;;
        "-d")
          DEBUG="1"
          ;;
        "-h")
	  usage ;;
        *) 
	  echo "illegal option -- $2" 
	  usage ;;
      esac
      shift
  fi
  done
  	
if [ "$INF" = "1" ];then
    echo "====ppp1 starting===="
 #   user=`nvram_get 2860 wan_3g_user`
 #   pass=`nvram_get 2860 wan_3g_pass`
 #   if [ "$APN" = "" ];then
 #       APN=`nvram_get 2860 wan_3g_apn`
 #   fi
    if [ "$PASSWORD" = "" ];then
        PASSWORD="password $pass"
    fi
    if [ "$USERNAME" = "" ];then
        USERNAME="user $user"
    fi
    if [ "$MODEM" = "" ];then
        MODEM="/dev/pts/1"
    fi
    PPP_3G_FILE=/etc/ppp/peers/MIBOX-SIM800-UART
    PPP_CALL_SCRI=MIBOX-SIM800-UART
    CON=/etc/ppp/peers/Chat-MIBOX-SIM800-UART-connect
    DISCON=/etc/ppp/peers/Chat-MIBOX-SIM800-UART-disconnect

elif [ "$INF" = "0" ];then
    echo "====ppp0 starting===="
    if [ "$MODEM" = "" ];then
        MODEM="/dev/ttyUSB3"
    fi

    PPP_3G_FILE=/etc/ppp/peers/MIBOX-SIM800-USB
    PPP_CALL_SCRI=MIBOX-SIM800-USB
    CON=/etc/ppp/peers/Chat-MIBOX-SIM800-USB-connect
    DISCON=/etc/ppp/peers/Chat-MIBOX-SIM800-USB-disconnect
fi

if [ -f $PPP_3G_FILE ]
then
    rm -f $PPP_3G_FILE
fi
if [ -f $CON ]
then
    rm -f $CON
fi
if [ -f $DISCON ]
then
    rm -f $DISCON
fi

echo "unit $INF" > $PPP_3G_FILE
if [ "$DEBUG" = "1" ];then
echo "debug" >> $PPP_3G_FILE
fi
#echo "debug" >> $PPP_3G_FILE
echo "nodetach" >> $PPP_3G_FILE
echo $MODEM >> $PPP_3G_FILE
echo $BAUD >> $PPP_3G_FILE
#echo $USERNAME >> $PPP_3G_FILE
#echo $PASSWORD >> $PPP_3G_FILE
echo "nocrtscts" >> $PPP_3G_FILE
echo "usepeerdns" >> $PPP_3G_FILE
if [ "$AUTH" == "" ];then
    echo "noauth" >> $PPP_3G_FILE
 #   echo "user <insert>" >> $PPP_3G_FILE
 #   echo "password <insert>" >> $PPP_3G_FILE
elif [ "$AUTH" == "pap" ];then

#    echo "auth" >> $PPP_3G_FILE
#    echo "+pap" >> $PPP_3G_FILE
    echo $USERNAME >> $PPP_3G_FILE
    echo $PASSWORD >> $PPP_3G_FILE
elif [ "$AUTH" == "chap" ];then
    echo "-pap" >> $PPP_3G_FILE
	echo "refuse-eap" >> $PPP_3G_FILE
    echo $USERNAME >> $PPP_3G_FILE
    echo $PASSWORD >> $PPP_3G_FILE
elif [ "$AUTH" == "auto" ];then
    echo $USERNAME >> $PPP_3G_FILE
    echo $PASSWORD >> $PPP_3G_FILE
fi
echo "noipdefault" >> $PPP_3G_FILE
echo "novj" >> $PPP_3G_FILE
echo "novjccomp" >> $PPP_3G_FILE
echo "noccp" >> $PPP_3G_FILE
#echo "persist" >> $PPP_3G_FILE
#echo "holdoff 10" >> $PPP_3G_FILE
#echo "defaultroute" >> $PPP_3G_FILE
echo "ipcp-accept-local" >> $PPP_3G_FILE
echo "ipcp-accept-remote" >> $PPP_3G_FILE

echo "connect '/usr/sbin/chat -s -v -t 25 -f $CON'" >> $PPP_3G_FILE
echo "disconnect '/usr/sbin/chat -s -v -f $DISCON'" >> $PPP_3G_FILE

if [ "$AUTH" = "pap" ];then
	 echo "$AUTH_USER * $AUTH_PASS *" > $PAP_AUTH_SCRIPT
elif [ "$AUTH" = "chap" ];then
   echo "$AUTH_USER * $AUTH_PASS *" > $CHAP_AUTH_SCRIPT
elif [ "$AUTH" = "auto" ];then
	 echo "$AUTH_USER * $AUTH_PASS *" > $PAP_AUTH_SCRIPT
   echo "$AUTH_USER * $AUTH_PASS *" > $CHAP_AUTH_SCRIPT
fi

echo "ABORT 'NO CARRIER'" > $CON
echo "ABORT 'ERROR'" >> $CON
echo "ABORT 'NO DIALTONE'" >> $CON
echo "ABORT 'BUSY'" >> $CON
echo "ABORT 'NO ANSWER'" >> $CON 
echo "'' AT" >> $CON
echo "OK ATE0" >> $CON
echo "OK AT+CGDCONT=1,\"IP\",\"$APN\",\"0.0.0.0\",0,0" >> $CON
echo "OK ATD*99#" >> $CON
echo "CONNECT ''" >> $CON

echo "ABORT OK" > $DISCON
echo "ABORT BUSY" >> $DISCON
echo "ABORT DELAYED" >> $DISCON
echo "ABORT \"NO ANSWER\"" >> $DISCON
echo "ABORT \"NO CARRIER\"" >> $DISCON
echo "ABORT \"NO DIALTONE\"" >> $DISCON
echo "ABORT VOICE" >> $DISCON
echo "ABORT ERROR" >> $DISCON
echo "ABORT RINGING" >> $DISCON
echo "TIMEOUT 12" >> $DISCON
echo "\"\" \\K" >> $DISCON
echo "\"\" +++ATH" >> $DISCON
echo "SAY \"\\nGoodbey\\n\"" >> $DISCON

#pppd call $PPP_CALL_SCRI >> /data/aos/run.log 2>&1 &
pppd call $PPP_CALL_SCRI &
