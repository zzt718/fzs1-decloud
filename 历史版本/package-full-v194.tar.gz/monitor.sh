#!/bin/sh
while [ 1 ]
do
        sleep 5
        isRunning=$(ps -ef| grep "/tmp/aos_tmp/firmware"|grep -v grep)
        #echo "$isRunning" 
        if [ "$isRunning" ]
        then
                echo "is running"
        else
		  echo "aos not running" >> /data/aos/monitor.log
                echo "not running"
                reboot
        fi
    
done
