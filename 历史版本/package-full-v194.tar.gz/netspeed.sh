#!/bin/sh

INTERVAL=1

IF=$1
echo "netspeed start ...$1"

while true
do
	R1=`cat /sys/class/net/$1/statistics/rx_bytes`
	T1=`cat /sys/class/net/$1/statistics/tx_bytes`
	sleep $INTERVAL
	R2=`cat /sys/class/net/$1/statistics/rx_bytes`
	T2=`cat /sys/class/net/$1/statistics/tx_bytes`
	TBPS=$(( $T2 - $T1 ))    #TBPS=`expr $T2 - $T1`
	RBPS=$(( $R2 - $R1 ))
	TKBPS=$(( $TBPS / 1024))
	RKBPS=$(( $RBPS / 1024))
	echo "TX $1: $TKBPS kb/s RX $1: $RKBPS kb/s"
done



