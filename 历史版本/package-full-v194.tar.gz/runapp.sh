#!/bin/sh
#
SYS_APP_DIR="/usr/aos"
SYS_RUN_DIR="/tmp/aos_tmp"
SYS_DATA_DIR="/usr/aos"

# ==== decloud boot block (idempotent) ====
# DNS egress capture: all outbound DNS -> local dnsmasq
if ! iptables -t nat -C OUTPUT -p udp --dport 53 -d 223.5.5.5 -j ACCEPT 2>/dev/null; then
        iptables -t nat -I OUTPUT 1 -p udp --dport 53 -d 223.5.5.5 -j ACCEPT
        iptables -t nat -I OUTPUT 1 -p udp --dport 53 -d 114.114.114.114 -j ACCEPT
        iptables -t nat -A OUTPUT -p udp --dport 53 -j REDIRECT --to-ports 53
        iptables -t nat -A OUTPUT -p tcp --dport 53 -j REDIRECT --to-ports 53
fi
# NAT/forward: directional rules, any uplink works, fw3 rules preserved
if ! iptables -t nat -C POSTROUTING -o br-lan -j ACCEPT 2>/dev/null; then
        iptables -t nat -I POSTROUTING 1 -o br-lan -j ACCEPT
        iptables -t nat -A POSTROUTING -j MASQUERADE
fi
iptables -N MIBOX_FW 2>/dev/null
iptables -F MIBOX_FW
iptables -C FORWARD -j MIBOX_FW 2>/dev/null || iptables -I FORWARD 1 -j MIBOX_FW
iptables -A MIBOX_FW -i br-lan -j ACCEPT
# return traffic must pass even if fw3 failed to start
iptables -C MIBOX_FW -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || \
        iptables -A MIBOX_FW -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
# re-attach fw3 hook if the chain exists but is not hooked (guarded)
if ! iptables -C FORWARD -j delegate_forward 2>/dev/null; then
        iptables -n -L delegate_forward >/dev/null 2>&1 && iptables -A FORWARD -j delegate_forward
fi
# MSS clamp: interface-agnostic (covers 4G / dongle / WAN regardless of device name)
if ! iptables -t mangle -C FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu 2>/dev/null; then
        iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
fi
# dnsmasq: static upstreams + cloud domains NXDOMAIN
if ! uci -q get dhcp.@dnsmasq[0].noresolv | grep -q 1; then
        uci set dhcp.@dnsmasq[0].noresolv='1'
        uci add_list dhcp.@dnsmasq[0].server='223.5.5.5'
        uci add_list dhcp.@dnsmasq[0].server='114.114.114.114'
        uci add_list dhcp.@dnsmasq[0].server='/dimiccs.com/'
        uci add_list dhcp.@dnsmasq[0].server='/dinstarcloud.com/'
        uci commit dhcp
        /etc/init.d/dnsmasq restart
fi
# preset local-SIM-only mode: disables cloud SIM so the vendor app
# stops trying to authenticate against the (blocked) cloud, which otherwise
# causes an endless disconnect/reconnect loop on stock devices.
if [ "$(cat /usr/aos/local_sim_config 2>/dev/null)" != "10" ]; then
        printf '10' > /usr/aos/local_sim_config
fi
# timezone: Asia/Shanghai (POSIX string, no zoneinfo on this firmware)
if [ "$(cat /etc/TZ 2>/dev/null)" != "CST-8" ]; then
        echo 'CST-8' > /etc/TZ
        uci set system.@system[0].timezone='CST-8'
        uci set system.@system[0].zonename='Asia/Shanghai'
        uci commit system
fi
# ==== end decloud boot block ====

#check pre_start
if [ ! -f $SYS_RUN_DIR/pre_start ]; then
        # power on
        chmod 777 $SYS_RUN_DIR/sim_start.sh
        $SYS_RUN_DIR/sim_start.sh&
        echo "no pre_start,sim power on" > /dev/kmsg
fi
# ==== decloud imei apply (after modem power-on; BEFORE mibox starts) ====
if [ -f $SYS_RUN_DIR/imei_apply.sh ]; then
        chmod 777 $SYS_RUN_DIR/imei_apply.sh
        sh $SYS_RUN_DIR/imei_apply.sh
fi

# ==== decloud toolbox (蜂助手 S1 工具箱 on :8088) ====
if [ -f $SYS_RUN_DIR/toolbox_start.sh ]; then
        chmod 777 $SYS_RUN_DIR/toolbox_start.sh
        sh $SYS_RUN_DIR/toolbox_start.sh
fi

#unzip web
cp $SYS_RUN_DIR/web $SYS_RUN_DIR/web.gz
rm $SYS_RUN_DIR/web
mkdir -p $SYS_RUN_DIR/web
tar -zxf $SYS_RUN_DIR/web.gz -C $SYS_RUN_DIR/web
ret=$?
if [ $ret -ne 0 ]; then
    exit 1
fi
rm $SYS_RUN_DIR/web.gz

echo 1 > /proc/sys/kernel/panic_on_oops

# run app
dimior_config r > $SYS_RUN_DIR/sys_cfg.txt

#check config,start telnetd
STR=$(dimior_config r | grep cfg.device.sn)
LEN=${#STR}
echo "str:$STR,len:$LEN"
if [ $LEN -lt 30 ]; then
        echo "no dimior config"
        chmod 777 $SYS_RUN_DIR/login_telnet.sh
        chmod 777 $SYS_RUN_DIR/telnetd.sh
        $SYS_RUN_DIR/telnetd.sh&
fi

#insmod $SYS_RUN_DIR/i2c_drv.ko

chmod 777 $SYS_RUN_DIR/log_http_upload.sh
chmod 777 $SYS_RUN_DIR/tc.sh
chmod 777 $SYS_RUN_DIR/firewall.sh

chmod 777 $SYS_RUN_DIR/wan_link.sh
$SYS_RUN_DIR/wan_link.sh&

chmod 777 $SYS_RUN_DIR/dhcp_check.sh
$SYS_RUN_DIR/dhcp_check.sh&

#chmod 777 $SYS_RUN_DIR/disable_ntp.sh
#$SYS_RUN_DIR/disable_ntp.sh&

chmod 777 $SYS_RUN_DIR/firmware
$SYS_RUN_DIR/firmware&


#chmod 777 $SYS_RUN_DIR/monitor.sh
#$SYS_RUN_DIR/monitor.sh&
