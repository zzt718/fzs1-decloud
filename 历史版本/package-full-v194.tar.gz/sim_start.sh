#!/bin/sh

SYS_RUN_DIR="/tmp/aos_tmp"

#I2S_MODE --> GPIO MODE
#RUN - GPIO3
#CHAN0 - GPIO2
#CHAN1 - GPIO0
#I2C_INT - GPIO1

#WAN - GPIO37
#WIFI - GPIO44


reg s 0
#set ALL EPHY LED MODE
#set WLED_N GPIO MODE bit0~1=1
#reg w 0x64 0x01
#set EPHY_LED3 INPUT bit8~9=1
#set EPHY_LED1/4 OUTPUT bit4~5=1 bit10~bit11=1
#     0101 0001 0001
#reg w 0x64 0x101
reg w 0x64 0x511

#phy P1~P4 : ENABLE 
reg w 0x3c 0xe001ff
#uart1 --> /dev/ttyS0  bit27~24=0,  uart1--> sw_r/t bit27~24=0011
#run/chan0/chan1/i2c_int bit7~6=01,  i2s_mode -->ant_sel bit7~6=11
#wan gpio37 bit18 =1
#i2c mode bit21~20=00
#set wdt_rst --> wdt mode bit14 = 0 
#reg w 0x60 0x50040451
reg w 0x60 0x530404d1
#set wdt_rst_pin ouput period 257us
#set wdt reset apply to system reset
#enable wdt_rst_pin output when wdt reset
reg w 0x38 0xc1000200

insmod $SYS_RUN_DIR/i2c_drv.ko
#POWER ON MODEM..
#if [ ! -f /dev/ttyUSB1 ]; then
	echo "power on sim modem start" > /dev/kmsg
	chmod 777 $SYS_RUN_DIR/sim_start
	$SYS_RUN_DIR/sim_start -c&
#else
#	echo "skip... power sim modem" > /dev/kmsg
#fi
#chmod 777 $SYS_RUN_DIR/led_start.sh
#$SYS_RUN_DIR/led_start.sh&
echo "sim modem power on finish." > /dev/kmsg
