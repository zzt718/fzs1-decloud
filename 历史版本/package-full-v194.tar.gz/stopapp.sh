#!/bin/sh

echo "stopapp.sh" > /dev/kmsg
killall -q firmware
sync
sleep 2
echo "stopapp.sh end" > /dev/kmsg

