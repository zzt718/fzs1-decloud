#!/bin/sh
#set the following values to somewhat less than your actual download
# and uplink speed. In kilobits. Also set the device that is to be shaped.
TC=/usr/sbin/tc
AWK="awk"

DEV=br-lan
OUT=$1
ARGC=$#
ARG1=$2
ARG2=$3
ARG3=$4
ARG4=$5
ARG5=$6
PERTURB=5
PRIO=5
S_PRIO=6
L_PRIO=7

#下行限速 独立
divide(){
    if [[ $ARG2 == "init" ]];then
	if [[ $ARGC -ne 4 ]];then
	    divide_usage
        else
	    # stop share
	    			/etc/init.d/start_shortcut_fe_le stop
            HDLS=$($TC filter ls dev $DEV | grep "3:30" | $AWK '{print $10}')
            for HDL in $HDLS
            do
                $TC filter del dev $DEV protocol ip parent 3:0 prio $PRIO handle $HDL u32
            done
            $TC qdisc del dev $DEV root 2>/dev/null
            # main class 
            $TC qdisc add dev $DEV root handle 1: htb
            $TC class add dev $DEV parent 1:0 classid 1:1 htb rate $ARG3 ceil $ARG3
	fi
    elif [[ $ARG2 == "add" ]];then
        if [[ $ARGC -ne 6 ]];then
            divide_usage
        else
            #other class
            $TC class add dev $DEV parent 1:1 classid 1:${ARG3##*.} htb rate $ARG4 ceil $ARG5 2> /dev/null
	    if [[ $? -ne 0 ]];then
                $TC class change dev $DEV parent 1:1 classid 1:${ARG3##*.} htb rate $ARG4 ceil $ARG5
            else
                $TC qdisc add dev $DEV parent 1:${ARG3##*.} handle ${ARG3##*.}: sfq perturb $PERTURB
            fi
            RET=$($TC filter ls dev $DEV | grep -- "flowid 1:${ARG3##*.}" |  wc -l)
	    if [[ $RET -eq 0 ]];then
                $TC filter add dev $DEV protocol ip parent 1:0 prio $PRIO u32 match ip dst $ARG3 flowid 1:${ARG3##*.}
	    fi
        fi
    elif [[ $ARG2 == "change" ]];then
        if [[ $ARGC -ne 6 ]];then
            divide_usage
        else
	    if [[ $ARG3 == "all" ]];then
	        IDS=$($TC filter ls dev $DEV | grep "flowid" | $AWK '{print $19}')
	        for ID in $IDS
                do
                    $TC class change dev $DEV parent 1:1 classid ${ID} htb rate $ARG4 ceil $ARG5
	        done
	    else
                $TC class change dev $DEV parent 1:1 classid 1:${ARG3##*.} htb rate $ARG4 ceil $ARG5
	    fi
        fi
    elif [[ $ARG2 == "remove" ]];then
        if [[ $ARGC -ne 4 ]];then
            divide_usage
        else
	    if [[ $ARG3 == "all" ]];then
	        IDS=$($TC filter ls dev $DEV | grep "flowid" | $AWK '{print $19}')
	        for ID in $IDS
                do
                    HDLS=$($TC filter ls dev $DEV | grep -- "${ID}" | $AWK '{print $10}')
                    for HDL in $HDLS
                    do
                        $TC filter del dev $DEV protocol ip parent 1:0 prio $PRIO handle $HDL u32
                    done
	        done
	    else
                HDLS=$($TC filter ls dev $DEV | grep ${ARG3##*.} | $AWK '{print $10}')
                for HDL in $HDLS
                do
                    $TC filter del dev $DEV protocol ip parent 1:0 prio $PRIO handle $HDL u32
                done
	    fi
        fi
    elif [[ $ARG2 == "stop" ]];then
        IDS=$($TC filter ls dev $DEV | grep "flowid" | $AWK '{print $19}')
        for ID in $IDS
        do
            HDLS=$($TC filter ls dev $DEV | grep -- "${ID}" | $AWK '{print $10}')
            for HDL in $HDLS
            do
                $TC filter del dev $DEV protocol ip parent 1:0 prio $PRIO handle $HDL u32
            done
        done
        $TC qdisc del dev $DEV root 2>/dev/null
    else
	divide_usage
    fi    
}

#下行限速 共享
share(){
    if [[ $ARG2 == "init" ]];then
        if [[ $ARGC -ne 6 ]];then
            share_usage
        else
            #$TC qdisc del dev $DEV root 2>/dev/null

	    #init share
            $TC qdisc add dev $DEV root handle 3: htb
            $TC class add dev $DEV parent 3:0 classid 3:1 htb rate $ARG3 ceil $ARG3
			$TC class add dev $DEV parent 3:1 classid 3:30 htb rate $ARG4 ceil $ARG5 2> /dev/null
            if [[ $? -ne 0 ]];then
                $TC class change dev $DEV parent 3:1 classid 3:30 htb rate $ARG4 ceil $ARG5 prio $PRIO
            else
                $TC qdisc add dev $DEV parent 3:30 handle 30: sfq perturb $PERTURB
            fi
            RET=$($TC filter ls dev $DEV | grep -- "flowid 3:30" |  wc -l)
            if [[ $RET -eq 0 ]];then
                $TC filter add dev $DEV protocol ip parent 3:0 prio $PRIO handle 101 fw classid 3:30
            fi
        fi
    elif [[ $ARG2 == "change" ]];then
        if [[ $ARGC -ne 5 ]];then
	    share_usage
	else
            $TC class change dev $DEV parent 3:1 classid 3:30 htb rate $ARG3 ceil $ARG4 prio $PRIO
	fi
    elif [[ $ARG2 == "stop" ]];then
			#/etc/init.d/start_shortcut_fe_le start
		#$TC qdisc del dev $DEV root 2>/dev/null
		$TC filter del dev $DEV protocol ip parent 3:0 prio $PRIO handle 101 fw classid 3:30
		$TC qdisc del dev $DEV parent 3:30 handle 30: sfq perturb $PERTURB
		$TC class del dev $DEV parent 3:1 classid 3:30		
    elif [[ $ARG2 == "get" ]];then
        if [[ $ARG3 == "rate" ]];then
	    $TC class ls dev $DEV | grep "htb 3:30" | $AWK '{print $11}'
        elif [[ $ARG3 == "ceil" ]];then
	    $TC class ls dev $DEV | grep "htb 3:30" | $AWK '{print $13}'
	else
	    share_usage
	fi
    else
	share_usage
    fi
}

#上行限速 共享
upload(){
    if [[ $ARG2 == "init" ]];then
	if [[ $ARGC -ne 6 ]];then
	    upload_usage
	else
	    #$TC qdisc del dev $OUT root 2>/dev/null
            $TC qdisc add dev $OUT root handle 2: htb default 100
            $TC class add dev $OUT parent 2:0 classid 2:1 htb rate $ARG3 ceil $ARG3

	    $TC class add dev $OUT parent 2:1 classid 2:20 htb rate $ARG4 ceil $ARG5 prio $PRIO
		if [[ $? -ne 0 ]];then
			$TC class change dev $OUT parent 2:1 classid 2:20 htb rate $ARG4 ceil $ARG5 prio $PRIO
		else
			$TC qdisc add dev $OUT parent 2:20 handle 20: sfq perturb $PERTURB
		fi
	    $TC filter add dev $OUT protocol ip parent 2:0 prio $PRIO handle 102 fw classid 2:20
	fi
    elif [[ $ARG2 == "change" ]];then
	if [[ $ARGC -ne 5 ]];then
	    upload_usage
	else
	    $TC class change dev $OUT parent 2:1 classid 2:20 htb rate $ARG3 ceil $ARG4 prio $PRIO
	fi
    elif [[ $ARG2 == "stop" ]];then
        #$TC qdisc del dev $OUT root 2>/dev/null
		$TC filter del dev $OUT protocol ip parent 2:0 prio $PRIO handle 102 fw classid 2:20
		$TC qdisc del dev $OUT parent 2:20 handle 20: sfq perturb $PERTURB
		$TC class del dev $OUT parent 2:1 classid 2:20
    elif [[ $ARG2 == "get" ]];then
        if [[ $ARG3 == "rate" ]];then
            $TC class ls dev $OUT | grep "parent" | $AWK '{print $11}'
	elif [[ $ARG3 == "ceil" ]];then
            $TC class ls dev $OUT | grep "parent" | $AWK '{print $13}'
	else
	    upload_usage
	fi
    else
	upload_usage
    fi
}

#wifi下行限速 共享
s_share(){
    if [[ $ARG2 == "init" ]];then
        if [[ $ARGC -ne 6 ]];then
            s_share_usage
        else
            #$TC qdisc del dev $DEV root 2>/dev/null
	    #init s_share
            $TC qdisc add dev $DEV root handle 3: htb
            $TC class add dev $DEV parent 3:0 classid 3:1 htb rate $ARG3 ceil $ARG3
			$TC class add dev $DEV parent 3:1 classid 3:31 htb rate $ARG4 ceil $ARG5 2> /dev/null
            if [[ $? -ne 0 ]];then
                $TC class change dev $DEV parent 3:1 classid 3:31 htb rate $ARG4 ceil $ARG5 prio $S_PRIO
            else
                $TC qdisc add dev $DEV parent 3:31 handle 31: sfq perturb $PERTURB
            fi
            RET=$($TC filter ls dev $DEV | grep -- "flowid 3:31" |  wc -l)
            if [[ $RET -eq 0 ]];then
                $TC filter add dev $DEV protocol ip parent 3:0 prio $S_PRIO handle 100 fw classid 3:31
            fi
        fi
    elif [[ $ARG2 == "change" ]];then
        if [[ $ARGC -ne 5 ]];then
	    s_share_usage
	else
            $TC class change dev $DEV parent 3:1 classid 3:31 htb rate $ARG3 ceil $ARG4 prio $S_PRIO
	fi
    elif [[ $ARG2 == "stop" ]];then
			#/etc/init.d/start_shortcut_fe_le start
		#$TC qdisc del dev $DEV root 2>/dev/null
		$TC filter del dev $DEV protocol ip parent 3:0 prio $S_PRIO handle 100 fw classid 3:31
		$TC qdisc del dev $DEV parent 3:31 handle 31: sfq perturb $PERTURB
		$TC class del dev $DEV parent 3:1 classid 3:31
    elif [[ $ARG2 == "get" ]];then
        if [[ $ARG3 == "rate" ]];then
	    $TC class ls dev $DEV | grep "htb 3:31" | $AWK '{print $11}'
        elif [[ $ARG3 == "ceil" ]];then
	    $TC class ls dev $DEV | grep "htb 3:31" | $AWK '{print $13}'
	else
	    s_share_usage
	fi
    else
	s_share_usage
    fi
}

#wifi上行限速 共享
s_upload(){
    if [[ $ARG2 == "init" ]];then
	if [[ $ARGC -ne 6 ]];then
	    s_upload_usage
	else
	    #$TC qdisc del dev $OUT root 2>/dev/null
            $TC qdisc add dev $OUT root handle 2: htb default 100
            $TC class add dev $OUT parent 2:0 classid 2:1 htb rate $ARG3 ceil $ARG3

	    $TC class add dev $OUT parent 2:1 classid 2:21 htb rate $ARG4 ceil $ARG5 prio $S_PRIO
		if [[ $? -ne 0 ]];then
			$TC class change dev $OUT parent 2:1 classid 2:21 htb rate $ARG4 ceil $ARG5 prio $S_PRIO
		else
			$TC qdisc add dev $OUT parent 2:21 handle 21: sfq perturb $PERTURB
		fi
	    $TC filter add dev $OUT protocol ip parent 2:0 prio $S_PRIO handle 99 fw classid 2:21
	fi
    elif [[ $ARG2 == "change" ]];then
	if [[ $ARGC -ne 5 ]];then
	    s_upload_usage
	else
	    $TC class change dev $OUT parent 2:1 classid 2:21 htb rate $ARG3 ceil $ARG4 prio $S_PRIO
	fi
    elif [[ $ARG2 == "stop" ]];then
        #$TC qdisc del dev $OUT root 2>/dev/null
		$TC filter del dev $OUT protocol ip parent 2:0 prio $S_PRIO handle 99 fw classid 2:21
		$TC qdisc del dev $OUT parent 2:21 handle 21: sfq perturb $PERTURB
		$TC class del dev $OUT parent 2:1 classid 2:21
    elif [[ $ARG2 == "get" ]];then
        if [[ $ARG3 == "rate" ]];then
            $TC class ls dev $OUT | grep "parent" | $AWK '{print $11}'
	elif [[ $ARG3 == "ceil" ]];then
            $TC class ls dev $OUT | grep "parent" | $AWK '{print $13}'
	else
	    s_upload_usage
	fi
    else
	s_upload_usage
    fi
}

#LAN1下行限速 共享
l_share(){
    if [[ $ARG2 == "init" ]];then
        if [[ $ARGC -ne 6 ]];then
            l_share_usage
        else
            #$TC qdisc del dev $DEV root 2>/dev/null
	    #init l_share
            $TC qdisc add dev $DEV root handle 3: htb
            $TC class add dev $DEV parent 3:0 classid 3:1 htb rate $ARG3 ceil $ARG3
			$TC class add dev $DEV parent 3:1 classid 3:32 htb rate $ARG4 ceil $ARG5 2> /dev/null
            if [[ $? -ne 0 ]];then
                $TC class change dev $DEV parent 3:1 classid 3:32 htb rate $ARG4 ceil $ARG5 prio $L_PRIO
            else
                $TC qdisc add dev $DEV parent 3:32 handle 32: sfq perturb $PERTURB
            fi
            RET=$($TC filter ls dev $DEV | grep -- "flowid 3:32" |  wc -l)
            if [[ $RET -eq 0 ]];then
                $TC filter add dev $DEV protocol ip parent 3:0 prio $L_PRIO handle 98 fw classid 3:32
            fi
        fi
    elif [[ $ARG2 == "change" ]];then
        if [[ $ARGC -ne 5 ]];then
	    l_share_usage
	else
            $TC class change dev $DEV parent 3:1 classid 3:32 htb rate $ARG3 ceil $ARG4 prio $L_PRIO
	fi
    elif [[ $ARG2 == "stop" ]];then
			#/etc/init.d/start_shortcut_fe_le start
		#$TC qdisc del dev $DEV root 2>/dev/null
		$TC filter del dev $DEV protocol ip parent 3:0 prio $L_PRIO handle 98 fw classid 3:32
		$TC qdisc del dev $DEV parent 3:32 handle 32: sfq perturb $PERTURB
		$TC class del dev $DEV parent 3:1 classid 3:32
    elif [[ $ARG2 == "get" ]];then
        if [[ $ARG3 == "rate" ]];then
	    $TC class ls dev $DEV | grep "htb 3:32" | $AWK '{print $11}'
        elif [[ $ARG3 == "ceil" ]];then
	    $TC class ls dev $DEV | grep "htb 3:32" | $AWK '{print $13}'
	else
	    l_share_usage
	fi
    else
	l_share_usage
    fi
}

#LAN1 上行限速 共享
l_upload(){
    if [[ $ARG2 == "init" ]];then
	if [[ $ARGC -ne 6 ]];then
	    l_upload_usage
	else
	    #$TC qdisc del dev $OUT root 2>/dev/null
            $TC qdisc add dev $OUT root handle 2: htb default 100
            $TC class add dev $OUT parent 2:0 classid 2:1 htb rate $ARG3 ceil $ARG3

	    $TC class add dev $OUT parent 2:1 classid 2:22 htb rate $ARG4 ceil $ARG5 prio $S_PRIO
		if [[ $? -ne 0 ]];then
			$TC class change dev $OUT parent 2:1 classid 2:22 htb rate $ARG4 ceil $ARG5 prio $S_PRIO
		else
			$TC qdisc add dev $OUT parent 2:22 handle 22: sfq perturb $PERTURB
		fi
	    $TC filter add dev $OUT protocol ip parent 2:0 prio $S_PRIO handle 97 fw classid 2:22
	fi
    elif [[ $ARG2 == "change" ]];then
	if [[ $ARGC -ne 5 ]];then
	    l_upload_usage
	else
	    $TC class change dev $OUT parent 2:1 classid 2:22 htb rate $ARG3 ceil $ARG4 prio $S_PRIO
	fi
    elif [[ $ARG2 == "stop" ]];then
        #$TC qdisc del dev $OUT root 2>/dev/null
		$TC filter del dev $OUT protocol ip parent 2:0 prio $S_PRIO handle 97 fw classid 2:22
		$TC qdisc del dev $OUT parent 2:22 handle 22: sfq perturb $PERTURB
		$TC class del dev $OUT parent 2:1 classid 2:22
    elif [[ $ARG2 == "get" ]];then
        if [[ $ARG3 == "rate" ]];then
            $TC class ls dev $OUT | grep "parent" | $AWK '{print $11}'
	elif [[ $ARG3 == "ceil" ]];then
            $TC class ls dev $OUT | grep "parent" | $AWK '{print $13}'
	else
	    l_upload_usage
	fi
    else
	l_upload_usage
    fi
}

#查看状态
status() {
    CNTS=$($TC filter ls dev $DEV | grep "classid" |  wc -l)
    echo "========== TC limit speed status ============"
    DBDW=$($TC class ls dev $DEV | grep "root" | $AWK '{print $8}')
    UBDW=$($TC class ls dev $OUT | grep "root" | $AWK '{print $8}')
    if [[ "$DBDW" != "" ]];then
			echo "downlink bw:$DBDW"
    else
      if [[ "$UBDW" = "" ]];then
	    	echo "no limit"
	    	return
			fi
    fi
    if [[ "$UBDW" != "" ]];then
			echo "uplink bw:$UBDW"
    fi
		RET=$($TC filter ls dev $DEV | grep "classid 3:30" |  wc -l)
		if [[ $RET -ne 0 ]];then
	    RATE=$($TC class ls dev $DEV | grep "htb 3:30" | $AWK '{print $9}')
	    CEIL=$($TC class ls dev $DEV | grep "htb 3:30" | $AWK '{print $11}')
	    if [[ "$RATE" != "" ]];then
				echo "downlink speed limit"
				echo  share $RATE $CEIL
	  	fi
		fi
		
		RET=$($TC filter ls dev $DEV | grep "classid 3:31" |  wc -l)
		if [[ $RET -ne 0 ]];then
	    RATE=$($TC class ls dev $DEV | grep "htb 3:31" | $AWK '{print $9}')
	    CEIL=$($TC class ls dev $DEV | grep "htb 3:31" | $AWK '{print $11}')
	    if [[ "$RATE" != "" ]];then
				echo "wifi downlink speed limit"
				echo  share $RATE $CEIL
	  	fi
		fi

		RET=$($TC filter ls dev $DEV | grep "classid 3:32" |  wc -l)
		if [[ $RET -ne 0 ]];then
	    RATE=$($TC class ls dev $DEV | grep "htb 3:32" | $AWK '{print $9}')
	    CEIL=$($TC class ls dev $DEV | grep "htb 3:32" | $AWK '{print $11}')
	    if [[ "$RATE" != "" ]];then
				echo "lan1 downlink speed limit"
				echo  share $RATE $CEIL
	  	fi
		fi
		
    RATE=$($TC class ls dev $OUT | grep "2:20" | $AWK '{print $9}')
    CEIL=$($TC class ls dev $OUT | grep "2:20" | $AWK '{print $11}')
    if [[ "$RATE" != "" ]];then
        echo "uplink speed limit"
        echo "share $RATE  $CEIL"
    fi

    RATE=$($TC class ls dev $OUT | grep "2:21" | $AWK '{print $9}')
    CEIL=$($TC class ls dev $OUT | grep "2:21" | $AWK '{print $11}')
    if [[ "$RATE" != "" ]];then
        echo "wifi uplink speed limit"
        echo "share $RATE  $CEIL"
    fi

    RATE=$($TC class ls dev $OUT | grep "2:22" | $AWK '{print $9}')
    CEIL=$($TC class ls dev $OUT | grep "2:22" | $AWK '{print $11}')
    if [[ "$RATE" != "" ]];then
        echo "lan1 uplink speed limit"
        echo "share $RATE  $CEIL"
    fi
	
    echo "============================="
}

#帮助
usage() {
    echo "(usage):"
    echo "tc.sh [interface] divide ;limit downlink speed, please see tc.sh divide help"
    echo "tc.sh [interface] share  ;limit downlink speed(share), please see tc.sh share help"
    echo "tc.sh [interface] upload ;limit uplink speed(share), please see tc.sh upload help"
    echo "tc.sh [interface] status ;query speed limit status"
}

divide_usage(){
    echo "(usage):"
    echo "tc.sh [interface] divide init [bw]                           ;tc.sh wwan0 divide init 8mbit"
    echo "tc.sh [interface] divide add [ip] [speed] [max speed]        ;tc.sh wwan0 divide add 192.168.1.100 500kbit 600kbit"
    echo "tc.sh [interface] divide change [ip/all] [speed] [max speed] ;tc.sh wwan0 divide change all 1mbit 1mbit"
    echo "tc.sh [interface] divide remove [ip/all]                   "
    echo "tc.sh [interface] divide stop                                "
    echo "tc.sh [interface] status                                     "
}

share_usage(){
    echo "(usage):"
    echo "tc.sh [interface] share init [bw] [speed] [max speed]        ;tc.sh wwan0 share init 8mbit 800kbit 1mbit"
    echo "tc.sh [interface] share change [speed] [max speed]           "
    echo "tc.sh [interface] share stop                                   "
    echo "tc.sh [interface] share get rate                               "
    echo "tc.sh [interface] share get ceil                               "
    echo "tc.sh [interface] status                                       "
}

upload_usage(){
    echo "(usage):"
    echo "tc.sh [interface] upload init [bw] [speed] [max speed]         ;tc.sh wwan0 upload init 4mbit 800kbit 1mbit"
    echo "tc.sh [interface] upload change [speed] [max speed]"
    echo "tc.sh [interface] upload stop                                   "
    echo "tc.sh [interface] upload get rate                               "
    echo "tc.sh [interface] upload get ceil                               "
    echo "tc.sh [interface] status                                        "
}
s_share_usage(){
    echo "(usage):"
    echo "tc.sh [interface] s_share init [bw] [speed] [max speed]        ;tc.sh usb0 s_share init 8mbit 800kbit 1mbit"
    echo "tc.sh [interface] s_share change [speed] [max speed]           "
    echo "tc.sh [interface] s_share stop                                   "
    echo "tc.sh [interface] s_share get rate                               "
    echo "tc.sh [interface] s_share get ceil                               "
    echo "tc.sh [interface] status                                       "
}

s_upload_usage(){
    echo "(usage):"
    echo "tc.sh [interface] s_upload init [bw] [speed] [max speed]         ;tc.sh usb0 s_upload init 4mbit 800kbit 1mbit"
    echo "tc.sh [interface] s_upload change [speed] [max speed]"
    echo "tc.sh [interface] s_upload stop                                   "
    echo "tc.sh [interface] s_upload get rate                               "
    echo "tc.sh [interface] s_upload get ceil                               "
    echo "tc.sh [interface] status                                        "
}

l_share_usage(){
    echo "(usage):"
    echo "tc.sh [interface] l_share init [bw] [speed] [max speed]        ;tc.sh usb0 l_share init 8mbit 800kbit 1mbit"
    echo "tc.sh [interface] l_share change [speed] [max speed]           "
    echo "tc.sh [interface] l_share stop                                   "
    echo "tc.sh [interface] l_share get rate                               "
    echo "tc.sh [interface] l_share get ceil                               "
    echo "tc.sh [interface] status                                       "
}

l_upload_usage(){
    echo "(usage):"
    echo "tc.sh [interface] l_upload init [bw] [speed] [max speed]         ;tc.sh usb0 l_upload init 4mbit 800kbit 1mbit"
    echo "tc.sh [interface] l_upload change [speed] [max speed]"
    echo "tc.sh [interface] l_upload stop                                   "
    echo "tc.sh [interface] l_upload get rate                               "
    echo "tc.sh [interface] l_upload get ceil                               "
    echo "tc.sh [interface] status                                        "
}

case "$2" in
    divide)
        divide
        exit 0
        ;;
    share)
	share
        exit 0
        ;;
    upload)
	upload
        exit 0
        ;;
    s_share)
	s_share
        exit 0
        ;;
    s_upload)
	s_upload
        exit 0
        ;;
    l_share)
	l_share
        exit 0
        ;;
    l_upload)
	l_upload
        exit 0
        ;;		
	status)
	status
        exit 0
        ;;
    *) usage
        exit 1
        ;;
esac
