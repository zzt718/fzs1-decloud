#!/bin/sh
SYS_RUN_DIR="/tmp/aos_tmp"

echo "start telnetd.sh..." > /dev/kmsg

sleep 2
killall -q dropbear
telnetd -l $SYS_RUN_DIR/login_telnet.sh&
