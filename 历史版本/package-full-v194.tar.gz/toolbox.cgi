#!/bin/sh
# toolbox.cgi - decloud edition v6
# single AJAX endpoint (one microcom session), at-port mutex, single auto-refresh
FACTORY_BAND="12,78,145,482,149,0,2,2"
BACKUP=/etc/band_backup

at_port(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in *1.1:1.4*) echo "${t##*/}"; return;; esac
  done
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in
      *:1.4*)
        PP=${t##*/}
        R=$( (echo -e 'ATI
'; sleep 1) | microcom -t 1500 -s 115200 /dev/$PP 2>/dev/null )
        case "$R" in *EC200T*) echo "$PP"; return;; esac;;
    esac
  done
}
at_lock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    if [ -n "$LP" ] && kill -0 $LP 2>/dev/null; then
      i=0
      while [ $i -lt 12 ]; do
        LP=$(cat /tmp/at_busy.lock 2>/dev/null)
        kill -0 $LP 2>/dev/null || break
        sleep 1
        i=$((i+1))
      done
    fi
  fi
  echo $$ > /tmp/at_busy.lock
}
at_unlock(){ rm -f /tmp/at_busy.lock; }
at_trylock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    [ -n "$LP" ] && kill -0 $LP 2>/dev/null && return 1
  fi
  echo $$ > /tmp/at_busy.lock
  return 0
}

atc(){
  rm -f /tmp/atc_out_$$
  ( (echo -e "$2\r"; sleep 2) | microcom -t 3000 -s 115200 /dev/$1 > /tmp/atc_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 8; kill $MP 2>/dev/null; killall microcom 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  cat /tmp/atc_out_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' '
  rm -f /tmp/atc_out_$$
}
band_write(){
  at_lock
  i=0
  while [ $i -lt 4 ]; do
    ATP=$(at_port)
    if [ -n "$ATP" ]; then
      W=$(atc $ATP "AT*BAND=$1")
      case "$W" in *OK*) at_unlock; return 0;; esac
    fi
    sleep 3
    i=$((i+1))
  done
  at_unlock
  return 1
}
band_human(){
  BH_LOW=$(echo "$1" | cut -d, -f5)
  BH_HIGH=$(echo "$1" | cut -d, -f4)
  BH_OUT=""; BH_N=0
  [ $(( BH_LOW & 1 )) -ne 0 ] && { BH_OUT="$BH_OUT B1"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 4 )) -ne 0 ] && { BH_OUT="$BH_OUT B3"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 16 )) -ne 0 ] && { BH_OUT="$BH_OUT B5"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B8"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 2 )) -ne 0 ] && { BH_OUT="$BH_OUT B34"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 32 )) -ne 0 ] && { BH_OUT="$BH_OUT B38"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 64 )) -ne 0 ] && { BH_OUT="$BH_OUT B39"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B40"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 256 )) -ne 0 ] && { BH_OUT="$BH_OUT B41"; BH_N=$((BH_N+1)); }
  if [ $BH_N -eq 0 ]; then echo "当前未启用任何频段"; else echo "已启用$BH_OUT"; fi
}

# one session, all data -> key=value lines
data_read(){
  ATP=$(at_port)
  [ -z "$ATP" ] && { echo "STATUSFAIL"; return 1; }
  rm -f /tmp/st_out_$$
  ( (echo -e 'AT*BAND?\r'; sleep 1; echo -e 'AT+QENG="servingcell"\r'; sleep 1; echo -e 'AT+CGSN\r'; sleep 1; echo -e 'AT+QCCID\r'; sleep 1; echo -e 'AT+CSQ\r'; sleep 1) | microcom -t 3000 -s 115200 /dev/$ATP > /tmp/st_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 12; kill $MP 2>/dev/null; killall microcom 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  RAW=$(cat /tmp/st_out_$$ 2>/dev/null | tr -d '\r')
  rm -f /tmp/st_out_$$
  BANDV=$(echo "$RAW" | grep -o '\*BAND:[0-9,]*' | head -1 | sed 's/\*BAND://')
  CELL=$(echo "$RAW" | grep -o '+QENG: "servingcell".*' | head -1)
  DUPLEX=$(echo "$CELL" | cut -d, -f4 | tr -d '"')
  BAND=$(echo "$CELL" | cut -d, -f10)
  RSRP=$(echo "$CELL" | cut -d, -f14 | tr -d '"')
  SINR=$(echo "$CELL" | cut -d, -f17 | tr -d '"')
  IMEI=$(echo "$RAW" | grep -oE '^[0-9]{15}$' | head -1)
  ICCID=$(echo "$RAW" | grep -o '+QCCID: [0-9A-Fa-f]*' | head -1 | sed 's/+QCCID: //')
  CSQ=$(echo "$RAW" | grep -o '+CSQ: [0-9]*' | head -1 | sed 's/+CSQ: //')
  echo "BANDVAL=${BANDV:-READFAIL}"
  echo "DUPLEX=${DUPLEX:-?}"
  echo "BAND=${BAND:-?}"
  echo "IMEI=${IMEI:-读取失败}"
  echo "ICCID=${ICCID:-读取失败}"
  echo "CSQ=${CSQ:-?}"
  echo "RSRP=${RSRP:-?}"
  echo "SINR=${SINR:-?}"
  if [ -n "$BANDV" ]; then
    echo "HUMAN=$(band_human "$BANDV")"
  else
    echo "HUMAN=READFAIL"
  fi
  return 0
}

# ---------- ajax: all data (rate limited: min 8s between reads) ----------
case "$QUERY_STRING" in
  *a=data*)
    echo "Content-Type: text/plain; charset=utf-8"
    echo ""
    NOW=$(date +%s)
    LAST=""
    [ -f /tmp/at_lastdata ] && LAST=$(cat /tmp/at_lastdata 2>/dev/null)
    if [ -n "$LAST" ] && [ $((NOW - LAST)) -lt 8 ] && [ -f /tmp/at_cached ]; then
      cat /tmp/at_cached
      echo "CACHED=$((NOW - LAST))"
      echo "STAMP=$(date +%H:%M:%S)"
      exit 0
    fi
    if ! at_trylock; then
      if [ -f /tmp/at_cached ]; then
        cat /tmp/at_cached
        echo "CACHED=-1"
        echo "STAMP=$(date +%H:%M:%S)"
      else
        echo "BUSY"
      fi
      exit 0
    fi
    data_read | tee /tmp/at_cached
    if grep -q 'BANDVAL=[0-9]' /tmp/at_cached 2>/dev/null; then
      date +%s > /tmp/at_lastdata
    fi
    at_unlock
    echo "CACHED=0"
    echo "STAMP=$(date +%H:%M:%S)"
    exit 0
    ;;
esac

LEN=$(echo -n "$CONTENT_LENGTH" | grep -o '[0-9]*' | head -1)
BODY=""
[ -n "$LEN" ] && BODY=$(dd bs=1 count=$LEN 2>/dev/null)

RESULT=""; RESULT_OK=""; APPLIED=""
POSTED=0

# ---------- imei POST (PRG; may trigger reboot) ----------
case "$BODY" in
  *imei=*)
    WANT=$(echo "$BODY" | grep -o 'imei=[0-9]*' | head -1 | cut -d= -f2)
    case "$WANT" in
      [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]) : ;;
      *) WANT="";;
    esac
    REBOOTNOW=0
    case "$BODY" in *reboot=1*) REBOOTNOW=1;; esac
    if [ -n "$WANT" ]; then
      # luhn sanity (server side; module enforces anyway)
      LS=0; LD=0
      i=14
      while [ $i -ge 0 ]; do
        D=$(echo "$WANT" | cut -c$((i+1)))
        if [ $LD -eq 1 ]; then D=$((D*2)); [ $D -gt 9 ] && D=$((D-9)); fi
        LS=$((LS+D)); LD=$((1-LD))
        i=$((i-1))
      done
      if [ $((LS % 10)) -ne 0 ]; then
        rm -f /usr/aos/imei_request
        {
          echo "IMEI 校验位不合法，已拒绝保存（模组会拒绝写入）。请核对后重试。"
          echo ""
          echo ""
        } > /tmp/imei_result
        echo "Status: 302 Found"
        echo "Location: /?a=band"
        echo "Content-Type: text/html"
        echo ""
        echo "redirecting"
        exit 0
      fi
      echo "$WANT" > /usr/aos/imei_request
      if [ $REBOOTNOW -eq 1 ]; then
        echo "Content-Type: text/html; charset=utf-8"
        echo ""
        echo "<html><head><meta charset=utf-8><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:15px}</style></head><body>"
        echo "<h2>IMEI 已保存，设备正在重启…</h2>"
        echo "<p style='color:#c62828'>重启时会把新 IMEI 写入模组，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
        echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
        echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
        echo "</body></html>"
        (sleep 2; sync; reboot) &
        exit 0
      fi
      {
        echo "IMEI 已保存：$WANT"
        echo "1"
        echo ""
      } > /tmp/imei_result
    else
      {
        echo "IMEI 格式错误（需要 15 位数字）"
        echo ""
        echo ""
      } > /tmp/imei_result
    fi
    echo "Status: 302 Found"
    echo "Location: /?a=band"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
esac

# ---------- reboot only (standalone button) ----------
case "$BODY" in
  *reboot=1*)
    echo "Content-Type: text/html; charset=utf-8"
    echo ""
    echo "<html><head><meta charset=utf-8><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:15px}</style></head><body>"
    echo "<h2>设备正在重启…</h2>"
    echo "<p style='color:#c62828'>重启时会把新 IMEI 写入模组，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
    echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
    echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
    echo "</body></html>"
    (sleep 2; sync; reboot) &
    exit 0
    ;;
esac

# ---------- actions (POST only) ----------
# order matters: restore_bak BEFORE restore (prefix collision)
case "$BODY" in
  *restore_bak*)
    POSTED=1
    if [ -f $BACKUP ]; then
      BK=$(cat $BACKUP)
      case "$BK" in
        [0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*) : ;;
        *) BK="";;
      esac
      if [ -z "$BK" ]; then
        RESULT="备份文件无效，请改用“恢复出厂频段”"
      elif band_write "$BK"; then
        RESULT="已恢复上次配置，模组复位中（网络约1-3分钟恢复）"; RESULT_OK=1; APPLIED="$BK"
      else
        RESULT="恢复失败：模组未响应，请重试"
      fi
    else
      RESULT="没有备份记录"
    fi
    ;;
esac
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *restore*)
    POSTED=1
    if band_write "$FACTORY_BAND"; then
      RESULT="已恢复出厂默认频段，模组复位中（网络约1-3分钟恢复）"; RESULT_OK=1; APPLIED="$FACTORY_BAND"
    else
      RESULT="恢复失败：模组未响应，请重试（模组可能正在重启）"
    fi
    ;;
esac
fi
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *low=*)
    POSTED=1
    LOWNEW=$(echo "$BODY" | grep -o 'low=[0-9]*' | head -1 | cut -d= -f2)
    HIGHNEW=$(echo "$BODY" | grep -o 'high=[0-9]*' | head -1 | cut -d= -f2)
    case "$LOWNEW" in ''|*[!0-9]*) LOWNEW=0;; esac
    case "$HIGHNEW" in ''|*[!0-9]*) HIGHNEW=0;; esac
    if [ "$LOWNEW" -eq 0 ] && [ "$HIGHNEW" -eq 0 ]; then
      RESULT="错误：至少勾选一个频段"
    elif [ "$LOWNEW" -gt 255 ] || [ "$HIGHNEW" -gt 4095 ]; then
      RESULT="错误：频段值超范围"
    else
      at_lock
      OLDV=""
      ATP=$(at_port)
      [ -n "$ATP" ] && OLDV=$(atc $ATP 'AT*BAND?' | grep -o '\*BAND:[0-9,]*' | sed 's/\*BAND://')
      [ -n "$OLDV" ] && echo "$OLDV" > $BACKUP
      R1=$(echo "$OLDV" | cut -d, -f1); R2=$(echo "$OLDV" | cut -d, -f2); R3=$(echo "$OLDV" | cut -d, -f3)
      T1=$(echo "$OLDV" | cut -d, -f6); T2=$(echo "$OLDV" | cut -d, -f7); T3=$(echo "$OLDV" | cut -d, -f8)
      [ -z "$R1" ] && R1=12; [ -z "$R2" ] && R2=78; [ -z "$R3" ] && R3=145
      [ -z "$T1" ] && T1=0; [ -z "$T2" ] && T2=2; [ -z "$T3" ] && T3=2
      NEW="$R1,$R2,$R3,$HIGHNEW,$LOWNEW,$T1,$T2,$T3"
      WR=0
      i=0
      while [ $i -lt 4 ]; do
        ATP=$(at_port)
        if [ -n "$ATP" ]; then
          W=$(atc $ATP "AT*BAND=$NEW")
          case "$W" in *OK*) WR=1; break;; esac
        fi
        sleep 3
        i=$((i+1))
      done
      at_unlock
      if [ $WR -eq 1 ]; then
        RESULT="已应用新配置，模组复位中（网络约1-3分钟恢复）"; RESULT_OK=1; APPLIED="$NEW"
      else
        RESULT="写入失败：模组未响应，请重试"
      fi
    fi
    ;;
esac
fi

# ---------- PRG: POST -> store result -> 302 redirect ----------
if [ $POSTED -eq 1 ]; then
  {
    echo "$RESULT"
    echo "$RESULT_OK"
    echo "$APPLIED"
  } > /tmp/band_result
  echo "Status: 302 Found"
  echo "Location: /?a=band"
  echo "Content-Type: text/html"
  echo ""
  echo "redirecting"
  exit 0
fi

# ---------- GET: show stored result once, then delete ----------
IMEI_RESULT=""
IMEI_RESULT_OK=""
if [ -f /tmp/imei_result ]; then
  IMEI_RESULT=$(sed -n 1p /tmp/imei_result)
  IMEI_RESULT_OK=$(sed -n 2p /tmp/imei_result)
  rm -f /tmp/imei_result
fi
if [ -f /tmp/band_result ]; then
  RESULT=$(sed -n 1p /tmp/band_result)
  RESULT_OK=$(sed -n 2p /tmp/band_result)
  APPLIED=$(sed -n 3p /tmp/band_result)
  rm -f /tmp/band_result
fi
PENDING_IMEI=""
if [ -f /usr/aos/imei_request ]; then
  PENDING_IMEI=$(cat /usr/aos/imei_request 2>/dev/null | grep -o '[0-9]*' | head -1)
fi

# ---------- render ----------
HASBAK=""
[ -f $BACKUP ] && HASBAK=1
ck(){ [ $(( ($1 / $2) % 2 )) -eq 1 ] && echo "checked"; }

SKIPLOAD=0
CURTEXT="当前状态：正在读取，请稍候…"
if [ -n "$APPLIED" ]; then
  RLOW=$(echo "$APPLIED" | cut -d, -f5)
  RHIGH=$(echo "$APPLIED" | cut -d, -f4)
  CURTEXT="$(band_human "$APPLIED")"
  SKIPLOAD=1
else
  RLOW=0; RHIGH=0
fi
B1=$(ck $RLOW 1); B3=$(ck $RLOW 4); B5=$(ck $RLOW 16); B8=$(ck $RLOW 128)
B34=$(ck $RHIGH 2); B38=$(ck $RHIGH 32); B39=$(ck $RHIGH 64); B40=$(ck $RHIGH 128); B41=$(ck $RHIGH 256)
if [ -z "$APPLIED" ]; then
  B1=checked; B3=checked; B5=checked; B8=checked
  B34=checked; B38=checked; B39=checked; B40=checked; B41=checked
fi

echo "Content-Type: text/html; charset=utf-8"
echo "Cache-Control: no-store, no-cache, must-revalidate"
echo "Pragma: no-cache"
echo ""

cat << CEOF
<html><head><meta charset=utf-8><title>蜂助手 S1 CPE 工具箱</title><style>
body{font-family:sans-serif;max-width:760px;margin:24px auto;font-size:15px}
table{border-collapse:collapse;margin:8px 0}
td,th{border:1px solid #bbb;padding:6px 14px}
.btn{padding:8px 22px;font-size:15px;margin-right:10px}
.msg{padding:12px;margin:12px 0;border-radius:6px}
.ok{background:#e6f7e6;border:1px solid #4caf50}
.err{background:#fdecea;border:1px solid #e57373}
.note{color:#888;font-size:13px;margin-top:6px}
.spinner{width:44px;height:44px;border:5px solid #ddd;border-top-color:#4caf50;border-radius:50%;animation:sp 1s linear infinite;margin:0 auto 14px}
@keyframes sp{to{transform:rotate(360deg)}}
.info{background:#f7f9fc;border:1px solid #ccd;border-radius:8px;padding:12px 16px;margin:10px 0}
.info b{display:inline-block;min-width:110px}
</style></head><body>
<h2>蜂助手 S1 CPE 工具箱</h2>
CEOF

if [ -n "$RESULT" ]; then
  if [ -n "$RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $RESULT</div>"
  else
    echo "<div class='msg err'>✗ $RESULT</div>"
  fi
fi

cat << 'CEOF'
<script>
var busy=0;
function showWait(msg){
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.55);display:flex;align-items:center;justify-content:center;text-align:center;z-index:9999';
  d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18)"><div class="spinner"></div><p style="font-size:17px;margin:0">'+msg+'</p><p style="font-size:13px;color:#888;margin:8px 0 0">请稍候，完成后自动刷新</p></div>';
  document.body.appendChild(d);
}
function build(f){
  var low=parseInt(f.low_base.value)||0, high=parseInt(f.high_base.value)||0;
  var nl=low & ~149, nh=high & ~482;
  if(f.b1.checked) nl|=1; if(f.b3.checked) nl|=4;
  if(f.b5.checked) nl|=16; if(f.b8.checked) nl|=128;
  if(f.b34.checked) nh|=2;
  if(f.b38.checked) nh|=32; if(f.b39.checked) nh|=64;
  if(f.b40.checked) nh|=128; if(f.b41.checked) nh|=256;
  if(nl==0 && nh==0){ alert('至少勾选一个频段！'); return false; }
  f.low.value=''+nl; f.high.value=''+nh;
  if(!confirm('将应用频段：FDD='+nl+' TDD='+nh+'\n\n模组将复位，网络约1-3分钟后恢复。\n若之后一直无网，点本页“恢复出厂频段”即可。')) return false;
  showWait('正在应用频段，请稍候…');
  return true;
}
function waitRestore(msg){
  if(!confirm(msg+'\n\n确认继续？')) return false;
  showWait(msg);
  return true;
}
function loadAll(){
  if(busy) return;
  busy=1;
  var e=document.getElementById('info');
  e.innerHTML='正在读取模组数据，请稍候…';
  var x=new XMLHttpRequest();
  x.onreadystatechange=function(){
    if(x.readyState==4){
      busy=0;
      var t=(x.responseText||'').trim();
      if(t=='BUSY'){
        e.innerHTML='模组忙碌中（上一次读取未完成），3 秒后自动重试…';
        setTimeout(loadAll,3000);
        return;
      }
      if(x.status==200 && t.indexOf('BANDVAL=')>=0){
        var d={};
        t.split('\n').forEach(function(l){
          var p=l.indexOf('=');
          if(p>0) d[l.substring(0,p)]=l.substring(p+1);
        });
        var h='';
        if(d.DUPLEX!='?' && d.BAND!='?') h+='<b>当前驻网：</b>LTE '+d.DUPLEX+' 频段 B'+d.BAND+'<br>';
        else h+='<b>当前驻网：</b>未驻网（模组复位中或搜网中）<br>';
        var csq=parseInt(d.CSQ)||0;
        var rsrp=(d.RSRP&&d.RSRP!='?')?parseInt(d.RSRP):null;
        var q,lvl,dbm;
        if(rsrp!==null&&!isNaN(rsrp)){
          dbm='（RSRP '+rsrp+' dBm）';
          if(rsrp>=-85){q='很强';lvl=4;}
          else if(rsrp>=-95){q='良好';lvl=3;}
          else if(rsrp>=-105){q='一般';lvl=2;}
          else{q='较弱';lvl=1;}
        }else if(d.CSQ=='?'){
          q='未知';lvl=0;dbm='';
        }else{
          dbm='（约 '+(2*csq-113)+' dBm）';
          if(csq>=26){q='很强';lvl=4;}
          else if(csq>=18){q='良好';lvl=3;}
          else if(csq>=10){q='一般';lvl=2;}
          else{q='较弱';lvl=1;}
        }
        var bt='';
        for(var bi=1;bi<=4;bi++){
          var col=bi<=lvl?'#4caf50':'#ddd';
          var hh=6+bi*4;
          bt+='<span style="display:inline-block;width:5px;height:'+hh+'px;background:'+col+';margin-right:2px;vertical-align:bottom;border-radius:1px"></span>';
        }
        h+='<b>信号强度：</b>'+bt+' <span style="vertical-align:bottom">'+q+' '+dbm+'</span><br>';
        h+='<b>IMEI：</b>'+d.IMEI+'<br>';
        h+='<b>ICCID：</b>'+d.ICCID+'<br>';
        if(d.CACHED=='0'){
          h+='<span style="color:#2e7d32;font-size:12px">数据已更新 '+d.STAMP+'</span>';
        } else if(parseInt(d.CACHED)>0){
          h+='<span style="color:#b26a00;font-size:12px">刚刷新过（'+d.CACHED+' 秒前读取），数据无变化；稍等几秒再点即可重新读取</span>';
        } else {
          h+='<span style="color:#b26a00;font-size:12px">模组忙碌，显示上次数据（'+d.STAMP+'）</span>';
        }
        e.innerHTML=h;
        if(d.BANDVAL!='READFAIL'){
          var b=d.BANDVAL.split(',');
          var low=parseInt(b[4])||0, high=parseInt(b[3])||0;
          var f=document.getElementById('bandform');
          if(!f) return;
          f.b1.checked=!!(low&1); f.b3.checked=!!(low&4);
          f.b5.checked=!!(low&16); f.b8.checked=!!(low&128);
          f.b34.checked=!!(high&2); f.b38.checked=!!(high&32);
          f.b39.checked=!!(high&64); f.b40.checked=!!(high&128); f.b41.checked=!!(high&256);
          f.low_base.value=low; f.high_base.value=high;
          f.low.value=low; f.high.value=high;
          var c=document.getElementById('cur');
          if(c) c.innerHTML=d.HUMAN;
        } else {
          var c2=document.getElementById('cur');
          if(c2) c2.innerHTML='当前状态：读取失败（模组忙/重启中）— 不影响下方操作';
        }
      } else {
        e.innerHTML='读取失败（模组忙/重启中），可点“刷新数据”重试';
      }
    }
  };
  x.open('GET','?a=data',true);
  x.send();
}
</script>
CEOF

echo "<div class='info' id='info'>正在读取模组数据，请稍候…</div>"
echo "<p><button class=btn type=button onclick='loadAll()'>刷新数据</button></p>"
echo "<p class=note>参考：-80 很好、-95 良好、-105 一般、-110 以下较弱。</p>"

echo "<h3>① IMEI 改串</h3>"
if [ -n "$IMEI_RESULT" ]; then
  if [ -n "$IMEI_RESULT_OK" ]; then
    echo "<div class='msg ok'>$IMEI_RESULT</div>"
  else
    echo "<div class='msg err'>$IMEI_RESULT</div>"
  fi
fi
if [ -n "$PENDING_IMEI" ]; then
  echo "<div class='msg ok'>待应用的新 IMEI：<b>$PENDING_IMEI</b><br>点下方按钮重启设备，重启后自动写入模组生效。<br><span style='color:#c62828'>改串重启比平常久，约需 2-3 分钟，请耐心等待。</span></div>"
  echo "<form method=POST action='?a=band' onsubmit=\"return rebootOnly()\">"
  echo "<button class=btn type=submit name=reboot value='1'>立即重启设备生效</button>"
  echo "</form>"
fi
cat << 'IEOF'
<script>
function luhnCheck(s){
  var sum=0, dbl=false;
  for(var i=s.length-1;i>=0;i--){
    var d=parseInt(s.charAt(i),10);
    if(isNaN(d)) return false;
    if(dbl){ d*=2; if(d>9) d-=9; }
    sum+=d; dbl=!dbl;
  }
  return sum%10===0;
}
function luhnFix(s14){
  var sum=0, dbl=true;
  for(var i=s14.length-1;i>=0;i--){
    var d=parseInt(s14.charAt(i),10);
    if(dbl){ d*=2; if(d>9) d-=9; }
    sum+=d; dbl=!dbl;
  }
  var c=(10-(sum%10))%10;
  return s14+''+c;
}
function buildImei(f){
  var raw=f.imei.value.replace(/[^0-9]/g,'');
  var v=raw;
  if(v.length==14){
    var fixed=luhnFix(v);
    if(!confirm('你输入了 14 位数字，已自动补全校验位：\n\n  '+v+'  →  '+fixed+'\n\n使用这个 IMEI 吗？')){
      return false;
    }
    v=fixed;
  } else if(!/^[0-9]{15}$/.test(v)){
    alert('IMEI 格式不对：需要 15 位数字（当前 '+v.length+' 位）');
    return false;
  } else if(!luhnCheck(v)){
    var fixed15=luhnFix(v.substring(0,14));
    if(confirm('这个 IMEI 的校验位不合法，模组会拒绝写入！\n\n  你的输入：'+v+'\n  建议修正：'+fixed15+'\n\n使用修正后的值吗？\n（如果确定原始值没错，请点"取消"并重新核对）')){
      v=fixed15;
    } else {
      return false;
    }
  }
  f.imei.value=v;
  if(confirm('将 IMEI 改为：'+v+'\n\n是否立即重启设备生效？\n（注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待）')){
    f.reboot.value='1';
    var d=document.createElement('div');
    d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999';
    d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0">正在保存并重启设备…</p></div>';
    document.body.appendChild(d);
  } else {
    f.reboot.value='';
  }
  return true;
}
function rebootOnly(){
  if(!confirm('设备将立即重启，重启时自动把新 IMEI 写入模组。\n\n注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待。\n\n确认重启？')) return false;
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999';
  d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0">正在重启设备…</p></div>';
  document.body.appendChild(d);
  return true;
}
</script>
<form method=POST action="?a=band" onsubmit="return buildImei(this)">
<input type=hidden name=reboot value=''>
<p>新 IMEI：<input name=imei maxlength=20 size=20 placeholder="15位数字"> <input class=btn type=submit value='保存'></p>
<p class=note>点保存后会校验 IMEI 合法性（含校验位），可自动修正；确认后询问是否立即重启生效。</p>
<p class=note style="color:#c62828">改串后的重启比平常久（约 2-3 分钟），请耐心等待。</p>
</form>
IEOF
echo "<hr>"
echo "<h3>② 锁频段</h3>"
echo "<p id=cur style='color:#555;margin:14px 0 6px'>$CURTEXT</p>"
echo "<form id='bandform' method=POST action='?a=band' onsubmit='return build(this)'>"
echo "<input type=hidden name=low_base value='$RLOW'>"
echo "<input type=hidden name=high_base value='$RHIGH'>"
echo "<input type=hidden name=low value='$RLOW'>"
echo "<input type=hidden name=high value='$RHIGH'>"
cat << CEOF
<table>
<tr><th>FDD-LTE</th><th>频率</th><th>TDD-LTE</th><th>频率</th></tr>
<tr><td><input type=checkbox name=b1 $B1> B1</td><td>2100M</td>
<td><input type=checkbox name=b34 $B34> B34</td><td>2000M</td></tr>
<tr><td><input type=checkbox name=b3 $B3> B3</td><td>1800M</td>
<td><input type=checkbox name=b38 $B38> B38</td><td>1900M</td></tr>
<tr><td><input type=checkbox name=b5 $B5> B5</td><td>850M</td>
<td><input type=checkbox name=b39 $B39> B39</td><td>1900M</td></tr>
<tr><td><input type=checkbox name=b8 $B8> B8</td><td>900M</td>
<td><input type=checkbox name=b40 $B40> B40</td><td>2300M</td></tr>
<tr><td></td><td></td>
<td><input type=checkbox name=b41 $B41> B41</td><td>2500M</td></tr>
</table>
<p><input class=btn type=submit value='应用勾选'></p>
</form>
<p class=note>点“应用勾选”后模组会重启，断网约 1-3 分钟自动恢复；想立即看结果可点上方“刷新数据”。</p>
<p style="color:#666;margin:16px 0 6px;font-size:14px">锁频段后一直无网？可以恢复到已知可用的频段（模组重启中也能点）：</p>
<form method=POST action="?a=band" style="display:inline" onsubmit="return waitRestore('正在恢复出厂频段…')">
<input class=btn type=submit name=restore value='恢复出厂频段'>
</form>
CEOF

if [ -n "$HASBAK" ]; then
  echo "<form method=POST action='?a=band' style='display:inline' onsubmit=\"return waitRestore('正在恢复上次频段…')\">"
  echo "<input class=btn type=submit name=restore_bak value='恢复上次频段'>"
  echo "</form>"
fi


if [ -n "$APPLIED" ]; then
  echo "<script>setTimeout(loadAll,100000);</script>"
else
  echo "<script>setTimeout(loadAll,1200);</script>"
fi
echo "</body></html>"
