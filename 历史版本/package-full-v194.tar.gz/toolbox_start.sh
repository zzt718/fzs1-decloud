#!/bin/sh
# ============ decloud toolbox launcher ============
# installs ASR toolbox into /tmp and starts its uhttpd on 8088
DCT=/tmp/webimei
mkdir -p $DCT/cgi
cp /tmp/aos_tmp/toolbox.cgi $DCT/cgi/toolbox 2>/dev/null
cp /tmp/aos_tmp/toolbox.cgi $DCT/index.cgi 2>/dev/null
chmod 777 $DCT/cgi/toolbox $DCT/index.cgi 2>/dev/null
if ! netstat -tln 2>/dev/null | grep -q ':8088 '; then
  start-stop-daemon -S -b -m -p /tmp/uhttpd8088.pid -x /usr/sbin/uhttpd -- -f -p 0.0.0.0:8088 -h $DCT -x /cgi -i .cgi=/bin/sh -I index.cgi
fi
