#!/bin/sh
link_status=0
wan_port=0
first_up=1
first_down=1
count=0
reg_value=0
echo "check WAN link status"

read_wan_port()
{
	ret=`uci show network.@switch_vlan[1].ports`
	ret=`echo "$ret" | awk -F '=' '{print $2}'`

	wan_port=${ret:0:1}

	#echo "wan port:$wan_port" > /dev/kmsg
	return 0
}

read_register()
{
	result=`reg p 110080`

	#echo "register:$result" > /dev/kmsg
	if [ $wan_port == 0 ]; then
		reg_value=0x${result:3:1}
	elif [ $wan_port == 3 ]; then
		reg_value=0x${result:2:1}
	fi
	#echo "reg_value:$reg_value" > /dev/kmsg
	return 0
}

check_link_status()
{
	pid=`ps | grep udhcpc | grep -v "grep" | awk '{print $1}'`
	#echo "udhcpc pid:$pid" > /dev/kmsg
	read_register
		
	let "value=$reg_value&$1"	
	
	#echo "value:$value" > /dev/kmsg
	if [[ $value == $1 && $link_status != 1 ]]
	then
		echo "wan port,link up." > /dev/kmsg
		echo "link_status=1" > /tmp/link_status
		link_status=1
		if [ $first_up == 1 ]
		then
			echo "first link up,skip." > /dev/kmsg
		else
			kill -USR2 $pid
			kill -USR1 $pid			
		fi
		first_up=0		
	fi
	
	if [[ $value == 0 && $link_status != 0 ]]
	then		
		echo "wan port,link down.$count" > /dev/kmsg
		let count+=1
		if [ $count == 3 ]
		then
			kill -USR2 $pid
			link_status=0
			count=0
			echo "wan port,link down.end" > /dev/kmsg
			echo "link_status=0" > /tmp/link_status
		fi

	fi

}

reg s 0

while [ 1 ]
do
	read_wan_port
	if [ $wan_port == 0 ]
	then
		#echo "Port0,WAN mode." > /dev/kmsg
		check_link_status 2
	elif [ $wan_port == 3 ]
	then
		#echo "Port3,WAN mode." > /dev/kmsg
		check_link_status 1
	else
		echo "Port0,Port3,LAN mode."
	fi
	
	sleep 1
done
