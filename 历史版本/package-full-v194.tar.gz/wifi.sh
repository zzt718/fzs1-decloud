#!/bin/sh
WIFI_STATISTICS_FILE=/tmp/wifi_statistics
LAN1_STATISTICS_FILE=/tmp/lan1_statistics

speed(){

	echo "Collecting data..."
	echo ""
	cat /proc/net/arp | grep : | grep ^192 | grep -v 00:00:00:00:00:00 | awk '{print $1}' > mac-ip
	iptables -N UPLOAD
	iptables -N DOWNLOAD
	while read line;do iptables -I FORWARD 1 -s $line -j UPLOAD;done < mac-ip
	while read line;do iptables -I FORWARD 1 -d $line -j DOWNLOAD;done < mac-ip
	sleep 1
	echo "Download speed:"
	echo ""
	iptables -nvx -L FORWARD | grep DOWNLOAD | awk '{print $2/1024/1" KB/s ",$1/10" packets/s", $9}' 
	echo ""
	echo "Upload speed:"
	echo ""
	iptables -nvx -L FORWARD | grep UPLOAD | awk '{print $2/1024/1" KB/s ",$1/10" packets/s", $8}' 
	 
	while read line;do iptables -D FORWARD -s $line -j UPLOAD;done < mac-ip
	while read line;do iptables -D FORWARD -d $line -j DOWNLOAD;done < mac-ip
	iptables -X UPLOAD
	iptables -X DOWNLOAD

}
statistics(){
	iptables -t mangle -nvx -L FORWARD -w | grep DOWNLOAD | awk '{print "Rx="$2"Bytes ", $9}' > $WIFI_STATISTICS_FILE
	iptables -t mangle -nvx -L FORWARD -w | grep UPLOAD | awk '{print "Tx="$2"Bytes ", $8}' >> $WIFI_STATISTICS_FILE
}

statistics2(){
	iptables -t mangle -nvx -L FORWARD -w | grep DOWNLOAD_LAN1 | awk '{print "Rx="$2"Bytes ", $9}' > $LAN1_STATISTICS_FILE
	iptables -t mangle -nvx -L FORWARD -w | grep UPLOAD_LAN1 | awk '{print "Tx="$2"Bytes ", $8}' >> $LAN1_STATISTICS_FILE
}

restart(){
	uci commit
	mv /tmp/resolv.conf.auto /tmp/resolv.conf.bak
	if [ "$1" == "5G" ];then
		wifi down mt7663
		wifi up mt7663
	else
		wifi down mt7628
		wifi up mt7628		
	fi	
	mv /tmp/resolv.conf.bak /tmp/resolv.conf.auto
	echo "wifi restart..."
}

init(){
	iptables -t filter -F FORWARD -w
	iptables -t mangle -F FORWARD -w
	iptables -t mangle -N UPLOAD -w
	iptables -t mangle -N DOWNLOAD -w
	iptables -t mangle -N UPLOAD_LAN1 -w
	iptables -t mangle -N DOWNLOAD_LAN1 -w
}

case $1 in
		init)
		init
				return 0
				;;
        statistics)
        statistics
                return 0
                ;;
        statistics2)
        statistics2
                return 0
                ;;				
        restart)
        restart $2
                return 0
                ;;
        *)
                echo "wifi.sh <statistics|statistics2|restart>"
                return 1
                ;;
esac




