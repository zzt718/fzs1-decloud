#!/bin/sh
# toolbox.cgi - decloud edition v6
# single AJAX endpoint (one microcom session), at-port mutex, single auto-refresh
FACTORY_BAND="12,78,145,482,149,0,2,2"
AUTO_SEC=6
BACKUP=/etc/band_backup

at_port(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in *1.1:1.4*) echo "${t##*/}"; return;; esac
  done
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t)
    case "$p" in
      *:1.4*)
        PP=${t##*/}
        at_clearlock "$PP"
        R=$( (echo -e 'ATI
'; sleep 1) | microcom -t 1500 -s 115200 /dev/$PP 2>/dev/null )
        at_clearlock "$PP"
        case "$R" in *EC200T*) echo "$PP"; return;; esac;;
    esac
  done
}
at_lock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    if [ -n "$LP" ] && kill -0 $LP 2>/dev/null; then
      i=0
      while [ $i -lt 12 ]; do
        LP=$(cat /tmp/at_busy.lock 2>/dev/null)
        kill -0 $LP 2>/dev/null || break
        sleep 1
        i=$((i+1))
      done
    fi
  fi
  echo $$ > /tmp/at_busy.lock
}
at_unlock(){ rm -f /tmp/at_busy.lock; }
# microcom creates /var/lock/LCK..ttyUSBn and removes it on a clean exit.  If the
# process is killed (our watchdog does exactly that) the lock is left behind and
# every later open fails with "File exists" -- the module looks dead even though
# it is fine.  Clear the lock when its owner is gone.  Called before and after
# each microcom run so a stale lock can never wedge the AT port permanently.
at_clearlock(){
  L=/var/lock/LCK..$1
  [ -f "$L" ] || return 0
  LP=$(cat "$L" 2>/dev/null | tr -d '\0\r\n ')
  case "$LP" in
    ''|*[!0-9]*) rm -f "$L"; return 0 ;;
  esac
  kill -0 "$LP" 2>/dev/null || rm -f "$L"
}
at_trylock(){
  if [ -f /tmp/at_busy.lock ]; then
    LP=$(cat /tmp/at_busy.lock 2>/dev/null)
    [ -n "$LP" ] && kill -0 $LP 2>/dev/null && return 1
  fi
  echo $$ > /tmp/at_busy.lock
  return 0
}

atc(){
  at_clearlock "$1"
  rm -f /tmp/atc_out_$$
  # -t is microcom's own silence timeout: it exits by itself once the line goes
  # quiet, so the 8s watchdog the old version needed (and its killall, which
  # killed other readers and stranded the lock file) is gone.  Measured: stdin 1s
  # + -t 1500 reads every response in full, and cuts each call from 8s to ~4s.
  ( (echo -e "$2\r"; sleep 1) | microcom -t 1500 -s 115200 /dev/$1 > /tmp/atc_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  cat /tmp/atc_out_$$ 2>/dev/null | tr -d '\r' | tr '\n' ' '
  rm -f /tmp/atc_out_$$
  at_clearlock "$1"
}
band_write(){
  at_lock
  i=0
  while [ $i -lt 4 ]; do
    ATP=$(at_port)
    if [ -n "$ATP" ]; then
      W=$(atc $ATP "AT*BAND=$1")
      case "$W" in *OK*) at_unlock; return 0;; esac
    fi
    sleep 3
    i=$((i+1))
  done
  at_unlock
  return 1
}
band_human(){
  BH_LOW=$(echo "$1" | cut -d, -f5)
  BH_HIGH=$(echo "$1" | cut -d, -f4)
  BH_OUT=""; BH_N=0
  [ $(( BH_LOW & 1 )) -ne 0 ] && { BH_OUT="$BH_OUT B1"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 4 )) -ne 0 ] && { BH_OUT="$BH_OUT B3"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 16 )) -ne 0 ] && { BH_OUT="$BH_OUT B5"; BH_N=$((BH_N+1)); }
  [ $(( BH_LOW & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B8"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 2 )) -ne 0 ] && { BH_OUT="$BH_OUT B34"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 32 )) -ne 0 ] && { BH_OUT="$BH_OUT B38"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 64 )) -ne 0 ] && { BH_OUT="$BH_OUT B39"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 128 )) -ne 0 ] && { BH_OUT="$BH_OUT B40"; BH_N=$((BH_N+1)); }
  [ $(( BH_HIGH & 256 )) -ne 0 ] && { BH_OUT="$BH_OUT B41"; BH_N=$((BH_N+1)); }
  if [ $BH_N -eq 0 ]; then echo "当前未启用任何频段"; else echo "已启用$BH_OUT"; fi
}

# MCC/MNC -> operator name.  Values come from the servingcell response we
# already read, so no extra AT command is needed.
op_name(){
  case "$1" in
    46000|46002|46004|46007|46008) echo "中国移动" ;;
    46001|46006|46009)             echo "中国联通" ;;
    46003|46005|46011)             echo "中国电信" ;;
    46015)                         echo "中国广电" ;;
    ""|"?"|"000")                  echo "" ;;
    *)                             echo "其他($1)" ;;
  esac
}

# one session, all data -> key=value lines
data_read(){
  ATP=$(at_port)
  [ -z "$ATP" ] && { echo "STATUSFAIL"; return 1; }
  rm -f /tmp/st_out_$$
  # Commands are pipelined in one burst and the reply is collected once at the
  # end.  Measured on-device: ~1s with this setting versus ~8s when each command
  # waited a full second, with the same 5/5 response rate.
  at_clearlock "$ATP"
  ( (echo -e 'AT*BAND?\r'; echo -e 'AT+QENG="servingcell"\r'; echo -e 'AT+CGSN\r'; echo -e 'AT+QCCID\r'; echo -e 'AT+CSQ\r'; sleep 1) | microcom -t 800 -s 115200 /dev/$ATP > /tmp/st_out_$$ 2>/dev/null ) & MP=$!
  ( sleep 4; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  at_clearlock "$ATP"
  RAW=$(cat /tmp/st_out_$$ 2>/dev/null | tr -d '\r')
  rm -f /tmp/st_out_$$
  BANDV=$(echo "$RAW" | grep -o '\*BAND:[0-9,]*' | head -1 | sed 's/\*BAND://')
  CELL=$(echo "$RAW" | grep -o '+QENG: "servingcell".*' | head -1)
  DUPLEX=$(echo "$CELL" | cut -d, -f4 | tr -d '"')
  BAND=$(echo "$CELL" | cut -d, -f10)
  RSRP=$(echo "$CELL" | cut -d, -f14 | tr -d '"')
  SINR=$(echo "$CELL" | cut -d, -f17 | tr -d '"')
  IMEI=$(echo "$RAW" | grep -oE '^[0-9]{15}$' | head -1)
  ICCID=$(echo "$RAW" | grep -o '+QCCID: [0-9A-Fa-f]*' | head -1 | sed 's/+QCCID: //')
  CSQ=$(echo "$RAW" | grep -o '+CSQ: [0-9]*' | head -1 | sed 's/+CSQ: //')
  # MCC/MNC live in fields 5/6 of the servingcell response
  MCC=$(echo "$CELL" | cut -d, -f5 | tr -d '"')
  MNC=$(echo "$CELL" | cut -d, -f6 | tr -d '"')
  MCCMNC="${MCC}${MNC}"
  case "$MCCMNC" in *[!0-9]*) MCCMNC="";; esac
  OPER=$(op_name "$MCCMNC")
  echo "BANDVAL=${BANDV:-READFAIL}"
  echo "DUPLEX=${DUPLEX:-?}"
  echo "BAND=${BAND:-?}"
  echo "IMEI=${IMEI:-读取失败}"
  echo "ICCID=${ICCID:-读取失败}"
  echo "CSQ=${CSQ:-?}"
  echo "RSRP=${RSRP:-?}"
  echo "SINR=${SINR:-?}"
  echo "OPER=$OPER"
  if [ -n "$BANDV" ]; then
    echo "HUMAN=$(band_human "$BANDV")"
  else
    echo "HUMAN=READFAIL"
  fi
  return 0
}

# The timestamp must describe when the data was actually read, not when it was
# served, so a cache hit re-emits the stored time instead of "now".  The panel
# therefore only shows a new time when a real AT read took place.
stamp_out(){
  ST=$(cat /tmp/at_stamp 2>/dev/null)
  [ -z "$ST" ] && ST=$(date +%H:%M:%S)
  echo "STAMP=$ST"
}

# ---------- ajax: all data (rate limited: min 3s between reads) ----------
case "$QUERY_STRING" in
  *a=data*)
    echo "Content-Type: text/plain; charset=utf-8"
    echo ""
    NOW=$(date +%s)
    LAST=""
    [ -f /tmp/at_lastdata ] && LAST=$(cat /tmp/at_lastdata 2>/dev/null)
    # A manual refresh sends force=1 and must always end in a real read, so it
    # bypasses the cache branch entirely and reads the module now.  The throttle
    # window is not waited out: at_trylock() below already serialises access, and
    # sleeping here only adds dead time (measured 5-6s instead of ~2s).
    # Auto-refresh omits the flag and still uses the cache, so the AT port is not
    # hit on every single tick.
    FORCE=0
    case "$QUERY_STRING" in *force=1*) FORCE=1 ;; esac
    if [ $FORCE -eq 0 ] && [ -n "$LAST" ] && [ $((NOW - LAST)) -lt 3 ] && [ -f /tmp/at_cached ]; then
      cat /tmp/at_cached
      # Keep the reported age at >=1.  A cache hit landing in the same second
      # would otherwise emit CACHED=0, which is the marker for "freshly read".
      AGE=$((NOW - LAST)); [ $AGE -lt 1 ] && AGE=1
      echo "CACHED=$AGE"
      stamp_out
      exit 0
    fi
    if ! at_trylock; then
      if [ -f /tmp/at_cached ]; then
        cat /tmp/at_cached
        echo "CACHED=-1"
        stamp_out
      else
        echo "BUSY"
      fi
      exit 0
    fi
    # The vendor app polls the same AT port every 20s and occasionally bursts a
    # SIM re-identification sequence; a read landing inside such a burst can come
    # back empty.  Retry before giving up, and only mark the result as fresh when
    # a retry actually succeeded (otherwise a stale cache would look fresh).
    GOT=0
    RT=0
    while [ $RT -lt 3 ]; do
      data_read > /tmp/at_try_$$ 2>/dev/null
      if grep -q 'BANDVAL=[0-9]' /tmp/at_try_$$ 2>/dev/null; then
        mv /tmp/at_try_$$ /tmp/at_cached
        GOT=1
        break
      fi
      RT=$((RT+1))
      [ $RT -lt 3 ] && sleep 2
    done
    rm -f /tmp/at_try_$$
    if [ ! -f /tmp/at_cached ]; then
      echo "STATUSFAIL"
    else
      cat /tmp/at_cached
    fi
    if [ $GOT -eq 1 ]; then
      date +%s > /tmp/at_lastdata
      date +%H:%M:%S > /tmp/at_stamp
    fi
    at_unlock
    echo "CACHED=0"
    stamp_out
    exit 0
    ;;
esac

LEN=$(echo -n "$CONTENT_LENGTH" | grep -o '[0-9]*' | head -1)
BODY=""
[ -n "$LEN" ] && BODY=$(dd bs=1 count=$LEN 2>/dev/null)

RESULT=""; RESULT_OK=""; APPLIED=""
POSTED=0

# ---------- imei POST (PRG; may trigger reboot) ----------
# ---------- root password POST (for the 8888 LuCI panel) ----------
case "$BODY" in
  *pw1=*)
    urldecode(){
      printf '%b' "$(echo "$1" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')"
    }
    PW0=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw0=\([^&]*\).*/\1/p' | head -1)")
    PW1=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw1=\([^&]*\).*/\1/p' | head -1)")
    PW2=$(urldecode "$(echo "$BODY" | sed -n 's/.*pw2=\([^&]*\).*/\1/p' | head -1)")
    PW_RESULT=""; PW_OK=""
    # Whether the CURRENT PASSWORD must be verified depends on whether the user has
    # ever set one through this page -- NOT on whether root has a hash.  The factory
    # password is unknown to us and to the user, so a device that was never
    # configured here must be allowed to set one without knowing the old value;
    # otherwise the feature is unusable.  Once the user has set it themselves, every
    # later change must prove knowledge of it, so nobody else can take it over.
    PW_PREV=""
    if [ -f /usr/aos/decloud_pw_set ] || [ -f /tmp/webimei/pw_set ]; then PW_PREV=1; fi
    if [ -z "$PW1" ]; then
      PW_RESULT="密码不能为空"
    elif [ "$PW1" != "$PW2" ]; then
      PW_RESULT="两次输入的密码不一致"
    elif [ ${#PW1} -lt 8 ]; then
      PW_RESULT="密码太短，请至少 8 位"
    elif [ -n "$PW_PREV" ]; then
      # 已设过密码：校验当前密码（用 lua + nixio.crypt 比对 /etc/shadow）
      printf '%s' "$PW0" > /tmp/.pwchk
      PW_VALID=$(lua -e '
        local f=io.open("/tmp/.pwchk"); local p=f:read("*a"); f:close()
        local s=io.open("/etc/shadow"):read("*a")
        local h=s:match("^root:([^:]*):")
        local ok=require("nixio")
        if h and h~="" and h~="!" and h~="x" and ok.crypt(p,h)==h then print("1") else print("0") end
      ' 2>/dev/null)
      rm -f /tmp/.pwchk
      if [ "$PW_VALID" != "1" ]; then
        PW_RESULT="当前密码不正确，未做修改"
      else
        PW_SET_GO=1
      fi
    else
      PW_SET_GO=1
    fi
    if [ -n "$PW_SET_GO" ]; then
      BEFORE=$(grep '^root' /etc/shadow 2>/dev/null | cut -d: -f2)
      printf '%s\n%s\n' "$PW1" "$PW2" | passwd root >/tmp/pw_try 2>&1
      AFTER=$(grep '^root' /etc/shadow 2>/dev/null | cut -d: -f2)
      if [ -n "$AFTER" ] && [ "$BEFORE" != "$AFTER" ]; then
        # 用户已通过本界面设过密码：此后修改必须先验证旧密码
        echo 1 > /usr/aos/decloud_pw_set 2>/dev/null
        echo 1 > /tmp/webimei/pw_set 2>/dev/null
        PW_RESULT="密码设置成功！现在可用 root + 该密码登录 8888 管理后台"
        PW_OK=1
      else
        PW_RESULT="密码设置失败，请重试"
      fi
    fi
    echo "$PW_RESULT" > /tmp/pw_result
    echo "$PW_OK" > /tmp/pw_result_ok
    rm -f /tmp/pw_try
    echo "Status: 302 Found"
    echo "Location: /"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
  *imei=*)
    WANT=$(echo "$BODY" | grep -o 'imei=[0-9]*' | head -1 | cut -d= -f2)
    case "$WANT" in
      [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]) : ;;
      *) WANT="";;
    esac
    REBOOTNOW=0
    case "$BODY" in *reboot=1*) REBOOTNOW=1;; esac
    if [ -n "$WANT" ]; then
      # luhn sanity (server side; module enforces anyway)
      LS=0; LD=0
      i=14
      while [ $i -ge 0 ]; do
        D=$(echo "$WANT" | cut -c$((i+1)))
        if [ $LD -eq 1 ]; then D=$((D*2)); [ $D -gt 9 ] && D=$((D-9)); fi
        LS=$((LS+D)); LD=$((1-LD))
        i=$((i-1))
      done
      if [ $((LS % 10)) -ne 0 ]; then
        rm -f /usr/aos/imei_request
        {
          echo "IMEI 校验位不合法，已拒绝保存（模组会拒绝写入）。请核对后重试。"
          echo ""
          echo ""
        } > /tmp/imei_result
        echo "Status: 302 Found"
        echo "Location: /?a=band"
        echo "Content-Type: text/html"
        echo ""
        echo "redirecting"
        exit 0
      fi
      echo "$WANT" > /usr/aos/imei_request
      if [ $REBOOTNOW -eq 1 ]; then
        echo "Content-Type: text/html; charset=utf-8"
        echo ""
        echo "<html><head><meta charset=utf-8><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:15px}</style></head><body>"
        echo "<h2>IMEI 已保存，设备正在重启…</h2>"
        echo "<p style='color:#c62828'>重启时会把新 IMEI 写入模组，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
        echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
        echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
        echo "</body></html>"
        (sleep 2; sync; reboot) &
        exit 0
      fi
      {
        echo "IMEI 已保存：$WANT"
        echo "1"
        echo ""
      } > /tmp/imei_result
    else
      {
        echo "IMEI 格式错误（需要 15 位数字）"
        echo ""
        echo ""
      } > /tmp/imei_result
    fi
    echo "Status: 302 Found"
    echo "Location: /?a=band"
    echo "Content-Type: text/html"
    echo ""
    echo "redirecting"
    exit 0
    ;;
esac

# ---------- reboot only (standalone button) ----------
case "$BODY" in
  *reboot=1*)
    echo "Content-Type: text/html; charset=utf-8"
    echo ""
    echo "<html><head><meta charset=utf-8><title>设备重启中</title><style>body{font-family:sans-serif;text-align:center;margin-top:80px;font-size:15px}</style></head><body>"
    echo "<h2>设备正在重启…</h2>"
    echo "<p style='color:#c62828'>重启时会把新 IMEI 写入模组，约需 2-3 分钟（比平常重启久，请耐心等待，不要断电）。</p>"
    echo "<p style='color:#888'>本页将在 3 分钟后自动刷新</p>"
    echo "<script>setTimeout(function(){location.href='/?a=band';},180000);</script>"
    echo "</body></html>"
    (sleep 2; sync; reboot) &
    exit 0
    ;;
esac

# ---------- actions (POST only) ----------
# order matters: restore_bak BEFORE restore (prefix collision)
case "$BODY" in
  *restore_bak*)
    POSTED=1
    if [ -f $BACKUP ]; then
      BK=$(cat $BACKUP)
      case "$BK" in
        [0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*,[0-9]*) : ;;
        *) BK="";;
      esac
      if [ -z "$BK" ]; then
        RESULT="备份文件无效，请改用“恢复出厂频段”"
      elif band_write "$BK"; then
        RESULT="已恢复上次配置，模组复位中（网络约1-3分钟恢复）"; RESULT_OK=1; APPLIED="$BK"
      else
        RESULT="恢复失败：模组未响应，请重试"
      fi
    else
      RESULT="没有备份记录"
    fi
    ;;
esac
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *restore*)
    POSTED=1
    if band_write "$FACTORY_BAND"; then
      RESULT="已恢复出厂默认频段，模组复位中（网络约1-3分钟恢复）"; RESULT_OK=1; APPLIED="$FACTORY_BAND"
    else
      RESULT="恢复失败：模组未响应，请重试（模组可能正在重启）"
    fi
    ;;
esac
fi
if [ $POSTED -eq 0 ]; then
case "$BODY" in
  *low=*)
    POSTED=1
    LOWNEW=$(echo "$BODY" | grep -o 'low=[0-9]*' | head -1 | cut -d= -f2)
    HIGHNEW=$(echo "$BODY" | grep -o 'high=[0-9]*' | head -1 | cut -d= -f2)
    case "$LOWNEW" in ''|*[!0-9]*) LOWNEW=0;; esac
    case "$HIGHNEW" in ''|*[!0-9]*) HIGHNEW=0;; esac
    if [ "$LOWNEW" -eq 0 ] && [ "$HIGHNEW" -eq 0 ]; then
      RESULT="错误：至少勾选一个频段"
    elif [ "$LOWNEW" -gt 255 ] || [ "$HIGHNEW" -gt 4095 ]; then
      RESULT="错误：频段值超范围"
    else
      at_lock
      OLDV=""
      ATP=$(at_port)
      [ -n "$ATP" ] && OLDV=$(atc $ATP 'AT*BAND?' | grep -o '\*BAND:[0-9,]*' | sed 's/\*BAND://')
      [ -n "$OLDV" ] && echo "$OLDV" > $BACKUP
      R1=$(echo "$OLDV" | cut -d, -f1); R2=$(echo "$OLDV" | cut -d, -f2); R3=$(echo "$OLDV" | cut -d, -f3)
      T1=$(echo "$OLDV" | cut -d, -f6); T2=$(echo "$OLDV" | cut -d, -f7); T3=$(echo "$OLDV" | cut -d, -f8)
      [ -z "$R1" ] && R1=12; [ -z "$R2" ] && R2=78; [ -z "$R3" ] && R3=145
      [ -z "$T1" ] && T1=0; [ -z "$T2" ] && T2=2; [ -z "$T3" ] && T3=2
      NEW="$R1,$R2,$R3,$HIGHNEW,$LOWNEW,$T1,$T2,$T3"
      WR=0
      i=0
      while [ $i -lt 4 ]; do
        ATP=$(at_port)
        if [ -n "$ATP" ]; then
          W=$(atc $ATP "AT*BAND=$NEW")
          case "$W" in *OK*) WR=1; break;; esac
        fi
        sleep 3
        i=$((i+1))
      done
      at_unlock
      if [ $WR -eq 1 ]; then
        RESULT="已应用新配置，模组复位中（网络约1-3分钟恢复）"; RESULT_OK=1; APPLIED="$NEW"
      else
        RESULT="写入失败：模组未响应，请重试"
      fi
    fi
    ;;
esac
fi

# ---------- PRG: POST -> store result -> 302 redirect ----------
if [ $POSTED -eq 1 ]; then
  {
    echo "$RESULT"
    echo "$RESULT_OK"
    echo "$APPLIED"
  } > /tmp/band_result
  echo "Status: 302 Found"
  echo "Location: /?a=band"
  echo "Content-Type: text/html"
  echo ""
  echo "redirecting"
  exit 0
fi

# ---------- GET: show stored result once, then delete ----------
PW_RESULT=""
PW_RESULT_OK=""
[ -f /tmp/pw_result ] && PW_RESULT=$(cat /tmp/pw_result 2>/dev/null)
[ -f /tmp/pw_result_ok ] && PW_RESULT_OK=$(cat /tmp/pw_result_ok 2>/dev/null)
rm -f /tmp/pw_result /tmp/pw_result_ok
# 用户是否通过工具箱设过密码（决定是否显示"已设置"状态）
PW_USER_SET=""
# Same rule as the POST branch: the "current password" field appears only once the
# user has set a password through this page (marker present).  A never-configured
# device must be settable without knowing the factory password.
if [ -f /usr/aos/decloud_pw_set ] || [ -f /tmp/webimei/pw_set ]; then
  PW_USER_SET=1
fi

IMEI_RESULT=""
IMEI_RESULT_OK=""
if [ -f /tmp/imei_result ]; then
  IMEI_RESULT=$(sed -n 1p /tmp/imei_result)
  IMEI_RESULT_OK=$(sed -n 2p /tmp/imei_result)
  rm -f /tmp/imei_result
fi
if [ -f /tmp/band_result ]; then
  RESULT=$(sed -n 1p /tmp/band_result)
  RESULT_OK=$(sed -n 2p /tmp/band_result)
  APPLIED=$(sed -n 3p /tmp/band_result)
  rm -f /tmp/band_result
fi
PENDING_IMEI=""
if [ -f /usr/aos/imei_request ]; then
  PENDING_IMEI=$(cat /usr/aos/imei_request 2>/dev/null | grep -o '[0-9]*' | head -1)
fi

# ---------- render ----------
HASBAK=""
[ -f $BACKUP ] && HASBAK=1
ck(){ [ $(( ($1 / $2) % 2 )) -eq 1 ] && echo "checked"; }

SKIPLOAD=0
CURTEXT="当前状态：正在读取，请稍候…"
if [ -n "$APPLIED" ]; then
  RLOW=$(echo "$APPLIED" | cut -d, -f5)
  RHIGH=$(echo "$APPLIED" | cut -d, -f4)
  CURTEXT="$(band_human "$APPLIED")"
  SKIPLOAD=1
else
  RLOW=0; RHIGH=0
fi
B1=$(ck $RLOW 1); B3=$(ck $RLOW 4); B5=$(ck $RLOW 16); B8=$(ck $RLOW 128)
B34=$(ck $RHIGH 2); B38=$(ck $RHIGH 32); B39=$(ck $RHIGH 64); B40=$(ck $RHIGH 128); B41=$(ck $RHIGH 256)
if [ -z "$APPLIED" ]; then
  B1=checked; B3=checked; B5=checked; B8=checked
  B34=checked; B38=checked; B39=checked; B40=checked; B41=checked
fi

echo "Content-Type: text/html; charset=utf-8"
echo "Cache-Control: no-store, no-cache, must-revalidate"
echo "Pragma: no-cache"
echo ""

cat << CEOF
<html><head><meta charset=utf-8><title>蜂助手 S1 CPE 工具箱</title><style>
body{font-family:sans-serif;max-width:760px;margin:24px auto;font-size:15px}
table{border-collapse:collapse;margin:8px 0}
td,th{border:1px solid #bbb;padding:6px 14px}
.btn{padding:8px 22px;font-size:15px;margin-right:10px}
.msg{padding:12px;margin:12px 0;border-radius:6px}
.ok{background:#e6f7e6;border:1px solid #4caf50}
.err{background:#fdecea;border:1px solid #e57373}
.note{color:#888;font-size:13px;margin-top:6px}
.spinner{width:44px;height:44px;border:5px solid #ddd;border-top-color:#4caf50;border-radius:50%;animation:sp 1s linear infinite;margin:0 auto 14px}
.maskv{display:inline-block;width:180px;white-space:pre;font-family:monospace;letter-spacing:1px}
.eye{color:#888;cursor:pointer;opacity:.45;display:inline-block;vertical-align:-3px;transition:opacity .15s;user-select:none}
.eye:hover{opacity:.95}
.refresh{background:#fff;border:1px solid #ddd;border-radius:6px;cursor:pointer;
  padding:3px 9px;color:#777;font-size:13px;vertical-align:middle;line-height:1.6}
.refresh:hover{border-color:#4caf50;color:#2e7d32}
.refresh svg{vertical-align:-2px}
.refresh.spin svg{animation:spin .9s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.auto{color:#aaa;font-size:12px;margin-left:8px}
.pwin{width:220px;padding:5px 8px;border:1px solid #bbb;border-radius:4px;font-size:14px}
.pwin:focus{outline:none;border-color:#4caf50}
.pwmsg{font-size:13px;margin-left:8px}
.pwok{color:#2e7d32}
code{background:#f0f0f0;padding:1px 5px;border-radius:3px;font-size:13px}
.pwerr{color:#c62828}
@keyframes sp{to{transform:rotate(360deg)}}
.info{background:#f7f9fc;border:1px solid #ccd;border-radius:8px;padding:12px 16px;margin:10px 0}
.info b{display:inline-block;min-width:110px}
</style></head><body>
<h2>蜂助手 S1 CPE 工具箱</h2>
CEOF

cat << 'CEOF'
<script>
var busy=0;
function showWait(msg){
  PAUSED=1;
  if(timer) clearTimeout(timer);
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.55);display:flex;align-items:center;justify-content:center;text-align:center;z-index:9999';
  d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18)"><div class="spinner"></div><p style="font-size:17px;margin:0">'+msg+'</p><p style="font-size:13px;color:#888;margin:8px 0 0">请稍候，完成后自动刷新</p></div>';
  document.body.appendChild(d);
}
function build(f){
  var low=parseInt(f.low_base.value)||0, high=parseInt(f.high_base.value)||0;
  var nl=low & ~149, nh=high & ~482;
  if(f.b1.checked) nl|=1; if(f.b3.checked) nl|=4;
  if(f.b5.checked) nl|=16; if(f.b8.checked) nl|=128;
  if(f.b34.checked) nh|=2;
  if(f.b38.checked) nh|=32; if(f.b39.checked) nh|=64;
  if(f.b40.checked) nh|=128; if(f.b41.checked) nh|=256;
  if(nl==0 && nh==0){ alert('至少勾选一个频段！'); return false; }
  f.low.value=''+nl; f.high.value=''+nh;
  if(!confirm('将应用频段：FDD='+nl+' TDD='+nh+'\n\n模组将复位，网络约1-3分钟后恢复。\n若之后一直无网，点本页“恢复出厂频段”即可。')) return false;
  showWait('正在应用频段，请稍候…');
  return true;
}
function waitRestore(msg){
  if(!confirm(msg+'\n\n确认继续？')) return false;
  showWait(msg);
  return true;
}
var REAL={imei:'',iccid:''}, HID={imei:1,iccid:1};
var EYE_OPEN='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
var EYE_SHUT='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><path d="M1 1l22 22"/></svg>';
function dots(n){var s='';while(n-->0)s+='*';return s;}
function maskMid(v){
  v=v||'';
  // ICCIDs may contain hex letters (e.g. 898608461625D0576855), so accept
  // alphanumerics; error text is shown as-is.
  if(!/^[0-9A-Za-z]+$/.test(v)) return v;
  if(v.length<=8) return dots(v.length);
  return v.substr(0,4)+dots(v.length-8)+v.substr(v.length-4);
}
function paint(k){
  var e=document.getElementById(k+'Val');
  if(e) e.textContent=HID[k]?maskMid(REAL[k]):(REAL[k]||'');
  var b=document.getElementById('eye_'+k);
  if(b) b.innerHTML=HID[k]?EYE_OPEN:EYE_SHUT;
}
function tog(k){HID[k]=HID[k]?0:1;paint(k);}
// Both value boxes are set to one shared width, measured from the widest real
// value actually present.  This keeps the two eye icons in a single fixed
// column and stops them shifting when a value is shown or hidden, without
// relying on any particular glyph being monospaced.
function fitMask(){
  var im=document.getElementById('imeiVal'), ic=document.getElementById('iccidVal');
  if(!im||!ic) return;
  var probe=document.createElement('span');
  probe.style.cssText='position:absolute;visibility:hidden;white-space:pre;font-family:monospace;letter-spacing:1px';
  document.body.appendChild(probe);
  var w=0;
  [REAL.imei,REAL.iccid].forEach(function(v){
    probe.textContent=v||'';
    if(probe.offsetWidth>w) w=probe.offsetWidth;
  });
  document.body.removeChild(probe);
  if(w<60) w=60;
  im.style.width=(w+2)+'px';
  ic.style.width=(w+2)+'px';
}
var AUTO_MS=6000;      // 自动刷新间隔
var PAUSED=0;        // 频段操作期间暂停
var PENDING=0;       // 手动刷新撞上正在进行的读取时，读完立刻补一次
var timer=null;
var RETRY=0;         // 连续重试次数
var MAX_RETRY=5;     // 重试上限（防止无限转圈）
var REQ_TIMEOUT=15000;  // 单次请求硬超时（毫秒）
function setSpin(on){
  var b=document.getElementById('rfbtn');
  if(!b) return;
  if(on) b.className='refresh spin'; else b.className='refresh';
}
function setNote(msg){
  var n=document.getElementById('rfnote');
  if(n) n.innerHTML=msg||'';
}
// Every terminal path goes through finish(), so the spinner can never be left
// turning.  This is the guarantee the old code lacked.
function finish(){
  busy=0; RETRY=0; setSpin(0); setNote(''); next();
}
// Bounded retry.  The vendor app polls the same AT port every 20s, so a read can
// lose the lock; retry a few times, then give up and release the spinner instead
// of spinning forever.
function again(){
  busy=0;
  RETRY++;
  if(RETRY>MAX_RETRY){
    RETRY=0; setSpin(0);
    setNote('<span style="color:#b26a00">模组持续忙碌，已停止重试；稍后再点刷新</span>');
    next();
    return;
  }
  setNote('<span style="color:#b26a00">模组忙碌，重试中 '+RETRY+'/'+MAX_RETRY+'…</span>');
  if(timer) clearTimeout(timer);
  timer=setTimeout(function(){ loadAll(0,1); },1500);
}
function schedule(){
  if(timer) clearTimeout(timer);
  if(PAUSED) return;
  timer=setTimeout(function(){ loadAll(1); }, AUTO_MS);
}
// End-of-request router: a click that arrived mid-read is honoured first,
// otherwise just queue the next automatic tick.
function next(){
  if(PENDING){ PENDING=0; loadAll(0,1); return; }
  schedule();
}
// 密码表单前端校验
function checkPw(f){
  var a=f.pw1.value, b=f.pw2.value, tip=document.getElementById('pwtip');
  if(f.pw0 && !f.pw0.value){ tip.className='pwmsg pwerr'; tip.textContent='请输入当前密码'; return false; }
  if(!a){ tip.className='pwmsg pwerr'; tip.textContent='请输入新密码'; return false; }
  if(a.length<8){ tip.className='pwmsg pwerr'; tip.textContent='密码至少 8 位'; return false; }
  if(a!==b){ tip.className='pwmsg pwerr'; tip.textContent='两次输入的密码不一致'; return false; }
  tip.className='pwmsg pwok'; tip.textContent='提交中…';
  return true;
}
function manualRefresh(){
  if(timer) clearTimeout(timer);
  // A manual click must always end in a real AT read, never in cached data.
  // If a read is already in flight, remember the click and re-run when it lands.
  if(busy){ PENDING=1; return; }
  loadAll(0,1);
}
// 页面切到后台就停，切回来立刻刷一次
document.addEventListener('visibilitychange',function(){
  if(document.hidden){ if(timer) clearTimeout(timer); }
  else { if(!busy) loadAll(1); }
});
function loadAll(silent,force){
  if(busy) return;
  busy=1;
  setSpin(1);
  var spinAt=Date.now();
  var e=document.getElementById('info');
  // Never blank the panel: clearing it shrinks the box and makes the whole page
  // jump.  The spinner already signals activity, so keep the previous readings
  // on screen until the new ones arrive.  Only the very first load, when there
  // is nothing to show yet, uses the placeholder text.
  if(!e.innerHTML || e.innerHTML.indexOf('info-empty')>=0){
    e.innerHTML='<span class=info-empty>正在读取模组数据，请稍候…</span>';
  }
  var x=new XMLHttpRequest();
  // Without a timeout, a stalled server leaves readyState below 4 forever, which
  // pins busy=1 and silently swallows every later click.
  try{ x.timeout=REQ_TIMEOUT; }catch(err){}
  var handled=0;
  function fail(){
    // Fires on timeout / network error.  Guarded so it cannot double-run with
    // the readyState handler.
    if(handled) return;
    handled=1;
    if(force){ again(); } else { finish(); }
  }
  x.ontimeout=fail;
  x.onerror=fail;
  x.onreadystatechange=function(){
    if(x.readyState==4){
      if(handled) return;
      handled=1;
      // A cache hit returns in ~0ms; hold the spinner briefly so the click still
      // registers visually instead of flashing for a single frame.
      var hold=Math.max(0,450-(Date.now()-spinAt));
      setTimeout(function(){
      // The spinner is stopped only at a terminal outcome below, so a forced read
      // that has to wait for the throttle window or the AT lock keeps turning.
      var t=(x.responseText||'').trim();
      if(t=='BUSY'){
        // Module busy: keep what is displayed and retry (bounded).
        if(force){ again(); } else { finish(); }
        return;
      }
      if(x.status==200 && t.indexOf('BANDVAL=')>=0){
        var d={};
        t.split('\n').forEach(function(l){
          var p=l.indexOf('=');
          if(p>0) d[l.substring(0,p)]=l.substring(p+1);
        });
        // A forced read that lost the AT lock comes back as the previous cache
        // with CACHED=-1.  Retry (bounded) rather than presenting stale data.
        if(force && d.CACHED=='-1'){ again(); return; }
        var h='';
        if(d.DUPLEX!='?' && d.BAND!='?') h+='<b>当前驻网：</b>LTE '+d.DUPLEX+' 频段 B'+d.BAND+'<br>';
        else h+='<b>当前驻网：</b>未驻网（模组复位中或搜网中）<br>';
        var csq=parseInt(d.CSQ)||0;
        var rsrp=(d.RSRP&&d.RSRP!='?')?parseInt(d.RSRP):null;
        var q,lvl,dbm;
        if(rsrp!==null&&!isNaN(rsrp)){
          dbm='（RSRP '+rsrp+' dBm）';
          if(rsrp>=-85){q='很强';lvl=4;}
          else if(rsrp>=-95){q='良好';lvl=3;}
          else if(rsrp>=-105){q='一般';lvl=2;}
          else{q='较弱';lvl=1;}
        }else if(d.CSQ=='?'){
          q='未知';lvl=0;dbm='';
        }else{
          dbm='（约 '+(2*csq-113)+' dBm）';
          if(csq>=26){q='很强';lvl=4;}
          else if(csq>=18){q='良好';lvl=3;}
          else if(csq>=10){q='一般';lvl=2;}
          else{q='较弱';lvl=1;}
        }
        var bt='';
        for(var bi=1;bi<=4;bi++){
          var col=bi<=lvl?'#4caf50':'#ddd';
          var hh=6+bi*4;
          bt+='<span style="display:inline-block;width:5px;height:'+hh+'px;background:'+col+';margin-right:2px;vertical-align:bottom;border-radius:1px"></span>';
        }
        h+='<b>信号强度：</b>'+bt+' <span style="vertical-align:bottom">'+q+' '+dbm+'</span><br>';
        if(d.OPER) h+='<b>运营商：</b>'+d.OPER+'<br>';
        REAL.imei=d.IMEI||''; REAL.iccid=d.ICCID||'';
        h+='<b>IMEI：</b><span class=maskv id="imeiVal"></span><span class=eye id="eye_imei" onclick="tog(\'imei\')" title="显示 / 隐藏"></span><br>';
        h+='<b>ICCID：</b><span class=maskv id="iccidVal"></span><span class=eye id="eye_iccid" onclick="tog(\'iccid\')" title="显示 / 隐藏"></span><br>';
        // Only the timestamp is shown.  With a short auto-refresh interval there
        // is no need to explain caching to the user any more.  The label says
        // "read time" rather than "updated", because the time now stays put while
        // the panel is served from cache.
        h+='<span style="color:#2e7d32;font-size:12px">数据读取时间 '+d.STAMP+'</span>';
        e.innerHTML=h;
        // paint() must run AFTER the innerHTML above, otherwise the target
        // spans do not exist yet and the fields render blank.
        fitMask(); paint('imei'); paint('iccid');
        // Rendering must never return early: an early return here would skip
        // finish() and leave the spinner turning forever.  Wrap it in try/catch
        // so a DOM surprise cannot strand the button either.
        try{
          if(d.BANDVAL!='READFAIL'){
            var b=d.BANDVAL.split(',');
            var low=parseInt(b[4])||0, high=parseInt(b[3])||0;
            var f=document.getElementById('bandform');
            if(f){
              f.b1.checked=!!(low&1); f.b3.checked=!!(low&4);
              f.b5.checked=!!(low&16); f.b8.checked=!!(low&128);
              f.b34.checked=!!(high&2); f.b38.checked=!!(high&32);
              f.b39.checked=!!(high&64); f.b40.checked=!!(high&128); f.b41.checked=!!(high&256);
              f.low_base.value=low; f.high_base.value=high;
              f.low.value=low; f.high.value=high;
            }
            var c=document.getElementById('cur');
            if(c) c.innerHTML=d.HUMAN;
          } else {
            var c2=document.getElementById('cur');
            if(c2) c2.innerHTML='当前状态：读取失败（模组忙/重启中）— 不影响下方操作';
          }
        }catch(err){}
        // No return here: control falls through to the finish() below, which
        // releases the spinner and schedules the next round exactly once.
      } else if(!silent){
        e.innerHTML='读取失败（模组忙/重启中），可点刷新重试';
      }
      // The success path already ended in finish(); this covers the non-200 /
      // malformed-response branch so no path can leave the spinner turning.
      finish();
      }, hold);
    }
  };
  x.open('GET','?a=data'+(force?'&force=1':''),true);
  x.send();
}
</script>
CEOF

echo "<div class='info' id='info'><span class=info-empty>正在读取模组数据，请稍候…</span></div>"
echo "<p><button class=refresh id=rfbtn type=button onclick='manualRefresh()' title='立即刷新'>"
echo "<svg width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\"><path d=\"M21 12a9 9 0 1 1-2.64-6.36\"/><path d=\"M21 3v6h-6\"/></svg>"
echo " 刷新</button><span class=auto>每 $((AUTO_SEC)) 秒自动刷新</span>"
echo "<span class=auto id=rfnote></span></p>"
echo "<p class=note>信号强度参考：-80 很好、-95 良好、-105 一般、-110 以下较弱。</p>"

echo "<h3>① IMEI 改串</h3>"
if [ -n "$IMEI_RESULT" ]; then
  if [ -n "$IMEI_RESULT_OK" ]; then
    echo "<div class='msg ok'>$IMEI_RESULT</div>"
  else
    echo "<div class='msg err'>$IMEI_RESULT</div>"
  fi
fi
if [ -n "$PENDING_IMEI" ]; then
  echo "<div class='msg ok'>待应用的新 IMEI：<b>$PENDING_IMEI</b><br>点下方按钮重启设备，重启后自动写入模组生效。<br><span style='color:#c62828'>改串重启比平常久，约需 2-3 分钟，请耐心等待。</span></div>"
  echo "<form method=POST action='?a=band' onsubmit=\"return rebootOnly()\">"
  echo "<button class=btn type=submit name=reboot value='1'>立即重启设备生效</button>"
  echo "</form>"
fi
cat << 'IEOF'
<script>
function luhnCheck(s){
  var sum=0, dbl=false;
  for(var i=s.length-1;i>=0;i--){
    var d=parseInt(s.charAt(i),10);
    if(isNaN(d)) return false;
    if(dbl){ d*=2; if(d>9) d-=9; }
    sum+=d; dbl=!dbl;
  }
  return sum%10===0;
}
function luhnFix(s14){
  var sum=0, dbl=true;
  for(var i=s14.length-1;i>=0;i--){
    var d=parseInt(s14.charAt(i),10);
    if(dbl){ d*=2; if(d>9) d-=9; }
    sum+=d; dbl=!dbl;
  }
  var c=(10-(sum%10))%10;
  return s14+''+c;
}
function buildImei(f){
  var raw=f.imei.value.replace(/[^0-9]/g,'');
  var v=raw;
  if(v.length==14){
    var fixed=luhnFix(v);
    if(!confirm('你输入了 14 位数字，已自动补全校验位：\n\n  '+v+'  →  '+fixed+'\n\n使用这个 IMEI 吗？')){
      return false;
    }
    v=fixed;
  } else if(!/^[0-9]{15}$/.test(v)){
    alert('IMEI 格式不对：需要 15 位数字（当前 '+v.length+' 位）');
    return false;
  } else if(!luhnCheck(v)){
    var fixed15=luhnFix(v.substring(0,14));
    if(confirm('这个 IMEI 的校验位不合法，模组会拒绝写入！\n\n  你的输入：'+v+'\n  建议修正：'+fixed15+'\n\n使用修正后的值吗？\n（如果确定原始值没错，请点"取消"并重新核对）')){
      v=fixed15;
    } else {
      return false;
    }
  }
  f.imei.value=v;
  if(confirm('将 IMEI 改为：'+v+'\n\n是否立即重启设备生效？\n（注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待）')){
    f.reboot.value='1';
    var d=document.createElement('div');
    d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999';
    d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0">正在保存并重启设备…</p></div>';
    document.body.appendChild(d);
  } else {
    f.reboot.value='';
  }
  return true;
}
function rebootOnly(){
  if(!confirm('设备将立即重启，重启时自动把新 IMEI 写入模组。\n\n注意：改串重启比平常久，约需 2-3 分钟，期间请耐心等待。\n\n确认重启？')) return false;
  var d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;z-index:9999';
  d.innerHTML='<div style="background:#fff;padding:28px 40px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.18);text-align:center"><div class="spinner"></div><p style="font-size:17px;margin:0">正在重启设备…</p></div>';
  document.body.appendChild(d);
  return true;
}
</script>
<form method=POST action="?a=band" onsubmit="return buildImei(this)">
<input type=hidden name=reboot value=''>
<p>新 IMEI：<input name=imei maxlength=20 size=20 placeholder="15位数字"> <input class=btn type=submit value='保存'></p>
<p class=note>点保存后会校验 IMEI 合法性（含校验位），可自动修正；确认后询问是否立即重启生效。</p>
<p class=note style="color:#c62828">改串后的重启比平常久（约 2-3 分钟），请耐心等待。</p>
</form>
IEOF
echo "<hr>"
echo "<h3>② 锁频段</h3>"
if [ -n "$RESULT" ]; then
  if [ -n "$RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $RESULT</div>"
  else
    echo "<div class='msg err'>✗ $RESULT</div>"
  fi
fi
echo "<p id=cur style='color:#555;margin:14px 0 6px'>$CURTEXT</p>"
echo "<form id='bandform' method=POST action='?a=band' onsubmit='return build(this)'>"
echo "<input type=hidden name=low_base value='$RLOW'>"
echo "<input type=hidden name=high_base value='$RHIGH'>"
echo "<input type=hidden name=low value='$RLOW'>"
echo "<input type=hidden name=high value='$RHIGH'>"
cat << CEOF
<table>
<tr><th>FDD-LTE</th><th>频率</th><th>TDD-LTE</th><th>频率</th></tr>
<tr><td><input type=checkbox name=b1 $B1> B1</td><td>2100M</td>
<td><input type=checkbox name=b34 $B34> B34</td><td>2000M</td></tr>
<tr><td><input type=checkbox name=b3 $B3> B3</td><td>1800M</td>
<td><input type=checkbox name=b38 $B38> B38</td><td>1900M</td></tr>
<tr><td><input type=checkbox name=b5 $B5> B5</td><td>850M</td>
<td><input type=checkbox name=b39 $B39> B39</td><td>1900M</td></tr>
<tr><td><input type=checkbox name=b8 $B8> B8</td><td>900M</td>
<td><input type=checkbox name=b40 $B40> B40</td><td>2300M</td></tr>
<tr><td></td><td></td>
<td><input type=checkbox name=b41 $B41> B41</td><td>2500M</td></tr>
</table>
<p><input class=btn type=submit value='应用勾选'></p>
</form>
<p class=note>点“应用勾选”后模组会重启，断网约 1-3 分钟自动恢复；想立即看结果可点上方“刷新数据”。</p>
<p style="color:#666;margin:16px 0 6px;font-size:14px">锁频段后一直无网？可以恢复到已知可用的频段（模组重启中也能点）：</p>
<form method=POST action="?a=band" style="display:inline" onsubmit="return waitRestore('正在恢复出厂频段…')">
<input class=btn type=submit name=restore value='恢复出厂频段'>
</form>
CEOF

if [ -n "$HASBAK" ]; then
  echo "<form method=POST action='?a=band' style='display:inline' onsubmit=\"return waitRestore('正在恢复上次频段…')\">"
  echo "<input class=btn type=submit name=restore_bak value='恢复上次频段'>"
  echo "</form>"
fi


echo "<hr>"
echo "<h3>③ 管理后台密码</h3>"
echo "<p>本设备内置 <b>OpenWrt 管理后台</b>（端口 8888），可配置网口、无线、防火墙等更多功能。"
echo "设置一个密码后，即可用 <b>root</b> + 该密码登录："
echo "<br><a href=\"http://192.168.1.1:8888\" target=\"_blank\">http://192.168.1.1:8888</a></p>"
# 结果提示紧贴表单，避免用户看不到
if [ -n "$PW_RESULT" ]; then
  if [ -n "$PW_RESULT_OK" ]; then
    echo "<div class='msg ok'>✓ $PW_RESULT</div>"
  else
    echo "<div class='msg err'>✗ $PW_RESULT</div>"
  fi
fi
echo "<form method=POST action='?a=pw' onsubmit=\"return checkPw(this)\">"
echo "<table>"
if [ -n "$PW_USER_SET" ]; then
  echo "<tr><td>当前密码</td><td><input class=pwin type=password name=pw0 id=pw0 maxlength=64 autocomplete=current-password></td></tr>"
fi
echo "<tr><td>新密码</td><td><input class=pwin type=password name=pw1 id=pw1 maxlength=64 autocomplete=new-password></td></tr>"
echo "<tr><td>确认密码</td><td><input class=pwin type=password name=pw2 id=pw2 maxlength=64 autocomplete=new-password></td></tr>"
echo "<tr><td></td><td><button class=btn type=submit>设置密码</button>"
echo "<span class=pwmsg id=pwtip></span></td></tr>"
echo "</table>"
echo "</form>"
if [ -n "$PW_USER_SET" ]; then
  echo "<p class=note>修改密码需要先输入当前密码。"
  echo "<br>忘记当前密码时，可通过 80 后台的「系统命令行」执行 <code>passwd -d root</code> 清除后回到本页重设。</p>"
else
  echo "<p class=note>要求：至少 8 位。设置后修改需要先输入当前密码。</p>"
fi

# 首次加载显示"正在读取"，之后由 schedule() 静默轮询
echo "<script>setTimeout(function(){loadAll(0);},300);</script>"""
echo "</body></html>"
