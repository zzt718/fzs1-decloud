#!/bin/sh
# ============================================================
# 恢复原厂包 v1 —— 「恢复原厂包」的 runapp.sh
# 开机早期（固件启动前）执行：换回原厂包 → 清理本项目持久化改动
# → 复位频段到出厂 → 重启。重启后设备运行原厂固件与原厂行为。
# 任何关键步骤失败：回退 package.bak（= 刷机前的包），设备回到原状态。
# ============================================================
SYS_APP_DIR="/usr/aos"
FACTORY_MD5="3716303a0a7d853bc27728dc4d3191e9"
FACTORY_SIZE="1247100"
LOG=/tmp/restore.log

feed(){ ( echo w > /dev/watchdog ) 2>/dev/null || true; }
log(){ echo "[restore] $*" >> $LOG 2>/dev/null; echo "[restore] $*"; }
clearlock(){
  L=/var/lock/LCK..$1
  [ -f "$L" ] || return 0
  LP=$(cat "$L" 2>/dev/null | tr -d '\0\r\n ')
  case "$LP" in ''|*[!0-9]*) rm -f "$L"; return 0;; esac
  kill -0 "$LP" 2>/dev/null || rm -f "$L"
}
atc(){
  D="$1"; C="$2"
  clearlock "$D"
  O=/tmp/atc_restore.txt; rm -f $O
  ( (echo -e "$C\r"; sleep 1) | microcom -t 2000 -s 115200 /dev/$D > $O 2>/dev/null ) & MP=$!
  ( sleep 5; kill $MP 2>/dev/null ) & KT=$!
  wait $MP 2>/dev/null; kill $KT 2>/dev/null
  R=$(cat $O 2>/dev/null | tr -d '\r' | tr '\n' ' ')
  rm -f $O
  clearlock "$D"
  echo "$R"
}
findport(){
  for t in /sys/bus/usb-serial/devices/ttyUSB*; do
    p=$(readlink -f $t 2>/dev/null)
    case "$p" in */1-1.1/1-1.1:1.4/*) echo "${t##*/}"; return 0;; esac
  done
  return 1
}
wait_ready(){ # wait_ready <max_s>：CGSN 读到 15 位数字才算就绪
  DDL=$(( $(cut -d. -f1 /proc/uptime) + $1 ))
  while [ $(cut -d. -f1 /proc/uptime) -lt $DDL ]; do
    feed
    P=$(findport)
    if [ -n "$P" ]; then
      R=$(atc "$P" 'AT+CGSN')
      case "$R" in *[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]*) echo "$P"; return 0;; esac
    fi
    sleep 4
  done
  return 1
}

: > $LOG
log "=== 恢复原厂包 v1 开始 ==="

# ---------- 1. 提取并校验原厂包 ----------
feed
cp /mnt/mtdblock5/usr/aos/package.tar.gz /tmp/factory_pkg.tar.gz 2>/dev/null
GOT=$(md5sum /tmp/factory_pkg.tar.gz 2>/dev/null | cut -d' ' -f1)
log "原厂包 md5=$GOT (期望 $FACTORY_MD5)"
if [ "$GOT" != "$FACTORY_MD5" ]; then
  log "!! 原厂包提取/校验失败 —— 回退：恢复 package.bak（刷机前的包）"
  if [ -f /usr/aos/package.bak ]; then
    cp /usr/aos/package.bak /usr/aos/package.tar.gz && sync
    log "已回退到 package.bak，重启"
  fi
  reboot
  exit 1
fi

# ---------- 2. 换包（原厂包同时写入 package.tar.gz 与 package.bak） ----------
cp /tmp/factory_pkg.tar.gz $SYS_APP_DIR/package.tar.gz
cp /tmp/factory_pkg.tar.gz $SYS_APP_DIR/package.bak
sync
log "已替换 package.tar.gz / package.bak 为原厂包"

# ---------- 3. 清理本项目持久化改动 ----------
# 3.1 卡模式锁（去掉后固件回到出厂的云卡优先行为）
rm -f $SYS_APP_DIR/local_sim_config
# 3.1b web_config 云域名恢复（本项目清空过 simserver 域名；兼容固件重写后的带空格
#      与本项目写入的无空格两种格式，只动 simserver 段内的 ip 字段）
WCD=$SYS_APP_DIR/web_config
if [ -f "$WCD" ]; then
        sed -i 's|<simserver><param name="ip" value="" />|<simserver><param name="ip" value="www.dimiccs.com" />|' "$WCD" 2>/dev/null
        sed -i 's|<simserver><param name="ip"value="" />|<simserver><param name="ip"value="www.dimiccs.com" />|' "$WCD" 2>/dev/null
        log "web_config 云域名恢复: $(grep -c 'www.dimiccs.com' $WCD) 处"
fi
# 3.2 工具箱标记
rm -f $SYS_APP_DIR/decloud_lang_set $SYS_APP_DIR/decloud_pw_set
rm -f $SYS_APP_DIR/imei_request
rm -f /etc/band_backup
# 3.3 LuCI 语言恢复出厂值 auto
uci set luci.main.lang='auto' 2>/dev/null
uci commit luci 2>/dev/null
# 3.4 DNS：移除本项目的静态上游与云域名黑洞，恢复出厂的 dns 配置
uci delete dhcp.@dnsmasq[0].noresolv 2>/dev/null
uci del_list dhcp.@dnsmasq[0].server='223.5.5.5' 2>/dev/null
uci del_list dhcp.@dnsmasq[0].server='114.114.114.114' 2>/dev/null
uci del_list dhcp.@dnsmasq[0].server='/dimiccs.com/' 2>/dev/null
uci del_list dhcp.@dnsmasq[0].server='/dinstarcloud.com/' 2>/dev/null
uci commit dhcp 2>/dev/null
# 3.5 时区恢复出厂（删除本项目写入的 CST-8）
rm -f /etc/TZ
uci delete system.@system[0].timezone 2>/dev/null
uci delete system.@system[0].zonename 2>/dev/null
uci commit system 2>/dev/null
# 3.6 早期版本可能遗留的 decloud 目录与定时任务（老用户升级路径的清理）
rm -rf /etc/decloud
sed -i '/decloud/d' /etc/crontabs/root 2>/dev/null
log "持久化清理完成"

# ---------- 4. 频段复位到出厂（模组 NV；避免原厂固件开机即遇 B3-only 挣扎） ----------
feed
sleep 5
P=$(wait_ready 120)
if [ -n "$P" ]; then
  i=0
  while [ $i -lt 6 ]; do
    feed
    R=$(atc "$P" 'AT*BAND=12,78,145,482,149,0,2,2')
    case "$R" in *OK*) log "频段已复位出厂"; break;; esac
    sleep 3
    i=$((i+1))
  done
else
  log "!! 模组 AT 口未就绪，跳过频段复位（若原频段为 B3-only，原厂固件首次开机可能挣扎数分钟）"
fi

# ---------- 5. 重启：下一次开机运行原厂包 ----------
feed
sync
sleep 2
log "=== 重启进入原厂固件 ==="
reboot
exit 0
